export const environment = {
    production: false,
    apiUrl: 'http://localhost:8003/',
    // apiUrl:'https://sdeiaiml.com:9039/',
    encryptionKey:"HelloWorld"
};
  