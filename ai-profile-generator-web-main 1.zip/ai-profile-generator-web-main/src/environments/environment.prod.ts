export const environment = {
  production: true,
  // Staging API url
  apiUrl: 'https://sdeiaiml.com:9039/',

  // Prod API url
  // apiUrl:'http://52.62.54.27/',
  // apiUrl: 'https://api.peopleworksmart.com/',

  encryptionKey: "HelloWorld"
};
