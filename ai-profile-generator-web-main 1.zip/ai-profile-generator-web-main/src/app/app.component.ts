import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'ai-profile-generator';

  constructor(private router: Router) { }

  // Define an array of routes where you don't want the sidebar and header
  hideLayoutRoutes = ['/login', '/forgot-password', '/reset-password','/set-password'];

  shouldShowLayout(): boolean {
    return !this.hideLayoutRoutes.some(route => this.router.url.startsWith(route));
  }

}
