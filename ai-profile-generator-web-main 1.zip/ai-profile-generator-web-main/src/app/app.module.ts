import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from '././Components/Login/login.component';
import { ForgotPasswordComponent } from '././Components/Forgot-password/forgot-password.component';
import { ResetPasswordComponent } from './Components/Reset-password/reset-password.component';
import { UserService } from './services/user.service';
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ToastrModule } from 'ngx-toastr';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';  // Import this
import { RoleManagementComponent } from './Components/role-management/role-management.component';
import { PaginationComponent } from './Components/Pagination/pagination.component';
import { StaffManagementComponent } from './Components/Staff-management/staff-management.component';
import { HeaderComponent } from './Components/header/header.component';
import { MatTableModule } from '@angular/material/table';
import {MatButtonModule} from '@angular/material/button';
import {MatDialog, MatDialogModule} from '@angular/material/dialog';
// import { CreateRoleComponent } from './Components/role-management/create-role/create-role.component';
import {MatPaginatorModule} from '@angular/material/paginator';
import { CommonModule } from '@angular/common';
import { MatSelectModule } from '@angular/material/select';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { SidebarComponent } from './Components/sidebar/sidebar.component';
import { LayoutComponent } from './Components/layout/layout.component';
import { LoaderComponent } from './Components/loader/loader.component';
import { DashboardComponent } from './Components/dashboard/dashboard.component';
import { SetPasswordComponent } from './Components/set-password/set-password.component';
import { ChangePasswordComponent } from './Components/change-password/change-password.component';
import { MatIcon, MatIconModule } from '@angular/material/icon';
import { UpdateProfileComponent } from './Components/update-profile/update-profile.component';
import { RoleCategoryComponent } from './Components/role-category/role-category.component';
import { PermissionManagementComponent } from './Components/permission-management/permission-management.component';
import {MatCheckboxModule} from '@angular/material/checkbox';
import { ScoreManagementComponent } from './Components/score-management/score-management.component';
import { WorkStyleManagemntComponent } from './Components/work-style-managemnt/work-style-managemnt.component';
import { TechnicalProficiencyManagementComponent } from './Components/technical-proficiency-management/technical-proficiency-management.component';
import { MasterService } from './services/master.service';
import { NoPermissionComponent } from './Components/no-permission/no-permission.component';
import { AuthInterceptor } from './interceptor/auth.service';
import { AIParsedResumeComponent } from './Components/ai-parsed-resume/ai-parsed-resume.component';
import { ManualResumeComponent } from './Components/manual-resume/manual-resume.component';
import { CandidateProfileManagementComponent } from './Components/candidate-profile-management/candidate-profile-management.component';
import { CognitiveCapabilityComponent } from './Components/cognitive-capability/cognitive-capability.component';
import { AiResumeTemplateComponent } from './Components/ai-resume-template/ai-resume-template.component';
import { NgxEditorModule } from 'ngx-editor';
import { ThemeSettingComponent } from './Components/theme-setting/theme-setting.component';
import { ScoreDescriptionComponent } from './Components/score-description/score-description.component';
import { NotFoundComponent } from './Components/not-found/not-found.component';
import { MatTooltipModule } from '@angular/material/tooltip';
import { UpdateCandidateProfileComponent } from './Components/update-candidate-profile/update-candidate-profile.component';
import { GeniusPairingsComponent } from './Components/genius-pairings/genius-pairings.component';
import { ImageCropperModule } from 'ngx-image-cropper';
import { AssessmentDescriptionComponent } from './Components/assessment-description/assessment-description.component';
import { AssessmentGradeComponent } from './Components/assessment-grade/assessment-grade.component';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    ForgotPasswordComponent,
    ResetPasswordComponent,
    RoleManagementComponent,
    PaginationComponent,
    StaffManagementComponent,
    HeaderComponent,
    SidebarComponent,
    LayoutComponent,
    LoaderComponent,
    DashboardComponent,
    SetPasswordComponent,
    ChangePasswordComponent,
    UpdateProfileComponent,
    RoleCategoryComponent,
    PermissionManagementComponent,
    ScoreManagementComponent,
    WorkStyleManagemntComponent,
    TechnicalProficiencyManagementComponent,
    NoPermissionComponent,
    CognitiveCapabilityComponent,
    CandidateProfileManagementComponent,
    ManualResumeComponent,
    AIParsedResumeComponent,
    AiResumeTemplateComponent,
    ThemeSettingComponent,
    ScoreDescriptionComponent,
    NotFoundComponent,
    UpdateCandidateProfileComponent,
    GeniusPairingsComponent,
    AssessmentDescriptionComponent,
    AssessmentGradeComponent,
    // CreateRoleComponent
  ],
  imports: [
    
    CommonModule,
    NgxEditorModule,
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    BrowserAnimationsModule,
    MatTooltipModule,
    ToastrModule.forRoot({
      timeOut: 10000, // 10 seconds
      closeButton: true,
      progressBar: true,
    }),
    HttpClientModule,
    MatTableModule,
    MatButtonModule,
    MatDialogModule,
    MatPaginatorModule,
    MatSelectModule,
    MatFormFieldModule,
    MatInputModule,
    MatIconModule,
    MatCheckboxModule,
    ImageCropperModule
  ],
  providers: [{ provide: HTTP_INTERCEPTORS, useClass: AuthInterceptor, multi: true },UserService,MasterService],
  bootstrap: [AppComponent],
  
})
export class AppModule { }
