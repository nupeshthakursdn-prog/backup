import { Component } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
// import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ChangeDetectionStrategy, inject } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UserService } from 'src/app/services/user.service';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { MasterService } from 'src/app/services/master.service';
// import { CreateRoleComponent } from './create-role/create-role.component';
interface Food {
  value: string;
  viewValue: string;
}

export interface PeriodicElement {
  typeOfScore: string;
  value: string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  {
    typeOfScore: 'Work Style',
    value: '0-5'
  },
  {
    typeOfScore: 'Cognitive Ability',
    value: '5-10'
  },
  {
    typeOfScore: 'Technical Proficiency',
    value: '10-15'
  },
];

@Component({
  selector: 'app-score-description',
  templateUrl: './score-description.component.html',
  styleUrls: ['./score-description.component.scss']
})
export class ScoreDescriptionComponent {

  loader: boolean = false
  limit: any = 10
  pageNumber: any = 1
  totalLength: any = 0
  searchText: any = ''

  displayedColumns: string[] = ['typeOfScore', 'description', 'value', 'actions'];
  dataSource = ELEMENT_DATA;
  ELEMENT_DATA: PeriodicElement[] = [];
  rolesList: any = []
  scoresList: any = []
  scoreDescriptionList: any = []
  scoreDescriptionForm: FormGroup;
  updateScoreDescriptionForm: FormGroup;
  selectedScoreDesId: any = '';;
  selectedScoreDescription: any = ''

  constructor(private fb: FormBuilder, private modalService: NgbModal, public dialog: MatDialog,
    private masterService: MasterService, private toastr: ToastrService) {

    this.scoreDescriptionForm = this.fb.group({
      talent_matrix: ['', Validators.required],
      score_value: ['', [Validators.required, Validators.min(0), Validators.max(100)]],
      description: ['', Validators.required],
    });

    this.updateScoreDescriptionForm = this.fb.group({
      talent_matrix: ['', Validators.required],
      score_value: ['', [Validators.required, Validators.min(0), Validators.max(100)]],
      description: ['', Validators.required],
    });

  }

  ngOnInit(): void {
    this.getScoresDescription();
  }

  getScoresDescription() {
    this.loader = true
    let queryData = {
      limit: this.limit,
      page: this.pageNumber,
      searchText: this.searchText
    }
    this.masterService.getScoreDescription(queryData).subscribe(
      (res: any) => {
        this.loader = false;
        if (res?.status === 200 && res?.data?.results) {
          this.scoreDescriptionList = res?.data?.results;
          this.totalLength = res?.data?.total;
        }
      },
      (err) => {
        this.loader = false;
        if (err?.status !== 401) {
          let errorMessage = 'An error occurred. Please try again later.'
          if (err.error) {
            if (err.error.errors && Object.keys(err.error.errors).length > 0) {
              errorMessage = err.error.errors;
            } else if (err.error.message) {
              errorMessage = err.error.message;
            }
          }
        }
      }
    );
  }

  getScoreDescriptionById() {

    this.loader = true;

    this.masterService.getScoreDesById(this.selectedScoreDescription).subscribe(
      (res: any) => {
        this.loader = false;

        if (res?.status === 200 && res?.data) {
          const { talent_matrix, max_value, description } = res.data;

          this.updateScoreDescriptionForm.patchValue({
            talent_matrix: this.toTitleCase(talent_matrix) || '',
            score_value: max_value ? max_value : '',
            description: description || ''
          });

        } else {
          this.toastr.error(res?.message || "An error occurred. Please try again.", "Error");
        }
      },
      (err) => {
        this.loader = false;
        if (err?.status !== 401) {
          let errorMessage = 'An error occurred. Please try again later.'
          if (err.error) {
            if (err.error.errors && Object.keys(err.error.errors).length > 0) {
              errorMessage = err.error.errors;
            } else if (err.error.message) {
              errorMessage = err.error.message;
            }
          }
          this.toastr.error(errorMessage, 'Error');
        }
      }
    );
  }


  onSubmit(): void {

    if (this.scoreDescriptionForm.valid) {
      this.loader = true;
      const { talent_matrix, score_value, description } = this.scoreDescriptionForm.value;

      const data = {
        talent_matrix: talent_matrix.toLowerCase(),
        max_value: score_value,
        description: description
      };

      this.masterService.addScoreDescription(data).subscribe(
        (res: any) => {
          this.loader = false;
          if (res?.status === 200) {
            this.toastr.success(res.message, "Success");
            this.modalService.dismissAll();
            this.scoreDescriptionForm.reset();
            this.getScoresDescription();
          } else {
            this.toastr.error(res.message || "An error occurred. Please try again.", "Error");
          }
        },
        (err) => {
          this.loader = false;
          if (err?.status !== 401) {
            let errorMessage = 'An error occurred. Please try again later.';
            if (err?.error) {
              if (err?.error?.errors && Object.keys(err?.error?.errors).length > 0) {
                for (let field in err.error.errors) {
                  if (err.error.errors.hasOwnProperty(field)) {
                    this.toastr.error(err.error.errors[field]);
                  }
                }
              } else if (err?.error?.message) {
                errorMessage = err?.error?.message;
                this.toastr.error(errorMessage, 'Error');
              }
            }
          }
        }
      );
    } else {
      this.toastr.error("Please select all required fields");
      this.scoreDescriptionForm.markAllAsTouched();
    }
  }


  onSubmitUpdate(): void {

    if (this.updateScoreDescriptionForm.valid) {
      this.loader = true;
      const { talent_matrix, score_value, description } = this.updateScoreDescriptionForm.value;

      const data = {
        score_description_id: this.selectedScoreDescription,  // Ensure this is set
        talent_matrix: talent_matrix.toLowerCase(),
        max_value: score_value,
        description: description
      };
      this.masterService.updateScoreDescriptionId(data).subscribe(
        (res: any) => {
          this.loader = false;
          if (res?.status === 200) {
            this.toastr.success(res.message, "Success");
            this.modalService.dismissAll();
            this.getScoresDescription();
          } else {
            this.toastr.error(res.message || "An error occurred. Please try again.", "Error");
          }
        },
        (err) => {
          this.loader = false;
          if (err?.status !== 401) {
            let errorMessage = 'An error occurred. Please try again later.';
            if (err?.error) {
              if (err?.error?.errors && typeof err.error.errors === 'object' && Object.keys(err.error.errors).length > 0) {
                for (let field in err.error.errors) {
                  if (err.error.errors.hasOwnProperty(field)) {
                    this.toastr.error(err.error.errors[field], 'Error');
                  }
                }
              } else if (err?.error?.message) {
                errorMessage = err.error.message; // Now it correctly captures "Score description already exist."
                this.toastr.error(errorMessage);
              }
            }
          }
        }
      );
    } else {
      this.toastr.error("Please select all required fields");
      this.updateScoreDescriptionForm.markAllAsTouched();
    }
  }


  deleteScoreDescription() {
    this.loader = true
    this.masterService.deleteScoreDescriptionById(this.selectedScoreDesId).subscribe(
      (res: any) => {
        if (res?.status === 200) {
          this.loader = false
          this.toastr.success(res.message, 'Success');
          this.modalService.dismissAll();
          this.getScoresDescription()
        } else {
          this.loader = false;
          this.toastr.error(res.message || 'An error occurred. Please try again.', 'Error');
        }
      },
      (err) => {
        this.loader = false;
        if (err?.status !== 401) {
          let errorMessage = 'An error occurred. Please try again later.'
          if (err.error) {
            if (err.error.errors && Object.keys(err.error.errors).length > 0) {
              errorMessage = err.error.errors;
            } else if (err.error.message) {
              errorMessage = err.error.message;
            }
          }
          this.toastr.error(errorMessage, 'Error');
        }
      }
    );
  }

  onSearchChange(searchTexts: any) {
    const trimmedText = searchTexts?.trim();
    if (trimmedText) {
      this.searchText = searchTexts;
      this.getScoresDescription();
    } else if (searchTexts === "") {
      this.getScoresDescription();
    }
  }

  clearAll() {
    this.searchText = '';
    this.selectedScoreDesId = '';
    this.getScoresDescription();
  }

  openModalAddscore(addScore: any) {
    this.scoreDescriptionForm.setValue({
      talent_matrix: '',
      score_value: '',
      description: ''
    });
    this.modalService.open(addScore, {
      centered: true,
      size: "md",
      windowClass: "master_modal add_content",
    });
  }

  openModaleditscore(edit: any, scoreId: any) {

    if (scoreId) {
      this.selectedScoreDescription = scoreId;
      this.getScoreDescriptionById();
    }
    this.modalService.open(edit, {
      centered: true,
      size: "md",
      windowClass: "master_modeladd_content",
    })
  }

  openModaldeletescore(deleteModal: any, scoreId: any) {
    if (scoreId) {
      this.selectedScoreDesId = scoreId;
    }
    this.modalService.open(deleteModal, {
      centered: true,
      size: "md",
      windowClass: "master_modeladd_content",
    })
  }

  handlePageEvent(event: any) {
    this.limit = event?.pageSize;
    this.pageNumber = event?.pageIndex + 1
    this.getScoresDescription()
  }

  toTitleCase(str: string): string {
    return str
      ?.toLowerCase()
      ?.split(' ')
      ?.map(word => word.charAt(0).toUpperCase() + word.slice(1))
      ?.join(' ');
  }
}