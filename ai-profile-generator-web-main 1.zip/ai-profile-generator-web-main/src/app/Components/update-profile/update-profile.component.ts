import { Component } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { MasterService } from 'src/app/services/master.service';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-update-profile',
  templateUrl: './update-profile.component.html',
  styleUrls: ['./update-profile.component.scss']
})
export class UpdateProfileComponent {
  loader: boolean = false;
  loggedInUserData: any;
  loggedInUserId: any;
  updateUserForm: FormGroup;
  editimage: any = '';

  isClicked: boolean = false;
  profilePic: string = 'assets/images/doc-img.png'; // Default profile picture
  defaultProfilePic: string = 'assets/images/doc-img.png';
  formData: any = { image: '' };

  triggerFileInput() {
    const fileInput = document.getElementById('fileInput') as HTMLInputElement;
    fileInput.click();
  }


  firstNameControl = new FormControl('', [Validators.required]);
  middleNameControl = new FormControl(''); // Middle name is optional
  lastNameControl = new FormControl('', [Validators.required]);
  emailControl = new FormControl('', [Validators.required, Validators.email]);
  mobileControl = new FormControl('', [
    Validators.required,
    Validators.pattern(/^[6-9]\d{9}$/) // Validates 10-digit mobile number starting with 6-9
  ]);

  matcher = {
    isErrorState: (control: FormControl | null) => {
      return !!(control && control.invalid && control.touched);
    }
  };
  constructor(private fb: FormBuilder, private userService: UserService, private masterService: MasterService, private toastr: ToastrService) {
    this.updateUserForm = this.fb.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      phone: ['', [Validators.required]],
      jobTitle: ['', Validators.required],
      image: ['', []],
    });
  }

  ngOnInit(): void {
    let loggedInUser = localStorage.getItem('loginUser');
    if (loggedInUser) {
      this.loggedInUserData = JSON.parse(loggedInUser)
      this.loggedInUserId = this.loggedInUserData?.user_id;
      this.getStaffById();
    }
  }

  getStaffById() {
    this.loader = true;
    this.userService.getStaffById({ id: this.loggedInUserId }).subscribe(
      (res: any) => {
        if (res?.status === 200) {
          // console.log(res?.data, "phone_number___");
          this.loggedInUserData = res?.data;
          this.updateUserForm.patchValue({
            firstName: res?.data?.first_name,
            lastName: res?.data?.last_name,
            jobTitle:res?.data?.job_title,
            email: res?.data?.email,
            phone: res?.data?.phone_number,
            staff_id: this.loggedInUserId
          });
          this.editimage = res?.data?.image;
          this.loader = false;
        } else {
          this.loader = false;
          this.toastr.error(res?.message || 'An error occurred. Please try again.', 'Error');
        }
      },
      (err) => {
        this.loader = false;
        if (err?.status !== 401) {
          let errorMessage = 'An error occurred. Please try again later.'
          if (err.error) {
            if (err.error.errors && Object.keys(err.error.errors).length > 0) {
              errorMessage = err.error.errors;
            } else if (err.error.message) {
              errorMessage = err.error.message;
            }
          }
          this.toastr.error(errorMessage, 'Error');
        }
      }
    );
  }

  onSubmitUpdate(): void {

    if (this.updateUserForm.valid) {
      this.loader = true
      const formData = new FormData();
      formData.append('first_name', this.updateUserForm.value.firstName);
      formData.append('last_name', this.updateUserForm.value.lastName);
      formData.append('job_title', this.updateUserForm.value.jobTitle);
      // formData.append('role', this.updateUserForm.value.role);
      formData.append('email', this.updateUserForm.value.email);
      formData.append('phone_number', this.updateUserForm.value.phone);
      // formData.append('password', this.updateUserForm.value.password);
      formData.append('user_id', this.loggedInUserId);

      if (this.updateUserForm.value.image) {
        formData.append('image', this.updateUserForm.value.image);
      }

      this.userService.updateUserProfile(formData).subscribe(
        (res: any) => {
          if (res?.status === 200) {
            this.loader = false
            this.toastr.success(res.message, 'Success');
            this.userService.updateUserDetails(res?.data);
            // this.modalService.dismissAll();
            this.getStaffById();
          } else {
            this.loader = false;
            this.toastr.error(res.message || 'An error occurred. Please try again.', 'Error');
          }
        },
        (err) => {

          this.loader = false;
          if (err?.status !== 401) {
            let errorMessage = 'An error occurred. Please try again later.'
            if (err.error) {
              if (err.error.errors && Object.keys(err.error.errors).length > 0) {
                errorMessage = err.error.errors;
              } else if (err.error.message) {
                errorMessage = err.error.message;
              }
            }
            this.toastr.error(errorMessage, 'Error');
          }
        }
      );
      // Now, pass formData to your API via a service.
    } else {
      this.toastr.error('Please enter all required fields');
      // Mark all controls as touched to trigger validation messages.
      this.updateUserForm.markAllAsTouched();
    }
  }

  updateProfilePic(event: any) {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e: any) => {
        this.profilePic = e.target.result; // Update profile pic preview
        this.isClicked = true; // Set to clicked state
      };
      reader.readAsDataURL(file);
    }
  }

  onFileChangeupdate(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length) {
      const file = input.files[0];
      this.updateUserForm.patchValue({
        image: file
      });

      // Convert the file to base64 for preview
      const reader = new FileReader();
      reader.onload = () => {
        // This will store the Base64 string
        const base64String = reader.result as string;
        this.editimage = base64String;
      };
      // Read the file as a data URL (Base64)
      reader.readAsDataURL(file);
    }
  }

}
