import { Component, Renderer2, HostListener } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent {
  loggedInUser: any;
  loggedInUserData: any;
  loader: boolean = false;
  loginUserDetails: any = ''

  constructor(private renderer: Renderer2, private router: Router, private userService: UserService) {
    this.loggedInUser = localStorage.getItem('loginUser');
    if (this.loggedInUser) {
      this.loggedInUserData = JSON.parse(this.loggedInUser)
      this.userService.userDetails$.subscribe(user => {
        if (user) {
          this.loginUserDetails = user;
        }
      });
      this.getUserDetailById();
    }

  }
  toggleBodyClass(): void {
    const body = document.body;

    if (body.classList.contains('close-sidebar')) {
      this.renderer.removeClass(body, 'close-sidebar');
      this.renderer.addClass(body, 'shift-icon');

    } else {
      this.renderer.addClass(body, 'close-sidebar');
      this.renderer.removeClass(body, 'shift-icon');

    }

    //  if (body.classList.contains('close-sidebar')) { 
    //   this.renderer.removeClass(body, 'close-sidebar'); 
    // } else
    //  { this.renderer.addClass(body, 'close-sidebar'); } 


  }
  @HostListener('window:resize', ['$event'])
  onResize(event?: Event) {
    if (window.innerWidth <= 900) {
      this.renderer.addClass(document.body, 'close-sidebar');
    } else {
      this.renderer.removeClass(document.body, 'close-sidebar');
    }
  }
  ngOnInit() {
    this.onResize();
  }

  logoutUser() {
    localStorage.removeItem('token');
    localStorage.removeItem('loginUser');
    localStorage.removeItem('permissions');
    localStorage.clear()
    this.userService?.resetPermissions();
    this.router.navigate(['login'])
  }

  navigateRoute(path: any) {
    this.router.navigate([path])
  }

  getUserDetailById() {
    this.loader = true;
    this.userService.getStaffById({ id: this.loggedInUserData?.user_id }).subscribe(
      (res: any) => {
        if (res?.status === 200) {
          this.loginUserDetails = res?.data;
          this.userService.updateUserDetails(this.loginUserDetails);
          this.loader = false;
        } else {
          this.loader = false;
        }
      },
      (err) => {
        this.loader = false;
        if (err?.status !== 401) {
          let errorMessage = 'An error occurred. Please try again later.'
          if (err.error) {
            if (err.error.errors && Object.keys(err.error.errors).length > 0) {
              errorMessage = err.error.errors;
            } else if (err.error.message) {
              errorMessage = err.error.message;
            }
          }
        }
      }
    );
  }

}
