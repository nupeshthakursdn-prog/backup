import { Component, OnDestroy, OnInit, TemplateRef } from '@angular/core';
import { AbstractControl, FormArray, FormBuilder, FormGroup, ValidationErrors, ValidatorFn, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Editor } from 'ngx-editor';
import { ToastrService } from 'ngx-toastr';
import { MasterService } from 'src/app/services/master.service';
import { ResumeParseService } from 'src/app/services/resume-parse.service';
import { environment } from 'src/environments/environment';
import * as CryptoJS from 'crypto-js';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Location } from '@angular/common';
import { ImageCroppedEvent } from 'ngx-image-cropper';
@Component({
  selector: 'app-ai-parsed-resume',
  templateUrl: './ai-parsed-resume.component.html',
  styleUrls: ['./ai-parsed-resume.component.scss']
})
export class AIParsedResumeComponent implements OnInit, OnDestroy {
  // editorContent: string = '';
  limit: any = 10
  pageNumber: any = 1
  selectedFileName: string = 'No file chosen';
  editor: Editor = new Editor;
  html = '';
  fileError: any = '';
  userParseData: any;
  loader: boolean = false;
  roleCategoryList: any = [];
  selectedCategory: any = ''
  candidateForm!: FormGroup;
  // years: number[] = Array.from({ length: new Date().getFullYear() - 1990 + 1 }, (_, i) => 1990 + i);
  // currentYear: any = new Date().getFullYear();
  // years: number[] = Array.from({ length: new Date().getFullYear() - 1990 }, (_, i) => 1990 + i);
  currentYear: number = new Date().getFullYear(); // Stores the current year
  //Include current year as well in select
  years: number[] = Array.from({ length: this.currentYear - 1990 + 1 }, (_, i) => 1990 + i);

  candidateCategoryRecord: any;
  technicalProficiencyByRole: any = [];
  formType: any = 'parsing';
  searchText: any = '';
  cognitiveList: any = [];
  availableAssessments: any[] = [];
  candidateImage: string | ArrayBuffer | null = null;
  loginUser: any = '';
  loginUserId: any = '';
  isResumeUploaded: boolean = true;
  encryptionKey: any = environment.encryptionKey;
  submitModalRef: any = '';

  pairingsFields: any = [];
  filteredPairing1: any = []
  filteredPairing2: any = []

  imageChangedEvent: any = '';
  croppedImage: any = '';

  constructor(private modalService: NgbModal, private router: Router, private resumeParseService: ResumeParseService, private toastr: ToastrService,
    private masterService: MasterService, private fb: FormBuilder, private route: ActivatedRoute, private location: Location) {

  }

  initializeForm() {
    this.candidateForm = this.fb.group({
      fullName: ['', [Validators.required, Validators.minLength(3)]],
      roleCategory: ['', [Validators.required]],
      age: ['', [Validators.required, Validators.min(12), Validators.max(100)]],
      noticePeriod: ['', [Validators.required, Validators.min(0), Validators.max(180)]],
      englishEducation: ['', [Validators.required, Validators.min(0), Validators.max(5),this.integerValidator]],
      image: [null],
      keySkills: this.fb.array([this.createKeySkill()]),
      profileSummary: ['', Validators.required],
      workExperience: this.fb.array([], [this.fromYearLessThanToYearValidator()]),
      workStyleScore: [''],
      pairing1: ['', [Validators.required]],
      pairing2: ['', [Validators.required]],
      cognitiveCapability: this.fb.group(this.getCognitiveCapabilityControls()),
      technicalProficiency: this.fb.array([this.createAssessment()]),
      jobRole: ['', [Validators.required, Validators.minLength(3)]],
      proximityToOffice: ['', [Validators.required, Validators.maxLength(1000)]] // Add new field
    });
    this.addWorkExperience();
  }

  integerValidator(control: AbstractControl): ValidationErrors | null {
    const value = control.value;
    if (value !== null && value !== undefined && value !== '') {
      if (!Number.isInteger(+value)) {
        return { notInteger: true };
      }
    }
    return null;
  }

  ngOnInit(): void {

    let loggedInUser = localStorage.getItem('loginUser');
    if (loggedInUser) {
      this.loginUser = JSON.parse(loggedInUser)
      this.loginUserId = this.loginUser?.user_id;
    }

    if (this.route.snapshot.paramMap.get('type')) {
      this.formType = this.route.snapshot.paramMap.get('type');
    }
    this.editor = new Editor();
    this.getCognitiveCapability();
    this.getRolecategoryList();
    this.getGeniusPairingFields();
  }

  updatePairings() {
    const selectedPairing1 = this.candidateForm.get('pairing1')?.value;
    const selectedPairing2 = this.candidateForm.get('pairing2')?.value;

    this.filteredPairing1 = this.pairingsFields.filter((field: any) => field !== selectedPairing2);
    this.filteredPairing2 = this.pairingsFields.filter((field: any) => field !== selectedPairing1);
  }

  getGeniusPairingFields() {
    this.loader = true;
    this.masterService.getGeniusPairingsField().subscribe(
      (res: any) => {
        this.pairingsFields = res?.data?.workstyle_data;
        this.filteredPairing1 = [...this.pairingsFields];
        this.filteredPairing2 = [...this.pairingsFields];
        this.loader = false;
      },
      (err) => {
        this.loader = false;
        if (err?.status !== 401) {
          let errorMessage = 'An error occurred. Please try again later.'
          if (err.error) {
            if (err.error.errors && Object.keys(err.error.errors).length > 0) {
              errorMessage = err.error.errors;
            } else if (err.error.message) {
              errorMessage = err.error.message;
            }
          }
          this.toastr.error(errorMessage, 'Error');
        }
      }
    );
  }

  getRolecategoryList() {
    this.loader = true;
    let queryData = {
      limit: '',
      page: this.pageNumber,
      searchText: ''
    }

    this.masterService.getRoleCategory(queryData).subscribe(
      (res: any) => {
        if (res?.status === 200) {
          this.loader = false;
          this.roleCategoryList = res?.data?.role_categories;
        } else {
          this.loader = false;
          this.roleCategoryList = []
          this.toastr.error(res.message || 'An error occurred. Please try again.', 'Error');
        }
      },
      (err) => {
        this.loader = false;
        if (err?.status !== 401) {
          let errorMessage = 'An error occurred. Please try again later.'
          if (err.error) {
            if (err.error.errors && Object.keys(err.error.errors).length > 0) {
              errorMessage = err.error.errors;
            } else if (err.error.message) {
              errorMessage = err.error.message;
            }
          }
          this.toastr.error(errorMessage, 'Error');
        }
      }
    );
  }

  getCognitiveCapability() {
    this.loader = true
    let queryData = {
      limit: this.limit,
      page: this.pageNumber,
      searchText: this.searchText
    }
    this.masterService.getcognitiveCapability(queryData).subscribe(
      (res: any) => {
        if (res?.status === 200) {
          this.cognitiveList = res?.data?.cognitive_capabilities;
          this.initializeForm();
          this.loader = false
        } else {
          this.loader = false;
          this.cognitiveList = [];
        }
      },
      (err) => {
        this.loader = false;
        if (err?.status !== 401) {
          let errorMessage = 'An error occurred. Please try again later.';
          if (err?.error) {
            if (err?.error?.errors && Object.keys(err?.error?.errors).length > 0) {
              errorMessage = err?.error?.errors;
              this.toastr.error(errorMessage, 'Error');
            } else if (err?.error?.message) {
              errorMessage = err?.error?.message;
              this.toastr.error(errorMessage, 'Error');
            }
          }
          this.toastr.error(errorMessage, 'Error');
        }
      }
    );
  }

  getCognitiveCapabilityControls() {
    let controls: any = {};

    this.cognitiveList.forEach((item: any) => {
      const fieldName = this.getFieldName(item.name);
      controls[fieldName] = ['', [Validators.required, Validators.min(0), Validators.max(100)]];
    })

    return controls;
  }

  // Helper function to generate valid form control names
  getFieldName(name: string): string {
    return name
      .toLowerCase() // Convert to lowercase
      .replace(/[^a-z\s]/g, '') // Remove non-alphabetic characters
      .split(' ') // Split words
      .map((word, index) => index === 0 ? word : word.charAt(0).toUpperCase() + word.slice(1)) // Convert to camelCase
      .join('');
  }

  createKeySkill(): FormGroup {
    return this.fb.group({
      key_skill: ['', Validators.required]
    });
  }

  // Getter to easily access the keySkills FormArray from the candidateForm
  get keySkills(): FormArray {
    return this.candidateForm.get('keySkills') as FormArray;
  }

  // Method to add a new key skill entry
  addKeySkill() {
    if (this.keySkills.length < 8) {
      this.keySkills.push(this.createKeySkill());
    }
  }

  // Method to remove a key skill entry; keeping at least one entry in the array
  removeKeySkill(index: number) {
    if (this.keySkills.length > 1) {
      this.keySkills.removeAt(index);
    }
  }

  //Upload Resume Functionality
  onResumeSelected(event: any) {
    this.loader = true;
    const file = event.target.files[0];

    if (!file) return;

    const allowedExtensions = ['pdf', 'docx'];
    const fileExtension = file.name.split('.').pop()?.toLowerCase();

    if (!allowedExtensions.includes(fileExtension || '')) {
      this.loader = false;
      this.fileError = 'Only PDF and DOCX files are allowed.';
      return;
    }

    this.fileError = '';
    this.uploadFile(file);
  }

  // Upload Image

  uploadFile(file: File) {

    this.candidateForm.reset();
    this.loader = true;
    const formData = new FormData();
    formData.append('file', file);

    this.resumeParseService.getResumeParseData(formData).subscribe(
      (res: any) => {
        if (res?.status === 200) {
          this.loader = false;
          this.isResumeUploaded = false;
          this.userParseData = res?.data

          const errorIdentifier = "not accessible or extractable";
          if (typeof this.userParseData === 'string' && this.userParseData.toLowerCase().includes(errorIdentifier.toLowerCase())) {
            this.toastr.error('The resume you uploaded is in an unsupported format and its data cannot be parsed. Please upload a valid resume.');
          } else {
            this.toastr.success(res.message, 'Success');
            this.candidateCategoryRecord = this.roleCategoryList?.find(
              (item: any) => item?.name?.trim()?.toLowerCase() === this.userParseData?.Category?.trim()?.toLowerCase()
            );

            if (this.candidateCategoryRecord?.id) {
              this.getTechnicalProficiencyByRole();
            }

            this.candidateForm.patchValue({
              fullName: this.userParseData?.Name && this.userParseData?.Name !== 'N/A' ? this.userParseData?.Name : '',
              roleCategory: this.candidateCategoryRecord?.id || '',
              age: this.userParseData?.Age && this.userParseData?.Age !== 'N/A' ? this.userParseData?.Age : '',
              noticePeriod: this.userParseData?.Notice_Period && this.userParseData?.Notice_Period !== 'N/A' ? this.userParseData?.Notice_Period : '',
              // englishEducation: this.userParseData?.English_Rating && this.userParseData?.English_Rating !== 'N/A' ? this.userParseData?.English_Rating : '',
              profileSummary: this.userParseData?.Profile_Summary && this.userParseData?.Profile_Summary !== 'N/A' ? this.userParseData?.Profile_Summary : '',
              jobRole: this.userParseData?.Role && this.userParseData?.Role !== 'N/A' ? this.userParseData?.Role : '',
            });

            // KeySkills Patch (Restrict to 8)
            if (this.userParseData?.Key_Skills?.length > 0) {
              this.keySkills.clear();
              this.userParseData.Key_Skills.slice(0, 8).forEach((skill: any) => {
                this.keySkills.push(
                  this.fb.group({
                    key_skill: [skill || '', Validators.required],
                  })
                );
              });
            }

            // Work_Experience Patch
            // if (this.userParseData?.Work_Experience?.length > 0) {
            //   // Clear the default empty field before adding new data
            //   this.workExperience.clear();
            //   this.userParseData.Work_Experience.forEach((experience: any) => {
            //     this.workExperience.push(
            //       this.fb.group({
            //         designation: [experience.Designation && experience.Designation !== 'N/A' ? experience.Designation : '', Validators.required],
            //         company_name: [experience.Company_Name && experience.Company_Name !== 'N/A' ? experience.Company_Name : '', Validators.required],
            //         from_year: [experience.From_Year && experience.From_Year !== 'N/A' ? experience.From_Year : '', Validators.required],
            //         to_year: [
            //           experience.To_Year === 'Present'
            //             ? this.currentYear
            //             : experience.To_Year && experience.To_Year !== 'N/A'
            //               ? experience.To_Year
            //               : '',
            //           Validators.required
            //         ]
            //       },
            //         { validators: this.fromYearLessThanToYearValidator() })
            //     );
            //   });
            // }

            if (this.userParseData?.Work_Experience?.length > 0) {
              // Clear the default empty field before adding new data
              this.workExperience.clear();

              // Sort work experiences in descending order (latest year first)
              this.userParseData.Work_Experience.sort((a: any, b: any) => {
                const fromYearA = a.From_Year === 'N/A' ? 0 : parseInt(a.From_Year, 10);
                const fromYearB = b.From_Year === 'N/A' ? 0 : parseInt(b.From_Year, 10);

                const toYearA = a.To_Year === 'Present' ? new Date().getFullYear() : (a.To_Year === 'N/A' ? 0 : parseInt(a.To_Year, 10));
                const toYearB = b.To_Year === 'Present' ? new Date().getFullYear() : (b.To_Year === 'N/A' ? 0 : parseInt(b.To_Year, 10));

                // First, sort by to_year in descending order
                if (toYearB !== toYearA) {
                  return toYearB - toYearA;
                }

                // If to_year is the same, sort by from_year in descending order
                return fromYearB - fromYearA;
              });

              // Iterate over the sorted array
              this.userParseData.Work_Experience.forEach((experience: any) => {
                this.workExperience.push(
                  this.fb.group({
                    designation: [experience.Designation && experience.Designation !== 'N/A' ? experience.Designation : '', Validators.required],
                    company_name: [experience.Company_Name && experience.Company_Name !== 'N/A' ? experience.Company_Name : '', Validators.required],
                    from_year: [experience.From_Year && experience.From_Year !== 'N/A' ? experience.From_Year : '', Validators.required],
                    to_year: [
                      experience.To_Year === 'Present'
                        ? this.currentYear
                        : experience.To_Year && experience.To_Year !== 'N/A'
                          ? experience.To_Year
                          : '',
                      Validators.required
                    ]
                  },
                    { validators: this.fromYearLessThanToYearValidator() })
                );
              });
            }


          }
        } else {
          this.loader = false;
          this.userParseData = ''
        }
      },
      (err) => {
        this.loader = false;
        let errorMessage = 'An error occurred. Please try again later.'
        if (err.error) {
          if (err.error.errors && Object.keys(err.error.errors).length > 0) {
            errorMessage = err.error.errors;
          } else if (err.error.message) {
            errorMessage = err.error.message;
          }
        }
        this.toastr.error(errorMessage);
      }
    );
  }


  // workExperience form array functionality

  get workExperience(): FormArray {
    return this.candidateForm.get('workExperience') as FormArray;
  }

  // Add New Work Experience Row
  addWorkExperience() {
    this.workExperience.push(
      this.fb.group({
        designation: ['', Validators.required],
        company_name: ['', Validators.required],
        from_year: ['', Validators.required],
        to_year: ['', Validators.required]
      },
        { validators: this.fromYearLessThanToYearValidator() })
    );
  }

  // Remove Work Experience Row
  removeWorkExperience(index: number) {
    this.workExperience.removeAt(index);
  }

  // Technical Proficiency Score form array functionality

  get technicalProficiency(): FormArray {
    return this.candidateForm.get('technicalProficiency') as FormArray;
  }

  createAssessment(): FormGroup {
    const group = this.fb.group({
      selectAssessment: ['', Validators.required],
      assessmentUrl: ['', [Validators.required, Validators.pattern('https?://.+')]],
      score: ['', [Validators.required, Validators.min(0), Validators.max(100)]]
    });

    // Subscribe to changes in the selectAssessment control
    group.get('selectAssessment')?.valueChanges.subscribe(selectedName => {
      // Look for the assessment in availableAssessments
      const selectedAssessment = this.availableAssessments.find(
        (item: any) => item.name_of_proficiency === selectedName
      );
      if (selectedAssessment) {
        // Patch the assessmentUrl with the URL from the selected assessment
        group.patchValue({ assessmentUrl: selectedAssessment.assessment_url });
      } else {
        // Clear the assessmentUrl if no matching assessment is found
        group.patchValue({ assessmentUrl: '' });
      }
    });

    return group;
  }


  addAssessment(): void {
    this.technicalProficiency.push(this.createAssessment());
  }

  removeAssessment(index: number): void {
    this.technicalProficiency.removeAt(index);
  }

  getTechnicalProficiencyByRole() {
    this.loader = true
    let queryData = {
      role_category_id: this.candidateCategoryRecord?.id,
    }
    this.resumeParseService.getTechnicalProficiencyByRoleCategory(queryData).subscribe(
      (res: any) => {
        if (res?.status === 200) {
          this.loader = false
          this.technicalProficiencyByRole = res?.data?.technical_proficiencies;

          const techArray = this.candidateForm.get('technicalProficiency') as FormArray;
          techArray.controls.forEach((group: any) => {
            group.patchValue({
              assessmentUrl: '',
            });
          });

          this.availableAssessments = this.technicalProficiencyByRole || [];

          // this.technicalProficiency.clear();
          // this.technicalProficiencyByRole.forEach((item: any) => {
          //   this.technicalProficiency.push(
          //     this.fb.group({
          //       selectAssessment: [item?.name_of_proficiency || '', Validators.required],
          //       assessmentUrl: [item?.assessment_url || '', [Validators.required, Validators.pattern('https?://.+')]],
          //       score: [item?.score || '', [Validators.required, Validators.min(0), Validators.max(100)]]
          //     })
          //   );
          // });
        } else {
          this.loader = false
          this.technicalProficiencyByRole = []
        }
      },
      (err) => {
        this.loader = false
        if (err?.status !== 401) {
          let errorMessage = 'An error occurred. Please try again later.'
          if (err.error) {
            if (err.error.errors && Object.keys(err.error.errors).length > 0) {
              errorMessage = err.error.errors;
            } else if (err.error.message) {
              errorMessage = err.error.message;
            }
          }
          this.toastr.error(errorMessage);
        }
      }
    );
  }

  // Form Submission

  onSubmit() {
    // this.router.navigate(['resume-template'])
    if (this.candidateForm.valid) {
      this.loader = true
      const formData = new FormData();
      formData.append('full_name', this.candidateForm.value.fullName);
      // formData.append('email', "admin@gmail.com");
      formData.append('role_category_id', this.candidateForm.value.roleCategory);
      formData.append('type', this.formType);
      formData.append('phone_number', this.candidateForm.value.phone_number);
      formData.append('role', "");
      formData.append('pairing1', this.candidateForm.value.pairing1);
      formData.append('pairing2', this.candidateForm.value.pairing2);
      formData.append('profile_summary', this.candidateForm.value.profileSummary);
      formData.append('age', this.candidateForm.value.age);
      formData.append('rating', this.candidateForm.value.englishEducation);
      formData.append('notice_period', this.candidateForm.value.noticePeriod);
      formData.append('work_experience', JSON.stringify(this.candidateForm.value.workExperience));
      formData.append('job_role', this.candidateForm.value.jobRole.toLowerCase());
      formData.append('key_skills', JSON.stringify(this.candidateForm.value.keySkills));
      formData.append('createdBy', this.loginUserId);
      formData.append('cognitive_capability_score', JSON.stringify(this.candidateForm.value.cognitiveCapability));
      formData.append('technical_proficiency_scores', JSON.stringify(this.candidateForm.value.technicalProficiency));
      formData.append('proximity_to_office', this.candidateForm.value.proximityToOffice); // Add new field

      if (this.candidateForm.value.image) {
        formData.append('image', this.candidateForm.value.image);
      }
      this.resumeParseService.addCandidate(formData).subscribe(
        (res: any) => {

          if (res?.status === 200) {
            this.loader = false
            this.toastr.success(res.message, 'Success');
            // this.router.navigate(['candidate-profile-creation'])
            this.redirectToResumeTemplate(res?.data?.id)
            this.candidateForm.reset();
          } else {
            this.loader = false;
            this.toastr.error(res.message || 'An error occurred. Please try again.', 'Error');
          }
        },
        (err) => {
          this.loader = false;
          let errorMessage = 'An error occurred. Please try again later.'
          if (err.error) {

            if (err.error.errors && Object.keys(err.error.errors).length > 0) {
              // for (let field in err.error.errors) {
              //   if (err.error.errors.hasOwnProperty(field)) {
              //     this.toastr.error(err.error.errors[field]);
              //   }
              // }
              errorMessage = err.error.errors;
              this.toastr.error(errorMessage);
            } else if (err.error.message) {
              errorMessage = err.error.message;
              this.toastr.error(errorMessage);
            }
          }
        }
      );

    } else {
      this.candidateForm.markAllAsTouched(); // Force validation messages to appear
      this.toastr.error("Please fill all the required fields.");
      return;
    }
  }

  onFileChange(event: Event): void {
    this.imageChangedEvent = event; // Pass the event to the cropper
  }

  imageCropped(event: ImageCroppedEvent): void {
    this.croppedImage = event.base64; // Store base64 for preview

    // Convert Base64 to File
    const timestamp = new Date().getTime(); // Get current timestamp
    this.convertBase64ToFile(event.base64, `cropped-image-${timestamp}.png`);
  }


  imageLoaded() {
    console.log("Image loaded successfully!");
  }

  loadImageFailed() {
    console.error("Image loading failed!");
  }

  confirmCrop(): void {
    if (this.candidateForm.valid) {
      const formData = new FormData();
      formData.append("image", this.candidateForm.get('image')?.value);
    }
  }


  onImageUpload(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length) {
      const file = input.files[0];

      // Patch the file into the form control
      this.candidateForm.patchValue({
        image: file
      });
      this.candidateForm.get('image')?.updateValueAndValidity();

      // Create a FileReader to generate a preview URL
      const reader = new FileReader();
      reader.onload = () => {
        this.candidateImage = reader.result;
      };
      reader.readAsDataURL(file);
    }
  }


  triggerFileInput(): void {
    const fileInput = document.getElementById('fileInput') as HTMLInputElement;
    fileInput.click();
  }

  // make sure to destory the editor
  ngOnDestroy(): void {
    this.editor.destroy();
  }
  navigateTo(routePath: any) {
    this.router.navigate([routePath])
  }

  onCategoryChange(event: any): void {
    const selectedCategoryId = event?.value;
    if (!selectedCategoryId) return;
    this.candidateCategoryRecord = this.roleCategoryList.find(
      (category: any) => category?.id === selectedCategoryId
    ) || null;

    if (this.candidateCategoryRecord?.id) {
      this.getTechnicalProficiencyByRole();
    }
  }


  fromYearLessThanToYearValidator(): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      const fromYear = control.get('from_year')?.value;
      const toYear = control.get('to_year')?.value;

      // If both values are present and from_year is greater than to_year, return an error.
      if (fromYear && toYear && fromYear > toYear) {
        return { fromYearGreaterThanToYear: true };
      }
      return null;
    };
  }

  redirectToResumeTemplate(candidateId: any) {
    const encryptedId = CryptoJS.AES.encrypt(candidateId.toString(), this.encryptionKey).toString();
    const safeEncryptedId = encodeURIComponent(encryptedId);
    if (safeEncryptedId) {
      this.router.navigate([`candidate-profile-builder/${safeEncryptedId}`])
    }
  }

  removeImage(fileInput: any) {
    this.candidateImage = null;
    this.croppedImage = null;
    fileInput.value = "";
    this.imageChangedEvent = ''
  }

  validateAndConfirm(submitForm: TemplateRef<any>) {
    if (this.candidateForm.invalid) {
      this.candidateForm.markAllAsTouched(); // Show validation errors
      this.toastr.error("Please fill all the required fields.");
      return;
    }

    // If form is valid, open the confirmation popup
    this.submitModalRef = this.modalService.open(submitForm, {
      centered: true,
      size: 'md',
      windowClass: 'master_modal add_content',
    });
  }

  confirmSubmit() {
    this.submitModalRef.close(); // Close modal
    this.onSubmit(); // Call API after confirmation
  }

  goBack(): void {
    this.location.back();
  }

  convertBase64ToFile(base64: any, filename: string) {
    const arr = base64.split(',');
    const mime = arr[0].match(/:(.*?);/)?.[1];
    const bstr = atob(arr[1]);
    let n = bstr.length;
    const u8arr = new Uint8Array(n);

    while (n--) {
      u8arr[n] = bstr.charCodeAt(n);
    }

    const file = new File([u8arr], filename, { type: mime });

    // Patch the file into FormGroup
    this.candidateForm.patchValue({
      image: file
    });
    this.candidateForm.get('image')?.updateValueAndValidity();
  }

  saveAsDraft() {
    this.loader = true;
  
    const fullName = this.candidateForm.value.fullName;
    const roleCategory = this.candidateForm.value.roleCategory;
  
    // Validation: Ensure required fields are filled
    if (!fullName || !roleCategory) {
      this.loader = false;
      this.toastr.error('Full Name and Role Category are required to save as draft.');
      return;
    }
  
    const formData = new FormData();
    formData.append('full_name', fullName);
    formData.append('role_category_id', roleCategory);
    formData.append('type', this.formType);
    formData.append('phone_number', this.candidateForm.value.phone_number || '');
    formData.append('role', '');
    formData.append('pairing1', this.candidateForm.value.pairing1 || '');
    formData.append('pairing2', this.candidateForm.value.pairing2 || '');
    formData.append('profile_summary', this.candidateForm.value.profileSummary || '');
    formData.append('age', this.candidateForm.value.age || '');
    formData.append('rating', this.candidateForm.value.englishEducation ? this.candidateForm.value.englishEducation : '');
    formData.append('notice_period', this.candidateForm.value.noticePeriod || '');
    formData.append('work_experience', JSON.stringify(this.candidateForm.value.workExperience || []));
    formData.append('job_role', this.candidateForm.value.jobRole ? this.candidateForm.value.jobRole.toLowerCase() : '');
    formData.append('key_skills', JSON.stringify(this.candidateForm.value.keySkills || []));
    formData.append('createdBy', this.loginUserId);
    formData.append('cognitive_capability_score', JSON.stringify(this.candidateForm.value.cognitiveCapability || {}));
    formData.append('technical_proficiency_scores', JSON.stringify(this.candidateForm.value.technicalProficiency || {}));
    formData.append('proximity_to_office', this.candidateForm.value.proximityToOffice); // Add new field
    formData.append('is_draft', 'true'); // Marking it as a draft
  
    if (this.candidateForm.value.image) {
      formData.append('image', this.candidateForm.value.image);
    }
  
    this.resumeParseService.addCandidate(formData).subscribe(
      (res: any) => {
        this.loader = false;
        if (res?.status === 200) {
          this.toastr.success('Saved as Draft successfully!', 'Success');
          this.router.navigate(['/candidate-profile-creation'], { queryParams: { status: 'drafts' } });
        } else {
          this.toastr.error(res.message || 'An error occurred. Please try again.', 'Error');
        }
      },
      (err) => {
        this.loader = false;
        let errorMessage = 'An error occurred. Please try again later.';
        if (err.error) {
          if (err.error.errors && Object.keys(err.error.errors).length > 0) {
            errorMessage = err.error.errors;
          } else if (err.error.message) {
            errorMessage = err.error.message;
          }
        }
        console.log(errorMessage,"ERROR MESSAGE=====>>")
        this.toastr.error(errorMessage);
      }
    );
  }

  // if while saving as draft, the form is completely filled then 
  // saveAsDraft() {
  //   this.loader = true;
  
  //   const fullName = this.candidateForm.value.fullName;
  //   const roleCategory = this.candidateForm.value.roleCategory;
  
  //   // Minimal validation for draft saving
  //   if (!fullName || !roleCategory) {
  //     this.loader = false;
  //     this.toastr.error('Full Name and Role Category are required to save as draft.');
  //     return;
  //   }
  
  //   const formData = new FormData();
  //   formData.append('full_name', fullName);
  //   formData.append('role_category_id', roleCategory);
  //   formData.append('type', this.formType);
  //   formData.append('phone_number', this.candidateForm.value.phone_number || '');
  //   formData.append('role', '');
  //   formData.append('pairing1', this.candidateForm.value.pairing1 || '');
  //   formData.append('pairing2', this.candidateForm.value.pairing2 || '');
  //   formData.append('profile_summary', this.candidateForm.value.profileSummary || '');
  //   formData.append('age', this.candidateForm.value.age || '');
  //   formData.append('rating', this.candidateForm.value.englishEducation ? this.candidateForm.value.englishEducation : '');
  //   formData.append('notice_period', this.candidateForm.value.noticePeriod || '');
  //   formData.append('work_experience', JSON.stringify(this.candidateForm.value.workExperience || []));
  //   formData.append('job_role', this.candidateForm.value.jobRole ? this.candidateForm.value.jobRole.toLowerCase() : '');
  //   formData.append('key_skills', JSON.stringify(this.candidateForm.value.keySkills || []));
  //   formData.append('createdBy', this.loginUserId);
  //   formData.append('cognitive_capability_score', JSON.stringify(this.candidateForm.value.cognitiveCapability || {}));
  //   formData.append('technical_proficiency_scores', JSON.stringify(this.candidateForm.value.technicalProficiency || {}));
  
  //   const isComplete = this.candidateForm.valid;
  //   console.log(isComplete,"IS_COMPLETED")
  //   formData.append('is_draft', isComplete ? 'false' : 'true');
  
  //   if (this.candidateForm.value.image) {
  //     formData.append('image', this.candidateForm.value.image);
  //   }
  
  //   this.resumeParseService.addCandidate(formData).subscribe(
  //     (res: any) => {
  //       this.loader = false;
  //       if (res?.status === 200) {
  //         if (isComplete) {
  //           console.log(isComplete,"IS_COMPLETED")
  //           this.toastr.success('Profile saved successfully!', 'Success');
  //           this.redirectToResumeTemplate(res?.data?.id); // triggers PDF generation
  //         } else {
  //           console.log("INSIDE ELSE DRAFT ")
  //           this.toastr.success('Saved as Draft successfully!', 'Success');
  //           this.router.navigate(['/candidate-profile-creation'], { queryParams: { status: 'drafts' } });
  //         }
  //       } else {
  //         this.toastr.error(res.message || 'An error occurred. Please try again.', 'Error');
  //       }
  //     },
  //     (err) => {
  //       this.loader = false;
  //       let errorMessage = 'An error occurred. Please try again later.';
  //       if (err.error) {
  //         if (err.error.errors && Object.keys(err.error.errors).length > 0) {
  //           errorMessage = err.error.errors;
  //         } else if (err.error.message) {
  //           errorMessage = err.error.message;
  //         }
  //       }
  //       this.toastr.error(errorMessage);
  //     }
  //   );
  // }
  
}
