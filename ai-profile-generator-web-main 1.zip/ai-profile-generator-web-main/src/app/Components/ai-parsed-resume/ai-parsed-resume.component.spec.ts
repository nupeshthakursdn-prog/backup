import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AIParsedResumeComponent } from './ai-parsed-resume.component';

describe('AIParsedResumeComponent', () => {
  let component: AIParsedResumeComponent;
  let fixture: ComponentFixture<AIParsedResumeComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AIParsedResumeComponent]
    });
    fixture = TestBed.createComponent(AIParsedResumeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
