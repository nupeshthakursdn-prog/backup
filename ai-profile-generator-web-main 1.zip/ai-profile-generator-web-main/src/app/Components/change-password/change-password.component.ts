import { Component } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { AbstractControl, FormBuilder, FormGroup, ValidationErrors, ValidatorFn, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { MasterService } from 'src/app/services/master.service';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.scss']
})

export class ChangePasswordComponent {
  hide = true;  // For toggling password visibility
  changePasswordForm: FormGroup;
  loader: boolean = false;
  loggedInUserData: any;
  loggedInUserId: any;

  constructor(private fb: FormBuilder, private userService: UserService, private toastr: ToastrService) {
    this.changePasswordForm = this.fb.group({
      currentPassword: ['', [Validators.required]],
      newPassword: [
        '',
        [
          Validators.required,
          Validators.minLength(8),
          Validators.pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{8,}$/)
        ]
      ],
      confirmPassword: [
        '',
        [
          Validators.required,
          this.matchPassword('newPassword')
        ]
      ],
    });
  }


  ngOnInit(): void {
    let loggedInUser = localStorage.getItem('loginUser');
    if (loggedInUser) {
      this.loggedInUserData = JSON.parse(loggedInUser)
      this.loggedInUserId = this.loggedInUserData?.user_id;
    }
  }

  get currentPasswordControl() {
    return this.changePasswordForm.get('currentPassword');
  }

  get newPasswordControl() {
    return this.changePasswordForm.get('newPassword');
  }

  get confirmPasswordControl() {
    return this.changePasswordForm.get('confirmPassword');
  }

  matchPassword(controlName: string): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      const formGroup = control.parent;
      if (formGroup) {
        const password = formGroup.get(controlName)?.value;
        const confirmPassword = control.value;
        return password && confirmPassword && password !== confirmPassword
          ? { passwordMismatch: true }
          : null;
      }
      return null;
    };
  }

  onSubmit(): void {

    if (this.changePasswordForm.valid) {
      this.loader = true
      const { currentPassword, newPassword, confirmPassword } = this.changePasswordForm.value;

      let data = {
        old_password: currentPassword,
        new_password: newPassword,
        confirm_password: confirmPassword,
        loggedInUserId: this.loggedInUserId
      }

      this.userService.changePassword(data).subscribe(
        (res: any) => {
          if (res?.status === 200) {
            this.loader = false
            this.toastr.success(res.message, 'Success');
            this.changePasswordForm.reset();
          } else {
            this.loader = false;
            this.toastr.error(res.message || 'An error occurred. Please try again.', 'Error');
          }
        },
        (err) => {
          this.loader = false;
          if (err?.status !== 401) {
            let errorMessage = 'An error occurred. Please try again later.'
            if (err.error) {
              if (err.error.errors && Object.keys(err.error.errors).length > 0) {
                for (let field in err.error.errors) {
                  if (err.error.errors.hasOwnProperty(field)) {
                    this.toastr.error(err.error.errors[field]);
                  }
                }
                errorMessage = err.error.errors;
              } else if (err.error.message) {
                errorMessage = err.error.message;
                this.toastr.error(errorMessage);
              }
            }
          }
        }
      );
      // Now, pass formData to your API via a service.
    } else {
      this.toastr.error('Please enter all required fields');
      // Mark all controls as touched to trigger validation messages.
      this.changePasswordForm.markAllAsTouched();
    }
  }

}
