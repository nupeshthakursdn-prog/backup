import { Component } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
// import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ChangeDetectionStrategy, inject } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { UserService } from 'src/app/services/user.service';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { MasterService } from 'src/app/services/master.service';
// import { CreateRoleComponent } from './create-role/create-role.component';
interface Food {
  value: string;
  viewValue: string;
}


export interface PeriodicElement {
  roleCategory: string;
  genius: string;
  competency: string;
  frustration: string;

}
const ELEMENT_DATA: PeriodicElement[] = [
  {
    roleCategory: 'graphic design & web development',
    genius: 'Tenacity, Discernment',
    competency: 'Galvanizing, Enablement',
    frustration: 'Wonder, Invention'
  },
  {
    roleCategory: 'Virtual Assistance & Admin',
    genius: 'Enablement, Galvanizing',
    competency: 'Discernment, Tenacity, Invention',
    frustration: 'Wonder'
  },
];

@Component({
  selector: 'app-work-style-managemnt',
  templateUrl: './work-style-managemnt.component.html',
  styleUrls: ['./work-style-managemnt.component.scss']
})
export class WorkStyleManagemntComponent {
  foods: Food[] = [
    { value: 'steak-0', viewValue: 'Steak' },
    { value: 'pizza-1', viewValue: 'Pizza' },
    { value: 'tacos-2', viewValue: 'Tacos' },
  ];

  loader: boolean = false
  limit: any = 10
  pageNumber: any = 1
  totalLength: any = 0
  searchText: any = ''

  displayedColumns: string[] = ['roleCategory', 'genius', 'competency', 'frustration', 'actions'];
  dataSource = ELEMENT_DATA;
  workingStyleList: any = []

  roleCategoryList: any = [];
  workStyleForm: FormGroup;
  workStyleUpdateForm: FormGroup;
  selectedWorkingStyleId: any = '';

  isAddForm: boolean = true;

  constructor(private fb: FormBuilder, private modalService: NgbModal, public dialog: MatDialog,
    private userService: UserService, private router: Router, private toastr: ToastrService, private masterService: MasterService) {

    this.workStyleForm = new FormGroup({
      roleCategory: new FormControl('', Validators.required),
      genius: new FormArray([new FormControl('', Validators.required)]),  // Default value for genius
      competency: new FormArray([new FormControl('', Validators.required)]),  // Default value for competency
      frustration: new FormArray([new FormControl('', Validators.required)])  // Default value for frustration
    });

    this.workStyleUpdateForm = new FormGroup({
      roleCategory: new FormControl('', Validators.required),
      genius: new FormArray([new FormControl('', Validators.required)]),  // Default value for genius
      competency: new FormArray([new FormControl('', Validators.required)]),  // Default value for competency
      frustration: new FormArray([new FormControl('', Validators.required)])  // Default value for frustration
    });

  }

  ngOnInit(): void {
    this.getWorkingStyleList();
    this.getRolecategoryList();
  }

  getRolecategoryList() {
    this.loader = true;
    let queryData = {
      limit: '',
      page: this.pageNumber,
      searchText: this.searchText
    }

    this.masterService.getRoleCategory(queryData).subscribe(
      (res: any) => {
        if (res?.status === 200) {
          this.loader = false;
          this.roleCategoryList = res?.data?.role_categories;
        } else {
          this.loader = false;
          this.roleCategoryList = []
          this.toastr.error(res.message || 'An error occurred. Please try again.', 'Error');
        }
      },
      (err) => {
        this.loader = false;
        let errorMessage = 'An error occurred. Please try again later.'
        if (err.error) {
          if (err.error.errors && Object.keys(err.error.errors).length > 0) {
            errorMessage = err.error.errors;
          } else if (err.error.message) {
            errorMessage = err.error.message;
          }
        }
        this.toastr.error(errorMessage, 'Error');
      }
    );
  }


  get genius(): FormArray {
    if (this.isAddForm) {
      return this.workStyleForm.get('genius') as FormArray;
    } else {
      return this.workStyleUpdateForm.get('genius') as FormArray;
    }
  }

  get competency(): FormArray {
    if (this.isAddForm) {
      return this.workStyleForm.get('competency') as FormArray;
    } else {
      return this.workStyleUpdateForm.get('competency') as FormArray;
    }
  }

  get frustration(): FormArray {
    if (this.isAddForm) {
      return this.workStyleForm.get('frustration') as FormArray;
    } else {
      return this.workStyleUpdateForm.get('frustration') as FormArray;
    }
  }

  addGeniusField(): void {
    this.genius.push(new FormControl('', Validators.required));
  }

  removeGeniusField(index: number): void {
    if (this.genius.length > 1) {
      this.genius.removeAt(index);
    }
  }

  addCompetencyField(): void {
    this.competency.push(new FormControl('', Validators.required));
  }

  removeCompetencyField(index: number): void {
    if (this.competency.length > 1) {
      this.competency.removeAt(index);
    }
  }


  addFrustrationField(): void {
    this.frustration.push(new FormControl('', Validators.required));
  }

  removeFrustrationField(index: number): void {
    if (this.frustration.length > 1) {
      this.frustration.removeAt(index);
    }
  }

  getWorkingStyleList() {
    this.loader = true;
    let queryData = {
      limit: this.limit,
      page: this.pageNumber,
      searchText: this.searchText,
    }
    this.masterService.getWorkingStyles(queryData).subscribe(
      (res: any) => {
        if (res?.status === 200) {
          this.loader = false;
          this.workingStyleList = res?.data?.work_styles;
          this.totalLength = res?.data?.pagination?.total;
        } else {
          this.workingStyleList = []
          this.loader = false;
        }
      },
      (err) => {
        this.loader = false;
        if (err?.status !== 401) {
          let errorMessage = 'An error occurred. Please try again later.'
          if (err.error) {
            if (err.error.errors && Object.keys(err.error.errors).length > 0) {
              errorMessage = err.error.errors;
            } else if (err.error.message) {
              errorMessage = err.error.message;
            }
          }
        }
      }
    );
  }

  getWorkingStyleById() {
    this.loader = true;
    this.masterService.getWorkingStyleById({ id: this.selectedWorkingStyleId }).subscribe(
      (res: any) => {
        if (res?.status === 200) {
          // Patch role category
          this.workStyleUpdateForm.patchValue({
            roleCategory: res?.data?.role_category?.id,
          });

          // Clear form arrays before adding new values
          this.clearFormArray(this.genius);
          this.clearFormArray(this.competency);
          this.clearFormArray(this.frustration);


          // Patch values for genius
          if (res?.data?.genius && res?.data?.genius.length > 0) {

            res?.data?.genius.forEach((item: any) => {
              this.genius.push(new FormControl(item, Validators.required));
            });
          } else {
            this.genius.push(this.fb.control('', Validators.required));  // Add empty control if no values
          }

          // Patch values for competency
          if (res?.data?.competency && res?.data?.competency.length > 0) {
            res?.data?.competency.forEach((item: any) => {
              this.competency.push(new FormControl(item, Validators.required));
            });
          } else {
            this.competency.push(this.fb.control('', Validators.required));  // Add empty control if no values
          }

          // Patch values for frustration
          if (res?.data?.frustration && res?.data?.frustration.length > 0) {
            res?.data?.frustration.forEach((item: any) => {
              this.frustration.push(new FormControl(item, Validators.required));
            });
          } else {
            this.frustration.push(this.fb.control('', Validators.required));  // Add empty control if no values
          }
          this.loader = false;
        } else {
          this.loader = false;
          this.toastr.error(res?.message || 'An error occurred. Please try again.', 'Error');
        }
      },
      (err) => {
        this.loader = false;
        if (err?.status !== 401) {
          let errorMessage = 'An error occurred. Please try again later.';
          if (err.error) {
            if (err.error.errors && Object.keys(err.error.errors).length > 0) {
              errorMessage = err.error.errors;
            } else if (err.error.message) {
              errorMessage = err.error.message;
            }
          }
          this.toastr.error(errorMessage, 'Error');
        }
      }
    );
  }
  clearFormArray(formArray: FormArray) {
    while (formArray.length !== 0) {
      formArray.removeAt(0);
    }
  }

  onSubmit(): void {
    if (this.workStyleForm.valid) {
      this.loader = true
      const { roleCategory, frustration, genius, competency } = this.workStyleForm.value

      const data = {
        role_category_id: roleCategory,
        frustration: frustration,
        competency: competency,
        genius: genius,
      };
      this.masterService.addWorkingStyle(data).subscribe(
        (res: any) => {
          if (res?.status === 200) {
            this.loader = false
            this.toastr.success(res.message, 'Success');
            this.modalService.dismissAll();
            this.workStyleForm.reset();
            this.genius.clear();
            this.frustration.clear();
            this.competency.clear();
            this.addCompetencyField();
            this.addFrustrationField();
            this.addGeniusField();
            this.getWorkingStyleList();
          } else {
            this.loader = false;
            this.toastr.error(res.message || 'An error occurred. Please try again.', 'Error');
          }
        },
        (err) => {
          this.loader = false;
          if (err?.status !== 401) {
            let errorMessage = 'An error occurred. Please try again later.'
            if (err.error) {
              if (err.error.errors && Object.keys(err.error.errors).length > 0) {
                for (let field in err.error.errors) {
                  if (err.error.errors.hasOwnProperty(field)) {
                    this.toastr.error(err.error.errors[field]);
                  }
                }
                errorMessage = err.error.errors;
              } else if (err.error.message) {
                errorMessage = err.error.message;
                this.toastr.error(errorMessage, 'Error');
              }
            }
          }
        }
      );
    } else {
      this.workStyleForm.markAllAsTouched();
      this.toastr.error('Please select all required fields');
    }
  }

  onSubmitUpdate(): void {

    if (this.workStyleUpdateForm.valid && this.selectedWorkingStyleId) {
      this.loader = true
      const { roleCategory, frustration, genius, competency } = this.workStyleUpdateForm.value

      const data = {
        role_category_id: roleCategory,
        frustration: frustration,
        competency: competency,
        genius: genius,
        work_style_id: this.selectedWorkingStyleId
      };

      this.masterService.updateWorkingStyle(data).subscribe(
        (res: any) => {
          if (res?.status === 200) {
            this.loader = false
            this.toastr.success(res.message, 'Success');
            this.modalService.dismissAll();
            this.getWorkingStyleList();
          } else {
            this.loader = false;
            this.toastr.error(res.message || 'An error occurred. Please try again.', 'Error');
          }
        },
        (err) => {
          this.loader = false;
          if (err?.status !== 401) {
            let errorMessage = 'An error occurred. Please try again later.'
            if (err.error) {
              if (err.error.errors && Object.keys(err.error.errors).length > 0) {
                for (let field in err.error.errors) {
                  if (err.error.errors.hasOwnProperty(field)) {
                    this.toastr.error(err.error.errors[field]);
                  }
                }
                errorMessage = err.error.errors;
              } else if (err.error.message) {
                errorMessage = err.error.message;
                this.toastr.error(errorMessage, 'Error');
              }
            }
          }
        }
      );
      // Now, pass formData to your API via a service.
    } else {
      // Mark all controls as touched to trigger validation messages.
      this.workStyleUpdateForm.markAllAsTouched();
      this.toastr.error('Please select all required fields');
    }
  }

  deleteSelectedWorkingStyle() {
    this.loader = true
    this.masterService.deleteWorkingStyleById({ id: this.selectedWorkingStyleId }).subscribe(
      (res: any) => {
        if (res?.status === 200) {
          this.loader = false
          this.toastr.success(res.message, 'Success');
          this.modalService.dismissAll();
          this.getWorkingStyleList()
        } else {
          this.loader = false;
          this.toastr.error(res.message || 'An error occurred. Please try again.', 'Error');
        }
      },
      (err) => {
        this.loader = false;
        if (err?.status !== 401) {
          let errorMessage = 'An error occurred. Please try again later.'
          if (err.error) {
            if (err.error.errors && Object.keys(err.error.errors).length > 0) {
              errorMessage = err.error.errors;
            } else if (err.error.message) {
              errorMessage = err.error.message;
            }
          }
          this.toastr.error(errorMessage, 'Error');
        }
      }
    );
  }

  onSearchChange(searchTexts: any) {
    const trimmedText = searchTexts?.trim();
    if (trimmedText) {
      this.searchText = searchTexts;
      this.getWorkingStyleList();
    } else if (searchTexts === "") {
      this.getWorkingStyleList();
    }
  }

  clearAll() {
    this.searchText = '';
    this.selectedWorkingStyleId = '';
    this.getWorkingStyleList();
  }


  openModalAddwork(addStaff: any) {
    this.isAddForm = true;
    this.modalService.open(addStaff, {
      centered: true,
      size: "md",
      windowClass: "master_modal add_content",
    });
  }

  openModalEditWorkingStyle(edit: any, workingStyleId: any) {
    if (workingStyleId) {
      this.selectedWorkingStyleId = workingStyleId;
      this.getWorkingStyleById();
      this.isAddForm = false;
    }
    this.modalService.open(edit, {
      centered: true,
      size: "md",
      windowClass: "master_modal add_content",
    });
  }

  deleteWorkingStyle() {
    if (this.selectedWorkingStyleId) {
      this.deleteSelectedWorkingStyle()
    }
  }

  openModalDeleteWorkStyle(deleteModal: any, workStyleId: any) {
    if (workStyleId) {
      this.selectedWorkingStyleId = workStyleId;
    }
    this.modalService.open(deleteModal, {
      centered: true,
      size: "md",
      windowClass: "master_modal add_content",
    });
  }

  handlePageEvent(event: any) {
    this.limit = event?.pageSize;
    this.pageNumber = event?.pageIndex + 1
    this.getWorkingStyleList()
  }
}
