import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WorkStyleManagemntComponent } from './work-style-managemnt.component';

describe('WorkStyleManagemntComponent', () => {
  let component: WorkStyleManagemntComponent;
  let fixture: ComponentFixture<WorkStyleManagemntComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [WorkStyleManagemntComponent]
    });
    fixture = TestBed.createComponent(WorkStyleManagemntComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
