import { Component } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
// import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ChangeDetectionStrategy, inject } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UserService } from 'src/app/services/user.service';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { MasterService } from 'src/app/services/master.service';
// import { CreateRoleComponent } from './create-role/create-role.component';
interface Food {
  value: string;
  viewValue: string;
}


export interface PeriodicElement {
  name: string;
  role: string;
  email: string;
  mobile: string;
  status: any;
  image: any;
  actions: string

}
const ELEMENT_DATA: PeriodicElement[] = [
  {
    name: 'Alice Johnson',
    role: 'Admin',
    email: 'alice@example.com',
    mobile: '123-456-7890',
    status: 'Active',
    image: 'assets/images/user1.jpg',
    actions: 'Edit/Delete',
  },
  {
    name: 'Bob Smith',
    role: 'Manager',
    email: 'bob@example.com',
    mobile: '987-654-3210',
    status: 'Inactive',
    image: 'assets/images/user2.jpg',
    actions: 'Edit/Delete',
  },
];



@Component({
  selector: 'app-score-management',
  templateUrl: './score-management.component.html',
  styleUrls: ['./score-management.component.scss']
})
export class ScoreManagementComponent {
  foods: Food[] = [
    { value: 'steak-0', viewValue: 'Steak' },
    { value: 'pizza-1', viewValue: 'Pizza' },
    { value: 'tacos-2', viewValue: 'Tacos' },
  ];

  loader: boolean = false
  limit: any = 10
  pageNumber: any = 1
  totalLength: any = 0
  searchText: any = ''

  displayedColumns: string[] = ['g1_status', 'g2_status', 'email', 'actions'];
  dataSource = ELEMENT_DATA;
  rolesList: any = []
  scoresList: any = []
  scoreForm: FormGroup;
  updateScoreForm: FormGroup;
  status_filter: any = ["Active", "Deactivated"]
  selectedScoreId: any = '';
  statusValue: any = '';
  selectedEmail: any = '';
  profile_pic: any = ''
  roleCategoryList: any = [];

  constructor(private fb: FormBuilder, private modalService: NgbModal, public dialog: MatDialog,
    private masterService: MasterService, private router: Router, private toastr: ToastrService) {

    this.scoreForm = this.fb.group({
      // role_category: ['', Validators.required],
      g1_status: ['', Validators.required],
      g2_status: ['', Validators.required],
      score: ['', [Validators.required, Validators.pattern('^[0-9]+(\.[0-9]{1,2})?$')]], // Allows up to 2 decimal places
    });

    this.updateScoreForm = this.fb.group({
      // role_category: ['', Validators.required],
      g1_status: ['', Validators.required],
      g2_status: ['', Validators.required],
      score: ['', [Validators.required, Validators.pattern('^[0-9]+(\.[0-9]{1,2})?$')]],
    });

  }

  ngOnInit(): void {
    this.getScores();
    this.getRolecategoryList();
  }

  getRolecategoryList() {
    this.loader = true;
    let queryData = {
      limit: this.limit,
      page: this.pageNumber,
      searchText: this.searchText
    }

    this.masterService.getRoleCategory(queryData).subscribe(
      (res: any) => {
        if (res?.status === 200) {
          this.loader = false;
          this.roleCategoryList = res?.data?.role_categories;
          this.totalLength = res?.data?.total;
        } else {
          this.loader = false;
          this.roleCategoryList = []
          this.toastr.error(res.message || 'An error occurred. Please try again.', 'Error');
        }
      },
      (err) => {
        this.loader = false;
        let errorMessage = 'An error occurred. Please try again later.'
        if (err.error) {
          if (err.error.errors && Object.keys(err.error.errors).length > 0) {
            errorMessage = err.error.errors;
          } else if (err.error.message) {
            errorMessage = err.error.message;
          }
        }
        this.toastr.error(errorMessage, 'Error');
      }
    );
  }

  getScores() {
    this.loader = true
    let queryData = {
      limit: this.limit,
      page: this.pageNumber,
      searchText: this.searchText
    }
    this.masterService.getScores(queryData).subscribe(
      (res: any) => {
        if (res?.status === 200) {
          this.scoresList = res?.data?.scores;
          this.totalLength = res?.data?.total;
          this.loader = false
        } else {
          this.loader = false;
          this.scoresList = [];
          this.totalLength = 0
        }
      },
      (err) => {
        this.loader = false;
        if (err?.status !== 401) {
          let errorMessage = 'An error occurred. Please try again later.'
          if (err.error) {
            if (err.error.errors && Object.keys(err.error.errors).length > 0) {
              errorMessage = err.error.errors;
            } else if (err.error.message) {
              errorMessage = err.error.message;
            }
          }
        }
      }
    );
  }

  getScoreById() {
    this.loader = true;
    this.masterService.getScoreById({ id: this.selectedScoreId }).subscribe(
      (res: any) => {
        if (res?.status === 200) {
          this.updateScoreForm.patchValue({
            g1_status: res?.data?.g1_status,
            g2_status: res?.data?.g2_status,
            score: res?.data?.score,
            // role_category: res?.data?.role_category?.id
          });
          this.loader = false;
        } else {
          this.loader = false;
          this.toastr.error(res?.message || 'An error occurred. Please try again.', 'Error');
        }
      },
      (err) => {
        this.loader = false;
        if (err?.status !== 401) {
          let errorMessage = 'An error occurred. Please try again later.'
          if (err.error) {
            if (err.error.errors && Object.keys(err.error.errors).length > 0) {
              errorMessage = err.error.errors;
            } else if (err.error.message) {
              errorMessage = err.error.message;
            }
          }
          this.toastr.error(errorMessage, 'Error');
        }
      }
    );
  }


  onSubmit(): void {
    if (this.scoreForm.valid) {
      this.loader = true
      const { g1_status, g2_status, score } = this.scoreForm.value;

      const data = {
        g1_status: g1_status?.toLowerCase(),
        g2_status: g2_status?.toLowerCase(),
        score: score,
        // role_category_id: role_category
      };

      this.masterService.addScore(data).subscribe(
        (res: any) => {

          if (res?.status === 200) {
            this.loader = false
            this.toastr.success(res.message, 'Success');
            this.modalService.dismissAll();
            this.scoreForm.reset();
            this.getScores();
          } else {
            this.loader = false;
            this.toastr.error(res.message || 'An error occurred. Please try again.', 'Error');
          }
        },
        (err) => {
          this.loader = false;
          if (err?.status !== 401) {
            let errorMessage = 'An error occurred. Please try again later.'
            if (err.error) {
              if (err.error.errors && Object.keys(err.error.errors).length > 0) {
                for (let field in err.error.errors) {
                  if (err.error.errors.hasOwnProperty(field)) {
                    this.toastr.error(err.error.errors[field]);
                  }
                }
                errorMessage = err.error.errors;
              } else if (err.error.message) {
                errorMessage = err.error.message;
                this.toastr.error(errorMessage);
              }
            }
          }
        }
      );
    } else {
      this.toastr.error('Please select all required fields');
      this.scoreForm.markAllAsTouched();
    }
  }

  onSubmitUpdate(): void {
    if (this.updateScoreForm.valid) {

      this.loader = true
      const { g1_status, g2_status, score } = this.updateScoreForm.value;

      const data = {
        g1_status: g1_status,
        g2_status: g2_status,
        score: score,
        // role_category_id: role_category,
        score_id: this.selectedScoreId
      };

      this.masterService.updateScoreId(data).subscribe(
        (res: any) => {
          if (res?.status === 200) {
            this.loader = false
            this.toastr.success(res.message, 'Success');
            this.modalService.dismissAll();
            this.getScores();
          } else {
            this.loader = false;
            this.toastr.error(res.message || 'An error occurred. Please try again.', 'Error');
          }
        },
        (err) => {
          this.loader = false;
          if (err?.status !== 401) {
            let errorMessage = 'An error occurred. Please try again later.'
            if (err.error) {
              if (err.error.errors && Object.keys(err.error.errors).length > 0) {
                for (let field in err.error.errors) {
                  if (err.error.errors.hasOwnProperty(field)) {
                    this.toastr.error(err.error.errors[field]);
                  }
                }
                errorMessage = err.error.errors;
              } else if (err.error.message) {
                errorMessage = err.error.message;
                this.toastr.error(errorMessage);
              }
            }
          }
        }
      );
    } else {
      this.toastr.error('Please select all required fields');
      this.updateScoreForm.markAllAsTouched();
    }
  }

  deleteScore() {
    this.loader = true
    this.masterService.deleteScoreById({ id: this.selectedScoreId }).subscribe(
      (res: any) => {
        if (res?.status === 200) {
          this.loader = false
          this.toastr.success(res.message, 'Success');
          this.modalService.dismissAll();
          this.getScores()
        } else {
          this.loader = false;
          this.toastr.error(res.message || 'An error occurred. Please try again.', 'Error');
        }
      },
      (err) => {
        this.loader = false;
        if (err?.status !== 401) {
          let errorMessage = 'An error occurred. Please try again later.'
          if (err.error) {
            if (err.error.errors && Object.keys(err.error.errors).length > 0) {
              errorMessage = err.error.errors;
            } else if (err.error.message) {
              errorMessage = err.error.message;
            }
          }
          this.toastr.error(errorMessage, 'Error');
        }
      }
    );
  }

  onSearchChange(searchTexts: any) {
    const trimmedText = searchTexts?.trim();
    if (trimmedText) {
      this.searchText = searchTexts;
      this.getScores();
    } else if (searchTexts === "") {
      this.getScores();
    }
  }

  clearAll() {
    this.searchText = '';
    this.statusValue = '';
    this.selectedScoreId = '';
    this.getScores();
  }

  openModalAddscore(addStaff: any) {
    this.modalService.open(addStaff, {
      centered: true,
      size: "md",
      windowClass: "master_modal add_content",
    });
  }

  openModaleditscore(edit: any, scoreId: any) {
    if (scoreId) {
      this.selectedScoreId = scoreId;
      this.getScoreById();
    }
    this.modalService.open(edit, {
      centered: true,
      size: "md",
      windowClass: "master_modal add_content",
    });
  }

  openModaldeletescore(deleteModal: any, scoreId: any) {
    if (scoreId) {
      this.selectedScoreId = scoreId;
    }
    this.modalService.open(deleteModal, {
      centered: true,
      size: "md",
      windowClass: "master_modal add_content",
    });
  }

  handlePageEvent(event: any) {
    this.limit = event?.pageSize;
    this.pageNumber = event?.pageIndex + 1
    this.getScores()
  }
}
