import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CandidateProfileManagementComponent } from './candidate-profile-management.component';

describe('CandidateProfileManagementComponent', () => {
  let component: CandidateProfileManagementComponent;
  let fixture: ComponentFixture<CandidateProfileManagementComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [CandidateProfileManagementComponent]
    });
    fixture = TestBed.createComponent(CandidateProfileManagementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
