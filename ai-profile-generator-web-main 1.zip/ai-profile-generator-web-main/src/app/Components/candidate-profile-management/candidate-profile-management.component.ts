import { Component } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
// import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ChangeDetectionStrategy, inject } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UserService } from 'src/app/services/user.service';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { MasterService } from 'src/app/services/master.service';
import { ResumeParseService } from 'src/app/services/resume-parse.service';
// import { CreateRoleComponent } from './create-role/create-role.component';
import * as CryptoJS from 'crypto-js';
import { environment } from 'src/environments/environment';
import { map } from 'rxjs';

export interface PeriodicElement {
  type: string;
  name: string;
  category: string;
  age: string;
  notice_period: string;
  mobile: string;
  image: any;
  actions: string;
}
const ELEMENT_DATA: PeriodicElement[] = [
  {
    type: 'Manual',
    name: 'Alice Johnson',
    category: 'Accountancy & Bookkeeping',
    age: '30',
    notice_period: '30 days',
    mobile: '123-456-7890',
    image: 'assets/images/user1.jpg',
    actions: 'Edit/Delete',
  },
  {
    type: 'Parsing',
    name: 'Bob Smith',
    category: 'Virtual Assistance & Admin',
    age: '25',
    notice_period: '45 days',
    mobile: '987-654-3210',
    image: 'assets/images/user2.jpg',
    actions: 'Edit/Delete',
  },
];

@Component({
  selector: 'app-candidate-profile-management',
  templateUrl: './candidate-profile-management.component.html',
  styleUrls: ['./candidate-profile-management.component.scss'],
})
export class CandidateProfileManagementComponent {
  checked: boolean = false;

  loader: boolean = false;
  limit: any = 10;
  pageNumber: any = 1;
  totalLength: any = 0;
  searchText: any = '';

  displayedColumns: string[] = [
    'type',
    'name',
    'category',
    'image',
    'age',
    'notice period',
    'export',
    'deleteAll',
    'actions',
  ];
  dataSource = ELEMENT_DATA;
  selectedEmail: any = '';
  profile_pic: any = '';
  editimage: any = '';
  selectedResumeRoute: any = 'parsing';

  roleCategoryList: any = [];
  selectedRoleCategory: any = '';
  selectedType: any = '';
  candidatesList: any = [];
  selectedCandidateId: any = '';
  encryptionKey = environment.encryptionKey;

  checkedCandidate: any = [];
  checkedCandidateForTemplate: any = [];
  isDraftList: boolean = false;

  updateDisplayedColumns() {
    this.displayedColumns = [
      'type',
      'name',
      'category',
      'image',
      'age',
      'notice period',
      ...(this.isDraftList ? [] : ['export']), // Show only if not draft
      'deleteAll',
      'actions',
    ];
  }
  

  constructor(
    private modalService: NgbModal,
    public dialog: MatDialog,
    private router: Router,
    private toastr: ToastrService,
    private masterService: MasterService,
    private resumeParseService: ResumeParseService,
    private route: ActivatedRoute
  ) {}



  ngOnInit(): void {
    this.route.queryParams
      .pipe(map((params) => params['status'] === 'drafts'))
      .subscribe((isDraft) => {
        this.isDraftList = isDraft; // Update the variable
        this.updateDisplayedColumns(); // <- Add this line
        this.clearAll();
        isDraft ? this.getCandidatesDraftsList() : this.getCandidatesList();
      });
  }

  getRolecategoryList() {
    this.loader = true;
    let queryData = {
      limit: this.limit,
      page: this.pageNumber,
      searchText: '',
    };

    this.masterService.getRoleCategory(queryData).subscribe(
      (res: any) => {
        if (res?.status === 200) {
          this.loader = false;
          this.roleCategoryList = res?.data?.role_categories;
        } else {
          this.loader = false;
          this.roleCategoryList = [];
          this.toastr.error(
            res.message || 'An error occurred. Please try again.',
            'Error'
          );
        }
      },
      (err) => {
        this.loader = false;
        if (err?.status !== 401) {
          let errorMessage = 'An error occurred. Please try again later.';
          if (err.error) {
            if (err.error.errors && Object.keys(err.error.errors).length > 0) {
              errorMessage = err.error.errors;
            } else if (err.error.message) {
              errorMessage = err.error.message;
            }
          }
          this.toastr.error(errorMessage, 'Error');
        }
      }
    );
  }

  getCandidatesDraftsList() {
    this.loader = true;
    let queryData = {
      limit: this.limit,
      page: this.pageNumber,
      searchText: this.searchText,
      role_category_id: this.selectedRoleCategory,
      type: this.selectedType.toLowerCase(),
    };

    this.resumeParseService.getCandidatesDrafts(queryData).subscribe(
      (res: any) => {
        if (res?.status === 200) {
          this.candidatesList = res?.data?.candidates;
          this.getRolecategoryList();
          this.totalLength = res?.data?.total;
          this.loader = false;
        } else {
          this.loader = false;
          this.candidatesList = [];
          this.totalLength = 0;
        }
      },

      (err) => {
        this.loader = false;
        if (err?.status !== 401) {
          let errorMessage = 'An error occurred. Please try again later.';
          if (err.error) {
            if (err.error.errors && Object.keys(err.error.errors).length > 0) {
              errorMessage = err.error.errors;
            } else if (err.error.message) {
              errorMessage = err.error.message;
            }
          }
        }
      }
    );
  }

  getCandidatesList() {
    this.loader = true;
    let queryData = {
      limit: this.limit,
      page: this.pageNumber,
      searchText: this.searchText,
      role_category_id: this.selectedRoleCategory,
      type: this.selectedType.toLowerCase(),
    };
    this.resumeParseService.getCandidates(queryData).subscribe(
      (res: any) => {
        if (res?.status === 200) {
          this.getRolecategoryList();
          this.candidatesList = res?.data?.candidates;
          this.totalLength = res?.data?.total;
          this.checkedCandidateForTemplate = [];
          this.loader = false;
        } else {
          this.loader = false;
          this.candidatesList = [];
          this.totalLength = 0;
          this.checkedCandidateForTemplate = [];
        }
      },
      (err) => {
        this.loader = false;
        if (err?.status !== 401) {
          let errorMessage = 'An error occurred. Please try again later.';
          if (err.error) {
            if (err.error.errors && Object.keys(err.error.errors).length > 0) {
              errorMessage = err.error.errors;
            } else if (err.error.message) {
              errorMessage = err.error.message;
            }
          }
        }
      }
    );
  }

  deleteCandidateRecord() {
    this.loader = true;
    this.resumeParseService
      .deleteCandidate({ id: this.selectedCandidateId })
      .subscribe(
        (res: any) => {
          if (res?.status === 200) {
            this.loader = false;
            this.toastr.success(res.message, 'Success');
            this.modalService.dismissAll();
            if(this.isDraftList) {
              this.getCandidatesDraftsList();
            } else {
            this.getCandidatesList();
            }
          } else {
            this.loader = false;
            this.toastr.error(
              res.message || 'An error occurred. Please try again.',
              'Error'
            );
          }
        },
        (err) => {
          this.loader = false;
          let errorMessage = 'An error occurred. Please try again later.';
          if (err.error) {
            if (err.error.errors && Object.keys(err.error.errors).length > 0) {
              errorMessage = err.error.errors;
            } else if (err.error.message) {
              errorMessage = err.error.message;
            }
          }
          this.toastr.error(errorMessage, 'Error');
        }
      );
  }

  onSearchChange(searchTexts: any) {
    const trimmedText = searchTexts?.trim();
    if (trimmedText) {
      this.searchText = searchTexts;
      if (this.isDraftList) {
        console.log('inside_____________');
        this.getCandidatesDraftsList();
      } else {
        this.getCandidatesList();
      }
    } else if (searchTexts === '') {
      this.getCandidatesList();
      this.getCandidatesDraftsList();
    }
  }

  onRoleCategorySelectionChange(event: any) {
    if (event?.value) {
      this.selectedRoleCategory = event?.value;

      if (this.isDraftList) {
        this.getCandidatesDraftsList();
      } else {
        this.getCandidatesList();
      }
    }
  }

  onTypeSelectionChange(event: any) {
    if (event?.value) {
      this.selectedType = event?.value;
      if (this.isDraftList) {
        this.getCandidatesDraftsList();
      } else {
        this.getCandidatesList();
      }
    }
  }

  clearAll() {
    this.searchText = '';
    this.selectedRoleCategory = '';
    this.selectedType = '';
    this.pageNumber = 1;
    this.limit = 10;
    if (this.isDraftList) {
      this.getCandidatesDraftsList();
    } else {
      this.getCandidatesList();
    }
  }

  openModalAddprofile(addStaff: any) {
    this.modalService.open(addStaff, {
      centered: true,
      size: 'md',
      windowClass: 'master_modal add_content',
    });
  }

  redirectToCandidateProfile(candidateId: any) {
    const encryptedId = CryptoJS.AES.encrypt(
      candidateId.toString(),
      this.encryptionKey
    ).toString();
    const safeEncryptedId = encodeURIComponent(encryptedId);
    if (safeEncryptedId) {
      this.router.navigate([`candidates/profile/${safeEncryptedId}`]);
    }
  }

  deleteCandidate() {
    if (this.selectedCandidateId) {
      this.deleteCandidateRecord();
    } else {
      this.toastr.error(
        'Please select the candidate which you want to delete first.'
      );
    }
  }

  selectedCandidateDeleteConfirmation(deleteModalSelectedCandidate: any) {
    this.modalService.open(deleteModalSelectedCandidate, {
      centered: true,
      size: 'md',
      windowClass: 'master_modal add_content',
    });
  }

  openModaldeleteprofile(deleteModal: any, candidateId: any) {
    if (candidateId) {
      this.selectedCandidateId = candidateId;
    }
    this.modalService.open(deleteModal, {
      centered: true,
      size: 'md',
      windowClass: 'master_modal add_content',
    });
  }

  redirectToResumeTemplate(candidateId: any) {
    const encryptedId = CryptoJS.AES.encrypt(
      candidateId.toString(),
      this.encryptionKey
    ).toString();
    const safeEncryptedId = encodeURIComponent(encryptedId);
    if (safeEncryptedId) {
      this.router.navigate([`candidate-profile-builder/${safeEncryptedId}`]);
    }
  }

  handlePageEvent(event: any) {
    this.limit = event?.pageSize;
    this.pageNumber = event?.pageIndex + 1;
    if (this.isDraftList) {
      this.getCandidatesDraftsList();
    } else {
      this.getCandidatesList();
    }
  }

  redirectRoutPath(routePath: any) {
    this.selectedResumeRoute = routePath;
  }
  navigateTo() {
    this.router.navigate([
      `/candidates/professional-details/${this.selectedResumeRoute}`,
    ]);
    this.modalService.dismissAll();
  }

  clearSearchField() {
    this.searchText = '';

    if (this.isDraftList) {
      this.getCandidatesDraftsList();
    } else {
      this.getCandidatesList();
    }
  }

  toggleCheckboxForDelete(candidateId: any) {
    if (candidateId) {
      const index = this.checkedCandidate.indexOf(candidateId);

      if (index > -1) {
        // If candidateId is already in the array, remove it (uncheck the checkbox)
        this.checkedCandidate.splice(index, 1);
      } else {
        // If candidateId is not in the array, add it (check the checkbox)
        this.checkedCandidate.push(candidateId);
      }
    }
  }

  deleteSelectedCandidates() {
    this.loader = true;
    this.resumeParseService
      .deleteSelectedCandidates({
        candidateNeedtoDelete: this.checkedCandidate,
      })
      .subscribe(
        (res: any) => {
          if (res?.status === 200) {
            this.toastr.success(res.message, 'Success');
            this.modalService.dismissAll();
            if (this.isDraftList) {
              this.getCandidatesDraftsList();
            } else {
              this.getCandidatesList();
            }
            // this.loader = false
            this.selectedCandidateId = [];
            this.checkedCandidate = [];
          } else {
            this.loader = false;
            this.selectedCandidateId = [];
          }
        },
        (err) => {
          this.loader = false;
          if (err?.status !== 401) {
            let errorMessage = 'An error occurred. Please try again later.';
            if (err.error) {
              if (
                err.error.errors &&
                Object.keys(err.error.errors).length > 0
              ) {
                errorMessage = err.error.errors;
              } else if (err.error.message) {
                errorMessage = err.error.message;
              }
            }
          }
        }
      );
  }

  toggleCheckboxForResumeTemplate(candidateId: any) {
    if (candidateId) {
      // Find the candidate in candidatesList by id
      const candidate = this.candidatesList.find(
        (candidate: { id: any }) => candidate.id === candidateId
      );


      if (candidate) {
        const index = this.checkedCandidateForTemplate.indexOf(
          candidate.pdf_file
        );


        if (index > -1) {
          // If pdf_file is already in the array, remove it (uncheck the checkbox)

          this.checkedCandidateForTemplate.splice(index, 1);
        } else {

          // If pdf_file is not in the array, add it (check the checkbox)
          this.checkedCandidateForTemplate.push(candidate.pdf_file);
        }
        console.log(this.checkedCandidateForTemplate,"checkedCandidateForTemplate___");
        
      }
    }
  }

  exportAllSelectedPdf() {
    this.checkedCandidateForTemplate.forEach((pdfUrl: any) => {
      const link = document.createElement('a');
      link.href = pdfUrl;
      link.target = '_blank';
      link.download = pdfUrl.split('/').pop() || 'resume.pdf'; // Extract filename from URL
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    });
  }

  // helper function to create delay
  delay(ms: number) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }
}
