import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AssessmentGradeComponent } from './assessment-grade.component';

describe('AssessmentGradeComponent', () => {
  let component: AssessmentGradeComponent;
  let fixture: ComponentFixture<AssessmentGradeComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AssessmentGradeComponent]
    });
    fixture = TestBed.createComponent(AssessmentGradeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
