import { Component } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';;
import { MatDialog } from '@angular/material/dialog';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { MasterService } from 'src/app/services/master.service';

interface Food {
  value: string;
  viewValue: string;
}

export interface PeriodicElement {
  name: string;
  role: string;
  email: string;
  mobile: string;
  status: any;
  image: any;
  actions: string

}
const ELEMENT_DATA: PeriodicElement[] = [
  {
    name: 'Alice Johnson',
    role: 'Admin',
    email: 'alice@example.com',
    mobile: '123-456-7890',
    status: 'Active',
    image: 'assets/images/user1.jpg',
    actions: 'Edit/Delete',
  },
  {
    name: 'Bob Smith',
    role: 'Manager',
    email: 'bob@example.com',
    mobile: '987-654-3210',
    status: 'Inactive',
    image: 'assets/images/user2.jpg',
    actions: 'Edit/Delete',
  },
];


@Component({
  selector: 'app-assessment-grade',
  templateUrl: './assessment-grade.component.html',
  styleUrls: ['./assessment-grade.component.scss']
})
export class AssessmentGradeComponent {
  foods: Food[] = [
    { value: 'steak-0', viewValue: 'Steak' },
    { value: 'pizza-1', viewValue: 'Pizza' },
    { value: 'tacos-2', viewValue: 'Tacos' },
  ];

  loader: boolean = false
  limit: any = 10
  pageNumber: any = 1
  totalLength: any = 0
  searchText: any = ''

  displayedColumns: string[] = ['grade', 'min', 'max', 'description', 'actions'];
  dataSource = ELEMENT_DATA;
  rolesList: any = []
  assessmentGradeList: any = []
  assessmentGradeForm: FormGroup;
  updateAssessmentGradeForm: FormGroup;
  status_filter: any = ["Active", "Deactivated"]
  selectedAssessmentGradeId: any = '';
  statusValue: any = '';
  selectedEmail: any = '';
  profile_pic: any = ''
  roleCategoryList: any = [];

  constructor(private fb: FormBuilder, private modalService: NgbModal, public dialog: MatDialog,
    private masterService: MasterService, private router: Router, private toastr: ToastrService) {

    this.assessmentGradeForm = this.fb.group({
      grade: ['', Validators.required],
      min: ['', [Validators.required, Validators.min(0)]],
      max: ['', [Validators.required, Validators.max(100)]],
      description: ['', [Validators.required]],
    });

    this.updateAssessmentGradeForm = this.fb.group({
      grade: ['', Validators.required],
      min: ['', [Validators.required, Validators.min(0)]],
      max: ['', [Validators.required, Validators.max(100)]],
      description: ['', [Validators.required]],
    });

  }

  ngOnInit(): void {
    this.getAssesssmentGrades();
  }

  getAssesssmentGrades() {
    this.loader = true
    let queryData = {
      limit: this.limit,
      page: this.pageNumber,
      searchText: this.searchText
    }
    this.masterService.getAssessmentGrade(queryData).subscribe(
      (res: any) => {
        if (res?.status === 200) {
          this.assessmentGradeList = res?.data?.results;
          this.totalLength = res?.data?.total;
          this.loader = false
        } else {
          this.loader = false;
          this.assessmentGradeList = [];
          this.totalLength = 0
        }
      },
      (err) => {
        this.loader = false;
        if (err?.status !== 401) {
          let errorMessage = 'An error occurred. Please try again later.'
          if (err.error) {
            if (err.error.errors && Object.keys(err.error.errors).length > 0) {
              errorMessage = err.error.errors;
            } else if (err.error.message) {
              errorMessage = err.error.message;
            }
          }
        }
      }
    );
  }

  getAssessmentGradeById() {
    this.loader = true;
    this.masterService.getAssessmentGradeById({ id: this.selectedAssessmentGradeId }).subscribe(
      (res: any) => {
        if (res?.status === 200) {
          this.updateAssessmentGradeForm.patchValue({
            grade: res?.data?.grade,
            min: res?.data?.min,
            max: res?.data?.max,
            description: res?.data?.description
          });
          this.loader = false;
        } else {
          this.loader = false;
          this.toastr.error(res?.message || 'An error occurred. Please try again.', 'Error');
        }
      },
      (err) => {
        this.loader = false;
        if (err?.status !== 401) {
          let errorMessage = 'An error occurred. Please try again later.'
          if (err.error) {
            if (err.error.errors && Object.keys(err.error.errors).length > 0) {
              errorMessage = err.error.errors;
            } else if (err.error.message) {
              errorMessage = err.error.message;
            }
          }
          this.toastr.error(errorMessage, 'Error');
        }
      }
    );
  }


  onSubmit(): void {
    if (this.assessmentGradeForm.valid) {
      this.loader = true
      const { grade, min, max, description } = this.assessmentGradeForm.value;

      const data = {
        grade: grade,
        min: min,
        max: max,
        description: description
      };

      this.masterService.addAssessmentGrade(data).subscribe(
        (res: any) => {

          if (res?.status === 200) {
            this.loader = false
            this.toastr.success(res.message, 'Success');
            this.modalService.dismissAll();
            this.assessmentGradeForm.reset();
            this.getAssesssmentGrades();
          } else {
            this.loader = false;
            this.toastr.error(res.message || 'An error occurred. Please try again.', 'Error');
          }
        },
        (err) => {
          this.loader = false;
          if (err?.status !== 401) {
            let errorMessage = 'An error occurred. Please try again later.'
            if (err.error) {
              if (err.error.errors && Object.keys(err.error.errors).length > 0) {
                for (let field in err.error.errors) {
                  if (err.error.errors.hasOwnProperty(field)) {
                    this.toastr.error(err.error.errors[field]);
                  }
                }
                errorMessage = err.error.errors;
              } else if (err.error.message) {
                errorMessage = err.error.message;
                this.toastr.error(errorMessage);
              }
            }
          }
        }
      );
    } else {
      this.toastr.error('Please select all required fields');
      this.assessmentGradeForm.markAllAsTouched();
    }
  }

  onSubmitUpdate(): void {
    if (this.updateAssessmentGradeForm.valid) {

      this.loader = true
      const { grade, min, max, description } = this.updateAssessmentGradeForm.value;

      const data = {
        grade: grade,
        min: min,
        max: max,
        description: description,
        talent_assessment_score_id: this.selectedAssessmentGradeId
      };

      this.masterService.updateAssessmentGrade(data).subscribe(
        (res: any) => {
          if (res?.status === 200) {
            this.loader = false
            this.toastr.success(res.message, 'Success');
            this.modalService.dismissAll();
            this.getAssesssmentGrades();
          } else {
            this.loader = false;
            this.toastr.error(res.message || 'An error occurred. Please try again.', 'Error');
          }
        },
        (err) => {
          this.loader = false;
          if (err?.status !== 401) {
            let errorMessage = 'An error occurred. Please try again later.'
            if (err.error) {
              if (err.error.errors && Object.keys(err.error.errors).length > 0) {
                for (let field in err.error.errors) {
                  if (err.error.errors.hasOwnProperty(field)) {
                    this.toastr.error(err.error.errors[field]);
                  }
                }
                errorMessage = err.error.errors;
              } else if (err.error.message) {
                errorMessage = err.error.message;
                this.toastr.error(errorMessage);
              }
            }
          }
        }
      );
    } else {
      this.toastr.error('Please select all required fields');
      this.updateAssessmentGradeForm.markAllAsTouched();
    }
  }

  deleteAssessmentGrade() {
    this.loader = true
    this.masterService.deleteAssessmentGrade({ id: this.selectedAssessmentGradeId }).subscribe(
      (res: any) => {
        if (res?.status === 200) {
          this.loader = false
          this.toastr.success(res.message, 'Success');
          this.modalService.dismissAll();
          this.getAssesssmentGrades()
        } else {
          this.loader = false;
          this.toastr.error(res.message || 'An error occurred. Please try again.', 'Error');
        }
      },
      (err) => {
        this.loader = false;
        if (err?.status !== 401) {
          let errorMessage = 'An error occurred. Please try again later.'
          if (err.error) {
            if (err.error.errors && Object.keys(err.error.errors).length > 0) {
              errorMessage = err.error.errors;
            } else if (err.error.message) {
              errorMessage = err.error.message;
            }
          }
          this.toastr.error(errorMessage, 'Error');
        }
      }
    );
  }

  onSearchChange(searchTexts: any) {
    const trimmedText = searchTexts?.trim();
    if (trimmedText) {
      this.searchText = searchTexts;
      this.getAssesssmentGrades();
    } else if (searchTexts === "") {
      this.getAssesssmentGrades();
    }
  }

  clearAll() {
    this.searchText = '';
    this.statusValue = '';
    this.selectedAssessmentGradeId = '';
    this.getAssesssmentGrades();
  }

  openModalAddscore(addStaff: any) {
    this.modalService.open(addStaff, {
      centered: true,
      size: "md",
      windowClass: "master_modal add_content",
    });
  }

  openModaleditscore(edit: any, scoreId: any) {
    if (scoreId) {
      this.selectedAssessmentGradeId = scoreId;
      this.getAssessmentGradeById();
    }
    this.modalService.open(edit, {
      centered: true,
      size: "md",
      windowClass: "master_modal add_content",
    });
  }

  openModaldeletescore(deleteModal: any, scoreId: any) {
    if (scoreId) {
      this.selectedAssessmentGradeId = scoreId;
    }
    this.modalService.open(deleteModal, {
      centered: true,
      size: "md",
      windowClass: "master_modal add_content",
    });
  }

  handlePageEvent(event: any) {
    this.limit = event?.pageSize;
    this.pageNumber = event?.pageIndex + 1
    this.getAssesssmentGrades()
  }
}
