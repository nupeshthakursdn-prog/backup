import { Component } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { MatDialog } from '@angular/material/dialog';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { MasterService } from 'src/app/services/master.service';
interface Food {
  value: string;
  viewValue: string;
}


export interface PeriodicElement {
  roleCategory: string;
  proficiency: string;
  assessment: string;

}
const ELEMENT_DATA: PeriodicElement[] = [
  {
    roleCategory: 'Accounting & Bookkeeping',
    proficiency: 'Accounting (Intermediate)',
    assessment: 'Link'
  },
  {
    roleCategory: 'Virtual Assistance & Admin',
    proficiency: 'Executive Assistant',
    assessment: 'Link'
  },
];

@Component({
  selector: 'app-technical-proficiency-management',
  templateUrl: './technical-proficiency-management.component.html',
  styleUrls: ['./technical-proficiency-management.component.scss']
})
export class TechnicalProficiencyManagementComponent {
  foods: Food[] = [
    { value: 'steak-0', viewValue: 'Steak' },
    { value: 'pizza-1', viewValue: 'Pizza' },
    { value: 'tacos-2', viewValue: 'Tacos' },
  ];

  loader: boolean = false
  limit: any = 10
  pageNumber: any = 1
  totalLength: any = 0
  searchText: any = ''

  displayedColumns: string[] = ['roleCategory', 'proficiency', 'assessment', 'actions'];
  dataSource = ELEMENT_DATA;
  technicalProficiencyList: any = []
  roleCategoryList: any = [];
  technicalProficiencyForm: FormGroup;
  updateTechnicalProficiencyForm: FormGroup;
  selectedTechnicalProficiency: any = ''
  duplicateErrorMessage: string = '';


  constructor(private fb: FormBuilder, private modalService: NgbModal, public dialog: MatDialog,
    private masterService: MasterService, private toastr: ToastrService) {

    this.technicalProficiencyForm = this.fb.group({
      roleCategory: ['', Validators.required], // Role category is required
      assessments: this.fb.array([this.createAssessment()]), // Start with one default assessment pair
    });

    this.updateTechnicalProficiencyForm = this.fb.group({
      role_category: ['', Validators.required], // Role category is required
      assessment_url: ['', Validators.required],
      name_of_proficiency: ['', Validators.required],
    });

  }

  ngOnInit(): void {
    this.getTechnicalProficiencies();
    this.getRolecategoryList();
  }

  getRolecategoryList() {
    this.loader = true;
    let queryData = {
      limit: '',
      page: this.pageNumber,
      searchText: this.searchText
    }

    this.masterService.getRoleCategory(queryData).subscribe(
      (res: any) => {
        if (res?.status === 200) {
          this.loader = false;
          this.roleCategoryList = res?.data?.role_categories;
        } else {
          this.loader = false;
          this.roleCategoryList = []
          this.toastr.error(res.message || 'An error occurred. Please try again.', 'Error');
        }
      },
      (err) => {
        this.loader = false;
        if (err?.status !== 401) {
          let errorMessage = 'An error occurred. Please try again later.'
          if (err.error) {
            if (err.error.errors && Object.keys(err.error.errors).length > 0) {
              errorMessage = err.error.errors;
            } else if (err.error.message) {
              errorMessage = err.error.message;
            }
          }
          this.toastr.error(errorMessage, 'Error');
        }
      }
    );
  }


  getTechnicalProficiencies() {
    this.loader = true
    let queryData = {
      limit: this.limit,
      page: this.pageNumber,
      searchText: this.searchText
    }
    this.masterService.getTechnicalProficiency(queryData).subscribe(
      (res: any) => {
        if (res?.status === 200) {
          this.loader = false
          this.technicalProficiencyList = res?.data?.techincal_proficiencies;
          this.totalLength = res?.data?.total;
        } else {
          this.loader = false
          this.technicalProficiencyList = []
        }
      },
      (err) => {
        this.loader = false
        if (err?.status !== 401) {
          let errorMessage = 'An error occurred. Please try again later.'
          if (err.error) {
            if (err.error.errors && Object.keys(err.error.errors).length > 0) {
              errorMessage = err.error.errors;
            } else if (err.error.message) {
              errorMessage = err.error.message;
            }
          }
        }
      }
    );
  }

  getTechnicalProficiencyByIds() {
    this.loader = true;
    let queryData = {
      id: this.selectedTechnicalProficiency
    };

    this.masterService.getTechnicalProficiencyById(queryData).subscribe(
      (res: any) => {
        if (res?.status === 200) {
          // Patch the form with received data
          this.updateTechnicalProficiencyForm.patchValue({
            assessment_url: res?.data?.assessment_url,
            name_of_proficiency: res?.data?.name_of_proficiency,
            role_category: res?.data?.role_category?.id
          });

          this.loader = false;
        } else {
          this.loader = false;
          this.toastr.error(res?.message || 'An error occurred', 'Error');
        }
      },
      (err) => {
        this.loader = false;
        if (err?.status !== 401) {
          let errorMessage = 'An error occurred. Please try again later.';
          if (err?.error) {
            if (err?.error?.errors && Object.keys(err?.error?.errors).length > 0) {
              errorMessage = err?.error?.errors;
              this.toastr.error(errorMessage, 'Error');
            } else if (err?.error?.message) {
              errorMessage = err?.error?.message;
              this.toastr.error(errorMessage, 'Error');
            }
          }
          // Display error message using Toastr for better user feedback
          this.toastr.error(errorMessage, 'Error');
        }
      }
    );
  }


  get assessments(): FormArray {
    return this.technicalProficiencyForm.get('assessments') as FormArray;
  }

  // Create a new assessment form group
  createAssessment(assessment: any = null): FormGroup {
    return this.fb.group({
      name_of_proficiency: [assessment?.name_of_proficiency || '', Validators.required],
      assessment_url: [assessment?.assessment_url || '', [Validators.required, Validators.pattern('https?://.+')]],
    });
  }

  // Add a new assessment pair
  addAssessment(): void {
    this.assessments.push(this.createAssessment());
  }

  // Remove an assessment pair
  removeAssessment(index: number): void {
    this.assessments.removeAt(index);
  }


  onSubmit(): void {
    this.duplicateErrorMessage = ''; // Reset previous error

    if (this.technicalProficiencyForm.valid) {
      this.loader = true;
      let { assessments, roleCategory } = this.technicalProficiencyForm.value;

      let data = {
        assessments: assessments,
        role_category_id: roleCategory
      };

      this.masterService.addTechnicalProficiency(data).subscribe(
        (res: any) => {
          if (res?.status === 200) {
            this.loader = false;
            this.toastr.success(res.message, 'Success');
            this.modalService.dismissAll();
            this.technicalProficiencyForm.reset();
            while (this.assessments.length !== 0) {
              this.assessments.removeAt(0);
            }
            this.addAssessment();
            this.getTechnicalProficiencies();
          } else {
            this.loader = false;
            this.toastr.error(res.message || 'An error occurred. Please try again.', 'Error');
          }
        },
        (err) => {
          this.loader = false;
          if (err?.status !== 401) {
            let errorMessage = 'An error occurred. Please try again later.';

            if (err) {
              if (err.error.errors && Object.keys(err.error.errors).length > 0) {
                errorMessage = Object.values(err.error.errors).join(', ');
                this.toastr.error("Technical proficiency with this name already exists");
              } else if (err.error.message) {
                errorMessage = err.error.message;
              }
            }
          }
        }
      );
    } else {
      this.technicalProficiencyForm.markAllAsTouched();
      this.toastr.error('Please select all required fields');
    }
  }


  onSubmitUpdate(): void {
    if (this.updateTechnicalProficiencyForm.valid) {
      this.loader = true;

      const { role_category, name_of_proficiency, assessment_url } = this.updateTechnicalProficiencyForm.value;

      const data = {
        technical_proficiency_id: this.selectedTechnicalProficiency,
        role_category_id: role_category,
        name_of_proficiency: name_of_proficiency.trim(),
        assessment_url: assessment_url.trim(),
      };

      this.masterService.updateTechnicalProficiency(data).subscribe(
        (res: any) => {
          if (res?.status === 200) {
            this.loader = false
            this.toastr.success(res.message, 'Success');
            this.modalService.dismissAll();
            this.getTechnicalProficiencies();
          } else {
            this.loader = false;
            this.toastr.error(res.message || 'An error occurred. Please try again.', 'Error');
          }
        },
        (err) => {
          this.loader = false;
          if (err?.status !== 401) {
            let errorMessage = 'An error occurred. Please try again later.'
            if (err.error) {
              if (err.error && Object.keys(err.error).length > 0) {
                for (let field in err.error) {
                  if (err.error.hasOwnProperty(field)) {
                    this.toastr.error(err.error[field]);
                  }
                }
                errorMessage = err.error;
              } else if (err.error.message) {
                errorMessage = err.error.message;
                this.toastr.error(errorMessage);
              }
            }
          }
        }
      );
    } else {
      this.toastr.error('Please fill all the required fields');
      this.updateTechnicalProficiencyForm.markAllAsTouched();
    }
  }

  deleteTechnicalProficiency() {
    this.loader = true
    this.masterService.deleteTechnicalProficiencyById({ techincal_proficiency_id: this.selectedTechnicalProficiency }).subscribe(
      (res: any) => {
        if (res?.status === 200) {
          this.loader = false
          this.toastr.success(res.message, 'Success');
          this.modalService.dismissAll();
          this.getTechnicalProficiencies();
        } else {
          this.loader = false;
          this.toastr.error(res.message || 'An error occurred. Please try again.', 'Error');
        }
      },
      (err) => {
        this.loader = false;
        if (err?.status !== 401) {
          let errorMessage = 'An error occurred. Please try again later.'
          if (err.error) {
            if (err.error.errors && Object.keys(err.error.errors).length > 0) {
              errorMessage = err.error.errors;
            } else if (err.error.message) {
              errorMessage = err.error.message;
            }
          }
          this.toastr.error(errorMessage, 'Error');
        }
      }
    );
  }

  onSearchChange(searchTexts: any) {
    const trimmedText = searchTexts?.trim();
    if (trimmedText) {
      this.searchText = searchTexts;
      this.getTechnicalProficiencies();
    } else if (searchTexts === "") {
      this.getTechnicalProficiencies();
    }
  }

  clearAll() {
    this.searchText = '';
    this.selectedTechnicalProficiency = '';
    this.getTechnicalProficiencies();
  }


  openModalAddtech(addTechnicalProficiency: any) {
    this.modalService.open(addTechnicalProficiency, {
      centered: true,
      size: "md",
      windowClass: "master_modal add_content",
    });
  }

  openModaledittech(edit: any, proficiencyId: any) {
    if (proficiencyId) {
      this.selectedTechnicalProficiency = proficiencyId;
      this.getTechnicalProficiencyByIds();
    }
    this.modalService.open(edit, {
      centered: true,
      size: "md",
      windowClass: "master_modal add_content",
    });
  }

  openModaldeletetech(deleteModal: any, proficiencyId: any) {
    if (proficiencyId) {
      this.selectedTechnicalProficiency = proficiencyId;
    }
    this.modalService.open(deleteModal, {
      centered: true,
      size: "md",
      windowClass: "master_modal add_content",
    });
  }

  handlePageEvent(event: any) {
    this.limit = event?.pageSize;
    this.pageNumber = event?.pageIndex + 1
    this.getTechnicalProficiencies()
  }

}
