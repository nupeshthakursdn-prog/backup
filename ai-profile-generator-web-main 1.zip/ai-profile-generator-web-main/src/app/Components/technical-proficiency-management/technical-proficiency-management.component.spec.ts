import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TechnicalProficiencyManagementComponent } from './technical-proficiency-management.component';

describe('TechnicalProficiencyManagementComponent', () => {
  let component: TechnicalProficiencyManagementComponent;
  let fixture: ComponentFixture<TechnicalProficiencyManagementComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TechnicalProficiencyManagementComponent]
    });
    fixture = TestBed.createComponent(TechnicalProficiencyManagementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
