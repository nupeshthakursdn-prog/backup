import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ManualResumeComponent } from './manual-resume.component';

describe('ManualResumeComponent', () => {
  let component: ManualResumeComponent;
  let fixture: ComponentFixture<ManualResumeComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ManualResumeComponent]
    });
    fixture = TestBed.createComponent(ManualResumeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
