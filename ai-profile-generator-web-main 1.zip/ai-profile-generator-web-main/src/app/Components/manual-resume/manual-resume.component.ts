import { Component } from '@angular/core';
import { AbstractControl, FormArray, FormBuilder, FormGroup, ValidationErrors, ValidatorFn, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Editor } from 'ngx-editor';
import { ToastrService } from 'ngx-toastr';
import { MasterService } from 'src/app/services/master.service';
import { ResumeParseService } from 'src/app/services/resume-parse.service';
@Component({
  selector: 'app-manual-resume',
  templateUrl: './manual-resume.component.html',
  styleUrls: ['./manual-resume.component.scss']
})
export class ManualResumeComponent {
  // editorContent: string = '';
  selectedFileName: string = 'No file chosen';
  editor: Editor = new Editor;
  html = '';

  limit: any = 10
  pageNumber: any = 1
  fileError: any = '';
  userParseData: any;
  loader: boolean = false;
  roleCategoryList: any = [];
  selectedCategory: any = ''
  candidateForm!: FormGroup;
  years: number[] = Array.from({ length: new Date().getFullYear() - 1990 + 1 }, (_, i) => 1990 + i);
  currentYear: any = new Date().getFullYear();
  candidateCategoryRecord: any;
  technicalProficiencyByRole: any = [];

  constructor(private router: Router, private resumeParseService: ResumeParseService, private toastr: ToastrService,
    private masterService: MasterService, private fb: FormBuilder) {

    this.candidateForm = this.fb.group({
      fullName: ['', [Validators.required, Validators.minLength(3)]],
      roleCategory: ['', [Validators.required]],
      age: ['', [Validators.required]],
      noticePeriod: ['', [Validators.required]],
      englishEducation: [''],
      image: [null],
      keySkills: [''],
      profileSummary: [''],
      workExperience: this.fb.array([], [this.fromYearLessThanToYearValidator()]),
      workStyleScore: [''],
      g1Status: ['', [Validators.required]],
      g2Status: ['', [Validators.required]],
      cognitiveCapability: this.fb.group({
        numericalReasoning: ['', [Validators.required, Validators.pattern(/^\d+(\.\d{1,2})?%$/)]],
        verbalReasoning: ['', [Validators.required, Validators.pattern(/^\d+(\.\d{1,2})?%$/)]],
        criticalThinking: ['', [Validators.required, Validators.pattern(/^\d+(\.\d{1,2})?%$/)]],
      }),
      technicalProficiency: this.fb.array([this.createAssessment()])
    });
    this.addWorkExperience();
  }

  onFileSelected(event: Event): void {
    const file = (event.target as HTMLInputElement).files?.[0];
    this.selectedFileName = file ? file.name : 'No file chosen';
  }

  triggerFileInput(): void {
    const fileInput = document.getElementById('fileInput') as HTMLInputElement;
    fileInput.click();
  }

  ngOnInit(): void {
    this.editor = new Editor();
    this.getRolecategoryList();
  }

  getRolecategoryList() {
    this.loader = true;
    let queryData = {
      limit: this.limit,
      page: this.pageNumber,
      searchText: ''
    }

    this.masterService.getRoleCategory(queryData).subscribe(
      (res: any) => {
        if (res?.status === 200) {
          this.loader = false;
          this.roleCategoryList = res?.data?.role_categories;
          console.log(this.roleCategoryList, "roleCategoryList__");
        } else {
          this.loader = false;
          this.roleCategoryList = []
          this.toastr.error(res.message || 'An error occurred. Please try again.', 'Error');
        }
      },
      (err) => {
        this.loader = false;
        let errorMessage = 'An error occurred. Please try again later.'
        if (err.error) {
          if (err.error.errors && Object.keys(err.error.errors).length > 0) {
            errorMessage = err.error.errors;
          } else if (err.error.message) {
            errorMessage = err.error.message;
          }
        }
        this.toastr.error(errorMessage, 'Error');
      }
    );
  }


  // workExperience form array functionality

  get workExperience(): FormArray {
    return this.candidateForm.get('workExperience') as FormArray;
  }

  // Add New Work Experience Row
  addWorkExperience() {
    this.workExperience.push(
      this.fb.group({
        designation: ['', Validators.required],
        companyName: ['', Validators.required],
        fromYear: ['', Validators.required],
        toYear: ['', Validators.required]
      },
        { validators: this.fromYearLessThanToYearValidator() })
    );
  }

  // Remove Work Experience Row
  removeWorkExperience(index: number) {
    this.workExperience.removeAt(index);
  }

  // Technical Proficiency Score form array functionality

  get technicalProficiency(): FormArray {
    return this.candidateForm.get('technicalProficiency') as FormArray;
  }

  createAssessment(): FormGroup {
    return this.fb.group({
      selectAssessment: ['', ],
      assessmentUrl: ['', ],
      score: ['', ]

      // selectAssessment: ['', Validators.required],
      // assessmentUrl: ['', [Validators.required, Validators.pattern('https?://.+')]],
      // score: ['', [Validators.required, Validators.min(0), Validators.max(100)]]
    });
  }

  addAssessment(): void {
    this.technicalProficiency.push(this.createAssessment());
  }

  removeAssessment(index: number): void {
    this.technicalProficiency.removeAt(index);
  }

  getTechnicalProficiencyByRole() {
    this.loader = true
    let queryData = {
      role_category_id: this.candidateCategoryRecord?.id,
    }
    this.resumeParseService.getTechnicalProficiencyByRoleCategory(queryData).subscribe(
      (res: any) => {
        if (res?.status === 200) {
          this.loader = false
          this.technicalProficiencyByRole = res?.data?.technical_proficiencies;
          this.technicalProficiency.clear();
          this.technicalProficiencyByRole.forEach((item: any) => {
            this.technicalProficiency.push(
              this.fb.group({
                selectAssessment: [item?.name_of_proficiency || '', Validators.required],
                assessmentUrl: [item?.assessment_url || '', [Validators.required, Validators.pattern('https?://.+')]],
                score: [item?.score || '', [Validators.required, Validators.min(0), Validators.max(100)]]
              })
            );
          });
          console.log(this.technicalProficiencyByRole, "technicalProficiencyByRole___");
        } else {
          this.loader = false
          this.technicalProficiencyByRole = []
        }
      },
      (err) => {
        this.loader = false
        let errorMessage = 'An error occurred. Please try again later.'
        if (err.error) {
          if (err.error.errors && Object.keys(err.error.errors).length > 0) {
            errorMessage = err.error.errors;
          } else if (err.error.message) {
            errorMessage = err.error.message;
          }
        }
        this.toastr.error(errorMessage);
        console.log(errorMessage, "errorMessage_");
      }
    );
  }

  // Form Submission

  onSubmit() {
    // this.router.navigate(['resume-template'])
    if (this.candidateForm.valid) {
      this.loader = true
      const formData = new FormData();
      formData.append('full_name', this.candidateForm.value.fullName);
      formData.append('email', "admin@gmail.com");
      formData.append('role_category_id', this.candidateForm.value.roleCategory);
      formData.append('phone_number', this.candidateForm.value.phone_number);
      formData.append('email', this.candidateForm.value.email);
      formData.append('role', "651e52d9-6be4-4c7d-a8fa-cd26aa4c3958");
      formData.append('g1_g2_status', '6');
      formData.append('profile_summary', this.candidateForm.value.profileSummary);
      formData.append('age', this.candidateForm.value.age);
      formData.append('rating', this.candidateForm.value.englishEducation);
      formData.append('notice_period', this.candidateForm.value.noticePeriod);
      formData.append('work_experience', JSON.stringify(this.candidateForm.value.workExperience));
      formData.append('cognitive_capability_score', JSON.stringify(this.candidateForm.value.cognitiveCapability));

      if (this.candidateForm.value.image) {
        formData.append('image', this.candidateForm.value.image);
      }
      this.resumeParseService.addCandidate(formData).subscribe(
        (res: any) => {

          if (res?.status === 200) {
            this.loader = false
            this.toastr.success(res.message, 'Success');
            // this.candidateForm.reset();
          } else {
            this.loader = false;
            this.toastr.error(res.message || 'An error occurred. Please try again.', 'Error');
          }
        },
        (err) => {
          this.loader = false;
          let errorMessage = 'An error occurred. Please try again later.'
          if (err.error) {
            if (err.error.errors && Object.keys(err.error.errors).length > 0) {

              for (let field in err.error.errors) {
                if (err.error.errors.hasOwnProperty(field)) {
                  this.toastr.error(err.error.errors[field]);
                }
              }
              errorMessage = err.error.errors;
            } else if (err.error.message) {
              errorMessage = err.error.message;
              this.toastr.error(errorMessage);
            }
          }
        }
      );

    } else {
      console.log("Form is invalid");
      this.candidateForm.markAllAsTouched(); // Force validation messages to appear
      this.toastr.error("Please fill all the required fields.");
      return;
    }

    console.log('Form Data:', this.candidateForm.value);
  }

  onImageUpload(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length) {
      const file = input.files[0];
      this.candidateForm.patchValue({
        image: file
      });
    }
  }

  navigateTo(routePath: any) {
    this.router.navigate([routePath])
  }

  onCategoryChange(event: any): void {
    const selectedCategoryId = event?.value;
    if (!selectedCategoryId) return;
    this.candidateCategoryRecord = this.roleCategoryList.find(
      (category: any) => category?.id === selectedCategoryId
    ) || null;

    if (this.candidateCategoryRecord?.id) {
      this.getTechnicalProficiencyByRole();
    }
  }


  fromYearLessThanToYearValidator(): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      const fromYear = control.get('fromYear')?.value;
      const toYear = control.get('toYear')?.value;

      // If fromYear is greater than toYear, return an error
      if (fromYear && toYear && fromYear > toYear) {
        return { fromYearGreaterThanToYear: true };
      }
      return null;
    };
  }

  // make sure to destory the editor
  ngOnDestroy(): void {
    this.editor.destroy();
  }
}
