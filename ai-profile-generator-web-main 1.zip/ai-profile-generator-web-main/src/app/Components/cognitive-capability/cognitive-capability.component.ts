import { Component } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { MatDialog } from '@angular/material/dialog';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UserService } from 'src/app/services/user.service';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';
import { MasterService } from 'src/app/services/master.service';

@Component({
  selector: 'app-cognitive-capability',
  templateUrl: './cognitive-capability.component.html',
  styleUrls: ['./cognitive-capability.component.scss']
})

export class CognitiveCapabilityComponent {
  limit: any = 10
  pageNumber: any = 1
  totalLength: any = 0
  searchText: any = ''

  displayedColumns: string[] = ['name', 'actions'];
  rolesList: any = [];
  selectedCognitiveId: any = ''
  cognitiveCapabilityForm: FormGroup;
  editcognitiveCapabilityForm: FormGroup;
  selectedRoleId: any;
  cognitiveList: any = []
  selectedCognitiveCapability: any = ''
  loader: boolean = false;

  constructor(private fb: FormBuilder, private modalService: NgbModal, public dialog: MatDialog,
    private toastr: ToastrService, private masterService: MasterService) {

    this.cognitiveCapabilityForm = this.fb.group({
      name: ['', [Validators.required, Validators.minLength(3)]]
    });

    this.editcognitiveCapabilityForm = this.fb.group({
      cognitiveName: ['', Validators.required]
    });

  }

  ngOnInit(): void {
    this.getcognitiveCapability();
  }

  deleteCognitiveCapability() {
    this.loader = true
    if (this.selectedCognitiveId) {
      this.masterService.deleteCognitiveById(this.selectedCognitiveId).subscribe(
        (res: any) => {
          if (res?.status === 200) {
            this.toastr.success(res.message, "Success");
            this.modalService.dismissAll();
            this.getcognitiveCapability();
          } else {
            this.toastr.error(res.message || "Failed to delete work style.", "Error");
          }
        },
        (err) => {
          this.loader = false;
          let errorMessage = 'An error occurred. Please try again later.';
          if (err?.error) {
            if (err?.error?.errors && Object.keys(err?.error?.errors).length > 0) {
              errorMessage = err?.error?.errors;
              this.toastr.error(errorMessage, 'Error');
            } else if (err?.error?.message) {
              errorMessage = err?.error?.message;
              this.toastr.error(errorMessage, 'Error');
            }
          }
          this.toastr.error(errorMessage, 'Error');
        }
      );
    } else {
      this.toastr.error("CognitiveCapability ID is missing!", "Error");
    }
  }

  onSubmitAdd() {

    if (this.cognitiveCapabilityForm.valid) {
      this.loader = true
      const { name } = this.cognitiveCapabilityForm.value;

      this.masterService.addcognitiveCapability({ name }).subscribe(
        (res: any) => {

          if (res?.status === 200) {
            this.toastr.success(res.message, 'Success');
            this.modalService.dismissAll();
            this.cognitiveCapabilityForm.reset()
            this.getcognitiveCapability();
          } else {

            this.toastr.error(res.message || 'An error occurred. Please try again.', 'Error');
          }
        },
        (err) => {
          this.loader = false;
          let errorMessage = 'An error occurred. Please try again later.';
          if (err?.error) {
            if (err?.error?.errors && Object.keys(err?.error?.errors).length > 0) {
              for (let field in err.error.errors) {
                if (err.error.errors.hasOwnProperty(field)) {
                  this.toastr.error(err.error.errors[field]);
                }
              }
            } else if (err?.error?.message) {
              errorMessage = err?.error?.message;
              this.toastr.error(errorMessage, 'Error');
            }
          }
        }
      );
    } else {
      this.toastr.error("Please fill all required fields");
      this.cognitiveCapabilityForm.markAllAsTouched();
    }
  }

  onSubmitEdit() {
    if (this.editcognitiveCapabilityForm.valid) {
      this.loader = true
      const { cognitiveName } = this.editcognitiveCapabilityForm.value;
      let data = {
        name: cognitiveName,
        cognitive_capability_id: this.selectedCognitiveId
      }
      this.masterService.updatecognitiveCapability(data).subscribe(
        (res: any) => {
          if (res?.status === 200) {
            this.toastr.success(res.message, 'Success');
            this.modalService.dismissAll();
            this.getcognitiveCapability();
          } else {
            this.toastr.error(res.message || 'An error occurred. Please try again.', 'Error');
          }
        },
        (err) => {
          this.loader = false;
          let errorMessage = 'An error occurred. Please try again later.';
          if (err?.error) {
            if (err?.error?.errors && Object.keys(err?.error?.errors).length > 0) {
              for (let field in err.error.errors) {
                if (err.error.errors.hasOwnProperty(field)) {
                  this.toastr.error(err.error.errors[field]);
                }
              }
            } else if (err?.error?.message) {
              errorMessage = err?.error?.message;
              this.toastr.error(errorMessage, 'Error');
            }
          }
        }
      );
    } else {
      this.toastr.error("Please select all required fields");
      this.editcognitiveCapabilityForm.markAllAsTouched();
    }
  }

  getcognitiveCapability() {
    this.loader = true
    let queryData = {
      limit: this.limit,
      page: this.pageNumber,
      searchText: this.searchText
    }
    this.masterService.getcognitiveCapability(queryData).subscribe(
      (res: any) => {
        if (res?.status === 200) {
          this.cognitiveList = res?.data?.cognitive_capabilities;
          this.totalLength = res?.data?.total;
          this.loader = false
        } else {
          this.loader = false;
          this.cognitiveList = [];
          this.totalLength = 0
        }
      },
      (err) => {
        this.loader = false;
        if (err?.status !== 401) {
          let errorMessage = 'An error occurred. Please try again later.';
          if (err?.error) {
            if (err?.error?.errors && Object.keys(err?.error?.errors).length > 0) {
              errorMessage = err?.error?.errors;
              this.toastr.error(errorMessage, 'Error');
            } else if (err?.error?.message) {
              errorMessage = err?.error?.message;
              this.toastr.error(errorMessage, 'Error');
            }
          }
          this.toastr.error(errorMessage, 'Error');
        }
      }
    );
  }

  getcognitiveCapabilityById(cognitiveId: any) {

    this.loader = true;
    this.masterService.getcognitiveById(cognitiveId).subscribe(
      (res: any) => {
        if (res?.status === 200 && res?.data) {
          this.selectedCognitiveId = res.data.id;
          this.editcognitiveCapabilityForm.patchValue({
            cognitiveName: this.toTitleCase(res.data.name)
          });

        } else {
          this.toastr.error(res?.message || 'An error occurred', 'Error');
        }
        this.loader = false;
      },
      (err) => {
        this.loader = false;
        if (err?.status !== 401) {
          let errorMessage = 'An error occurred. Please try again later.';
          if (err?.error) {
            if (err?.error?.errors && Object.keys(err?.error?.errors).length > 0) {
              errorMessage = err?.error?.errors;
              this.toastr.error(errorMessage, 'Error');
            } else if (err?.error?.message) {
              errorMessage = err?.error?.message;
              this.toastr.error(errorMessage, 'Error');
            }
          }
          this.toastr.error(errorMessage, 'Error');
        }
      }
    );
  }

  get name() {
    return this.cognitiveCapabilityForm.get('name');
  }

  openModalcognitiveadd(addcontent: any) {
    this.modalService.open(addcontent, {
      centered: true,
      size: "md",
      windowClass: "master_modal add_content",
    });
  }

  openModaleditcog(edit: any, scoreDescriptionId: any) {
    if (scoreDescriptionId) {
      this.selectedCognitiveId = scoreDescriptionId;
      this.getcognitiveCapabilityById(scoreDescriptionId)
    }
    this.modalService.open(edit, {
      centered: true,
      size: "md",
      windowClass: "master_modal add_content",
    });
  }

  openModaldeletecog(deleteModal: any, scoreDescriptionId: any) {
    if (scoreDescriptionId) {
      this.selectedCognitiveId = scoreDescriptionId;
    }
    this.modalService.open(deleteModal, {
      centered: true,
      size: "md",
      windowClass: "master_modal add_content",
    });
  }

  handlePageEvent(event: any) {
    this.limit = event?.pageSize;
    this.pageNumber = event?.pageIndex + 1
    this.getcognitiveCapability()
  }

  clearAll() {
    this.searchText = '';
    this.selectedCognitiveId = '';
    this.getcognitiveCapability();
  }

  onSearchChange(searchTexts: any) {
    const trimmedText = searchTexts?.trim();
    if (trimmedText) {
      this.searchText = searchTexts;
      this.getcognitiveCapability();
    } else if (searchTexts === "") {
      this.getcognitiveCapability();
    }
  }

  toTitleCase(str: string): string {
    return str
      ?.toLowerCase()
      ?.split(' ')
      ?.map(word => word.charAt(0).toUpperCase() + word.slice(1))
      ?.join(' ');
  }

}
