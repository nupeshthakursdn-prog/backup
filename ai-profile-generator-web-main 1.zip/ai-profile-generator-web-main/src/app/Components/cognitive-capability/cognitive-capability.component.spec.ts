import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CognitiveCapabilityComponent } from './cognitive-capability.component';

describe('CognitiveCapabilityComponent', () => {
  let component: CognitiveCapabilityComponent;
  let fixture: ComponentFixture<CognitiveCapabilityComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [CognitiveCapabilityComponent]
    });
    fixture = TestBed.createComponent(CognitiveCapabilityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
