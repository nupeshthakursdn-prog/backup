import { Component } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
// import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ChangeDetectionStrategy, inject } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { UserService } from 'src/app/services/user.service';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { MasterService } from 'src/app/services/master.service';
@Component({
  selector: 'app-theme-setting',
  templateUrl: './theme-setting.component.html',
  styleUrls: ['./theme-setting.component.scss']
})
export class ThemeSettingComponent {
  logoPreview: string | ArrayBuffer | null = null;
  primaryColor: string = '#007bff';
  selectedFileName: any = '';
  loader: boolean = false;
  brandingDetails: any;
  brandLogo: any = ''
  selectedFile: any = '';
  branding_id: any = '';
  selectedFiles: { [key: string]: File } = {};
  templateHeaderImgMain: string | ArrayBuffer | null = null;
  templateHeaderImg: string | ArrayBuffer | null = null;
  templateHeaderImgMainPreview: any = '';
  templateHeaderImgPreview: any = '';

  constructor(private fb: FormBuilder, private modalService: NgbModal, public dialog: MatDialog,
    private userService: UserService, private router: Router, private toastr: ToastrService) { }

  ngOnInit(): void {
    this.getBrandSettingDetails();
  }

  getBrandSettingDetails() {
    this.loader = true;
    this.userService.getBrandingDetails({}).subscribe(
      (res: any) => {
        if (res?.status === 200) {
          this.loader = false;
          this.brandingDetails = res?.data;
          this.primaryColor = res?.data?.theme_color;
          this.brandLogo = res?.data?.logo;
          this.templateHeaderImgPreview = res?.data?.templateHeaderImg;
          this.templateHeaderImgMainPreview = res?.data?.templateHeaderImgMain;
          this.branding_id = res?.data?.id;
        } else {
          this.loader = false;
          this.toastr.error(res.message || 'An error occurred. Please try again.', 'Error');
        }
      },
      (err) => {
        this.loader = false;
        if (err?.status !== 401) {
          let errorMessage = 'An error occurred. Please try again later.'
          if (err.error) {
            if (err.error.errors && Object.keys(err.error.errors).length > 0) {
              errorMessage = err.error.errors;
            } else if (err.error.message) {
              errorMessage = err.error.message;
            }
          }
          this.toastr.error(errorMessage, 'Error');
        }
      }
    );
  }

  onFileUpload(event: Event, fieldName: string): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files[0]) {
      const file = input.files[0];

      // Ensure selectedFiles is an object before assigning
      if (!this.selectedFiles) {
        this.selectedFiles = {};
      }

      this.selectedFiles[fieldName] = file; // ✅ Dynamically assign based on fieldName

      // Handle preview
      const reader = new FileReader();
      reader.onload = (e) => {
        if (fieldName === 'logo') {
          this.brandLogo = e.target?.result as string;
        } else if (fieldName === 'templateHeaderImgMain') {
          this.templateHeaderImgMainPreview = e.target?.result as string;
        } else if (fieldName === 'templateHeaderImg') {
          this.templateHeaderImgPreview = e.target?.result as string;
        }
      };
      reader.readAsDataURL(file);
    }
  }


  saveBrandSettings(): void {
    if (this.branding_id && (this.primaryColor || Object.keys(this.selectedFiles).length > 0)) {
      this.loader = true;
      const formData = new FormData();

      if (this.primaryColor) {
        formData.append('theme_color', this.primaryColor);
      }

      if (this.selectedFiles['logo']) {
        formData.append('logo', this.selectedFiles['logo'], this.selectedFiles['logo'].name);
      }

      if (this.selectedFiles['templateHeaderImgMain']) {
        formData.append('templateHeaderImgMain', this.selectedFiles['templateHeaderImgMain'], this.selectedFiles['templateHeaderImgMain'].name);
      }

      if (this.selectedFiles['templateHeaderImg']) {
        formData.append('templateHeaderImg', this.selectedFiles['templateHeaderImg'], this.selectedFiles['templateHeaderImg'].name);
      }


      formData.append('branding_id', String(this.branding_id));

      this.userService.updateBrandingDetails(formData).subscribe(
        (res: any) => {
          this.loader = false;
          if (res?.status === 200) {
            this.toastr.success(res.message, 'Success');
            this.modalService.dismissAll();
            this.getBrandSettingDetails();
          } else {
            this.toastr.error(res.message || 'An error occurred. Please try again.', 'Error');
          }
        },
        (err) => {
          this.loader = false;
          if (err?.status !== 401) {
            let errorMessage = 'An error occurred. Please try again later.';

            if (err.error) {
              if (err.error.errors && Object.keys(err.error.errors).length > 0) {
                for (let field in err.error.errors) {
                  if (err.error.errors.hasOwnProperty(field)) {
                    this.toastr.error(err.error.errors[field]);
                  }
                }
                errorMessage = err.error.errors;
              } else if (err.error.message) {
                errorMessage = err.error.message;
                this.toastr.error(errorMessage);
              }
            }
          }
        }
      );
    } else {
      this.loader = false;
      this.toastr.error('Please select at least one image or color theme.');
    }
  }

  triggerFileInput(fieldId: string): void {
    const fileInput = document.getElementById(fieldId) as HTMLInputElement;
    fileInput.click();
  }


}
