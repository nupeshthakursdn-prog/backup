import { Component } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { MatDialog } from '@angular/material/dialog';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UserService } from 'src/app/services/user.service';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';
import { MasterService } from 'src/app/services/master.service';

@Component({
  selector: 'app-role-category',
  templateUrl: './role-category.component.html',
  styleUrls: ['./role-category.component.scss']
})
export class RoleCategoryComponent {
  limit: any = 10
  pageNumber: any = 1
  totalLength: any = 0
  searchText: any = ''

  displayedColumns: string[] = ['name', 'actions'];
  dataSource: any = [];
  roleCategoryList: any = [];
  roleCategoryForm: FormGroup;
  editRoleCategoryForm: FormGroup;
  selectedRoleCategoryId: any = ''
  loader: boolean = false;

  constructor(private fb: FormBuilder, private modalService: NgbModal, public dialog: MatDialog,
    private userService: UserService, private masterService: MasterService, private router: Router, private toastr: ToastrService) {

    this.roleCategoryForm = this.fb.group({
      categoryName: ['', [Validators.required, Validators.minLength(3)]]
    });

    this.editRoleCategoryForm = this.fb.group({
      categoryName: ['', Validators.required]
    });

  }

  ngOnInit(): void {
    this.getRolecategoryList();
  }

  getRolecategoryList() {
    this.loader = true;
    let queryData = {
      limit: this.limit,
      page: this.pageNumber,
      searchText: this.searchText
    }

    this.masterService.getRoleCategory(queryData).subscribe(
      (res: any) => {
        if (res?.status === 200) {
          this.loader = false;
          this.roleCategoryList = res?.data?.role_categories;
          this.totalLength = res?.data?.total;
        } else {
          this.loader = false;
          this.roleCategoryList = []
          this.toastr.error(res.message || 'An error occurred. Please try again.', 'Error');
        }
      },
      (err) => {
        this.loader = false;
        if (err?.status !== 401) {
          let errorMessage = 'An error occurred. Please try again later.'
          if (err.error) {
            if (err.error.errors && Object.keys(err.error.errors).length > 0) {
              errorMessage = err.error.errors;
            } else if (err.error.message) {
              errorMessage = err.error.message;
            }
          }
          this.toastr.error(errorMessage, 'Error');
        }
      }
    );
  }

  getRoleCategoryById() {
    this.loader = true;
    this.masterService.getRoleCategoryById({ id: this.selectedRoleCategoryId }).subscribe(
      (res: any) => {
        if (res?.status === 200) {
          this.loader = false
          this.editRoleCategoryForm.patchValue({
            categoryName: this.toTitleCase(res?.data?.name)
          });
        } else {
          this.loader = false
          this.toastr.error(res.message || 'An error occurred. Please try again.', 'Error');
        }
      },
      (err) => {
        this.loader = false
        if (err?.status !== 401) {
          let errorMessage = 'An error occurred. Please try again later.'
          if (err.error) {
            if (err.error.errors && Object.keys(err.error.errors).length > 0) {
              errorMessage = err.error.errors;
            } else if (err.error.message) {
              errorMessage = err.error.message;
            }
          }
          this.toastr.error(errorMessage, 'Error');
        }
      }
    );
  }

  deleteRoleCategory() {
    this.loader = true;
    this.masterService.deleteRoleCategoryById({ id: this.selectedRoleCategoryId }).subscribe(
      (res: any) => {
        if (res?.status === 200) {
          this.loader = false;
          this.toastr.success(res.message, 'Success');
          this.modalService.dismissAll();
          this.getRolecategoryList();
        } else {
          this.loader = false;
          this.toastr.error(res.message || 'An error occurred. Please try again.', 'Error');
        }
      },
      (err) => {
        this.loader = false;
        if (err?.status !== 401) {
          let errorMessage = 'An error occurred. Please try again later.'
          if (err.error) {
            if (err.error.message) {
              errorMessage = err.error.message;
            } else if (err.error.errors && Object.keys(err.error.errors).length > 0) {
              for (let field in err.error.errors) {
                if (err.error.errors.hasOwnProperty(field)) {
                  this.toastr.error(err.error.errors[field]);
                }
              }
            }
          }
          this.toastr.error(errorMessage, 'Error');
        }
      }
    );
  }

  onSubmitAdd() {
    if (this.roleCategoryForm.valid) {
      this.loader = true;
      // Extract form data to pass to your API
      const { categoryName } = this.roleCategoryForm.value;

      // Call your API method (replace createRole with your actual method)
      this.masterService.addRoleCategory({ name: categoryName }).subscribe(
        (res: any) => {

          if (res?.status === 200) {
            this.loader = false;
            this.toastr.success(res.message, 'Success');
            this.modalService.dismissAll();
            this.roleCategoryForm.reset()
            this.getRolecategoryList();
          } else {
            this.loader = false;
            this.toastr.error(res.message || 'An error occurred. Please try again.', 'Error');
          }
        },
        (err) => {
          this.loader = false;
          if (err?.status !== 401) {
            let errorMessage = 'An error occurred. Please try again later.'
            if (err.error) {
              if (err.error.errors && Object.keys(err.error.errors).length > 0) {
                for (let field in err.error.errors) {
                  if (err.error.errors.hasOwnProperty(field)) {
                    this.toastr.error(err.error.errors[field]);
                  }
                }
                errorMessage = err.error.errors;
              } else if (err.error.message) {
                errorMessage = err.error.message;
                this.toastr.error(errorMessage);
              }
            }
          }
        }
      );
    } else {
      this.toastr.error('Please enter all required fields');
      this.roleCategoryForm.markAllAsTouched();
    }
  }

  onSubmitEdit() {
    if (this.editRoleCategoryForm.valid) {
      this.loader = true;
      const { categoryName } = this.editRoleCategoryForm.value;
      let data = {
        name: categoryName,
        role_category_id: this.selectedRoleCategoryId
      }
      this.masterService.updateRoleCategoryById(data).subscribe(
        (res: any) => {
          if (res?.status === 200) {
            this.loader = false;
            this.toastr.success(res.message, 'Success');
            this.modalService.dismissAll();
            this.getRolecategoryList();
          } else {
            this.loader = false;
            this.toastr.error(res.message || 'An error occurred. Please try again.', 'Error');
          }
        },
        (err) => {
          this.loader = false;
          if (err?.status !== 401) {
            let errorMessage = 'An error occurred. Please try again later.'
            if (err.error) {
              if (err.error.errors && Object.keys(err.error.errors).length > 0) {
                for (let field in err.error.errors) {
                  if (err.error.errors.hasOwnProperty(field)) {
                    this.toastr.error(err.error.errors[field]);
                  }
                }
                errorMessage = err.error.errors;
              } else if (err.error.message) {
                this.toastr.error(errorMessage);
                errorMessage = err.error.message;
              }
            }
          }
        }
      );
    }
  }

  get categoryName() {
    return this.roleCategoryForm.get('categoryName');
  }

  openModalAddCategory(addCategory: any) {
    this.modalService.open(addCategory, {
      centered: true,
      size: "md",
      windowClass: "master_modal add_content",
    });
  }

  openModalEditCategory(editCategory: any, categoryId: any) {
    if (categoryId) {
      this.selectedRoleCategoryId = categoryId;
      this.getRoleCategoryById()
    }
    this.modalService.open(editCategory, {
      centered: true,
      size: "md",
      windowClass: "master_modal add_content",
    });
  }

  openModaldelete(deleteModal: any, categoryId: any) {
    if (categoryId) {
      this.selectedRoleCategoryId = categoryId;
    }
    this.modalService.open(deleteModal, {
      centered: true,
      size: "md",
      windowClass: "master_modal add_content",
    });
  }

  onSearchChange(searchTexts: any) {
    const trimmedText = searchTexts?.trim();
    if (trimmedText) {
      this.searchText = searchTexts;
      this.getRolecategoryList();
    } else if (searchTexts === "") {
      this.getRolecategoryList();
    }
  }

  clearAll() {
    this.searchText = '';
    this.selectedRoleCategoryId = '';
    this.getRolecategoryList();
  }

  handlePageEvent(event: any) {
    this.limit = event?.pageSize;
    this.pageNumber = event?.pageIndex + 1
    this.getRolecategoryList();
  }

  toTitleCase(str: string): string {
    return str
      ?.toLowerCase()
      ?.split(' ')
      ?.map(word => word.charAt(0).toUpperCase() + word.slice(1))
      ?.join(' ');
  }

}
