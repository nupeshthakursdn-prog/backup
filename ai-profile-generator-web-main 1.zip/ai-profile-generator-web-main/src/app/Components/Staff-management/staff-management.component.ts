import { Component } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
// import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ChangeDetectionStrategy, inject } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UserService } from 'src/app/services/user.service';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
// import { CreateRoleComponent } from './create-role/create-role.component';

export interface PeriodicElement {
  name: string;
  role: string;
  email: string;
  mobile: string;
  status: any;
  image: any;
  actions: string

}
const ELEMENT_DATA: PeriodicElement[] = [
  {
    name: 'Alice Johnson',
    role: 'Admin',
    email: 'alice@example.com',
    mobile: '123-456-7890',
    status: 'Active',
    image: 'assets/images/user1.jpg',
    actions: 'Edit/Delete',
  },
  {
    name: 'Bob Smith',
    role: 'Manager',
    email: 'bob@example.com',
    mobile: '987-654-3210',
    status: 'Inactive',
    image: 'assets/images/user2.jpg',
    actions: 'Edit/Delete',
  },
];



@Component({
  selector: 'app-staff-management',
  templateUrl: './staff-management.component.html',
  styleUrls: ['./staff-management.component.scss']
})
export class StaffManagementComponent {

  loader: boolean = false
  limit: any = 10
  pageNumber: any = 1
  totalLength: any = 0
  searchText: any = ''

  displayedColumns: string[] = ['name', 'role', 'email', 'mobile', 'status', 'image', 'actions'];
  dataSource = ELEMENT_DATA;
  rolesList: any = []
  staffList: any = []
  userForm: FormGroup;
  updateUserForm: FormGroup;
  status_filter: any = ["Active", "Deactivated"]
  selectedStaffId: any = '';
  statusValue: any = '';
  selectedRole: any = '';
  selectedEmail: any = '';
  profile_pic: any = ''
  editimage: any = ''
  constructor(private fb: FormBuilder, private modalService: NgbModal, public dialog: MatDialog,
    private userService: UserService, private router: Router, private toastr: ToastrService) {

    this.userForm = this.fb.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      role: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      phone: ['', [
        Validators.required,
        // Validators.pattern(/^\d{40}$/) 
      ]],
      jobTitle: ['', Validators.required],
      // password: ['', Validators.required],
      image: [null], // optional file upload
      status: [true], // optional toggle switch (default false)
      displayAllCandidates: [false], // Added displayAllCandidates field
    });

    this.updateUserForm = this.fb.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      role: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      phone: ['', Validators.required],
      jobTitle: ['', Validators.required],
      // password: ['', Validators.required],
      image: [null], // File upload – no validation
      status: [false], // Checkbox
      staff_id: ['', Validators.required],
      displayAllCandidates: [false] // Added displayAllCandidates field
    });

  }

  ngOnInit(): void {
    // this.loaderService.show()
    this.getRoles();
    this.getStaffList();
  }



  getRoles() {

    let queryData = {
      limit: '',
      page: '',
      searchText: ''
    }
    this.userService.getRoles(queryData).subscribe(
      (res: any) => {
        if (res?.status === 200) {
          this.rolesList = res?.data?.roles;
        } else {
          this.rolesList = []
        }
      },
      (err) => {
        if (err?.status !== 401) {
          let errorMessage = 'An error occurred. Please try again later.'
          if (err.error) {
            if (err.error.errors && Object.keys(err.error.errors).length > 0) {
              errorMessage = err.error.errors;
            } else if (err.error.message) {
              errorMessage = err.error.message;
            }
          }
        }
      }
    );
  }

  getStaffList() {
    this.loader = true
    let queryData = {
      limit: this.limit,
      page: this.pageNumber,
      searchText: this.searchText,
      status: this.statusValue,
      role: this.selectedRole
    }
    this.userService.getStaffs(queryData).subscribe(
      (res: any) => {
        if (res?.status === 200) {
          this.staffList = res?.data?.staffs;
          this.totalLength = res?.data?.total;
          this.loader = false
        } else {
          this.loader = false;
          this.staffList = [];
          this.totalLength = 0
        }
      },
      (err) => {
        this.loader = false;
        if (err?.status !== 401) {
          let errorMessage = 'An error occurred. Please try again later.'
          if (err.error) {
            if (err.error.errors && Object.keys(err.error.errors).length > 0) {
              errorMessage = err.error.errors;
            } else if (err.error.message) {
              errorMessage = err.error.message;
            }
          }
        }
      }
    );
  }

  getStaffById() {
    this.loader = true;
    this.userService.getStaffById({ id: this.selectedStaffId }).subscribe(
      (res: any) => {
        if (res?.status === 200) {

          this.updateUserForm.patchValue({
            firstName: res?.data?.first_name,
            lastName: res?.data?.last_name,
            role: res?.data?.role,
            email: res?.data?.email,
            phone: res?.data?.phone_number,
            jobTitle:this.toTitleCase(res?.data?.job_title),
            status: res?.data?.status === 'active' ? true : false,
            displayAllCandidates: res?.data?.display_all_candidates, // Added display_all_candidates
            staff_id: this.selectedStaffId
          });
          this.editimage = res.data.image;
          this.loader = false;
        } else {
          this.loader = false;
          this.toastr.error(res?.message || 'An error occurred. Please try again.', 'Error');
        }
      },
      (err) => {
        this.loader = false;
        if (err?.status !== 401) {
          let errorMessage = 'An error occurred. Please try again later.'
          if (err.error) {
            if (err.error.errors && Object.keys(err.error.errors).length > 0) {
              errorMessage = err.error.errors;
            } else if (err.error.message) {
              errorMessage = err.error.message;
            }
          }
          this.toastr.error(errorMessage, 'Error');
        }
      }
    );
  }


  onSubmit(): void {
    if (this.userForm.valid) {
      this.loader = true

      // const formdata = {
      //   first_name: this.userForm.value.firstName,
      //   last_name: this.userForm.value.lastName,
      //   role: this.userForm.value.role,
      //   email: this.userForm.value.email,
      //   phone_number: this.userForm.value.phone,
      //   password: 'Admin@123',
      //   image: this.userForm.value.image,
      //   status: this.userForm.value.status ? "active" : "deactivated",
      //   is_staff: true
      // };
      const formData = new FormData();
      formData.append('first_name', this.userForm.value.firstName);
      formData.append('last_name', this.userForm.value.lastName);
      formData.append('role', this.userForm.value.role);
      formData.append('email', this.userForm.value.email);
      formData.append('phone_number', this.userForm.value.phone);
      formData.append('job_title', this.userForm.value.jobTitle);
      formData.append('password', "Admin@123");
      formData.append('is_staff', 'true');
      formData.append('status', this.userForm.value.status ? 'active' : 'deactivated');
      formData.append('display_all_candidates', this.userForm.value.displayAllCandidates ? 'true' : 'false'); // Added display_all_candidates


      if (this.userForm.value.image) {
        formData.append('image', this.userForm.value.image);
      }
      this.userService.addStaff(formData).subscribe(
        (res: any) => {

          if (res?.status === 200) {
            this.loader = false
            this.toastr.success(res.message, 'Success');
            this.modalService.dismissAll();
            this.userForm.reset();
            this.userForm.patchValue({
              status: true,
              displayAllCandidates: false // Reset displayAllCandidates
            })
            this.getStaffList();
            this.editimage = ''
          } else {
            this.loader = false;
            this.toastr.error(res.message || 'An error occurred. Please try again.', 'Error');
          }
        },
        (err) => {
          this.loader = false;
          if (err?.status !== 401) {
            let errorMessage = 'An error occurred. Please try again later.'
            if (err.error) {
              if (err.error.errors && Object.keys(err.error.errors).length > 0) {

                for (let field in err.error.errors) {
                  if (err.error.errors.hasOwnProperty(field)) {
                    this.toastr.error(err.error.errors[field]);
                  }
                }
                errorMessage = err.error.errors;
              } else if (err.error.message) {
                errorMessage = err.error.message;
                this.toastr.error(errorMessage);
              }
            }
          }
        }
      );
    } else {
      this.userForm.markAllAsTouched();
      this.toastr.error('Please enter all required fields');

    }
  }


  onSubmitUpdate(): void {

    if (this.updateUserForm.valid) {
      this.loader = true
      const formData = new FormData();
      formData.append('first_name', this.updateUserForm.value.firstName);
      formData.append('last_name', this.updateUserForm.value.lastName);
      formData.append('role', this.updateUserForm.value.role);
      formData.append('email', this.updateUserForm.value.email);
      formData.append('phone_number', this.updateUserForm.value.phone);
      formData.append('job_title', this.updateUserForm.value.jobTitle);
      // formData.append('password', this.updateUserForm.value.password);
      formData.append('staff_id', this.updateUserForm.value.staff_id);
      formData.append('status', this.updateUserForm.value.status ? 'active' : 'deactivated');
      formData.append('display_all_candidates', this.updateUserForm.value.displayAllCandidates ? 'true' : 'false'); // Added display_all_candidates


      if (this.updateUserForm.value.image) {
        formData.append('image', this.updateUserForm.value.image);
      }

      this.userService.updateStaffById(formData).subscribe(
        (res: any) => {
          if (res?.status === 200) {
            this.loader = false
            this.toastr.success(res.message, 'Success');
            this.modalService.dismissAll();
            this.getStaffList();
            this.editimage = ''
          } else {
            this.loader = false;
            this.toastr.error(res.message || 'An error occurred. Please try again.', 'Error');
          }
        },
        (err) => {

          this.loader = false;
          if (err?.status !== 401) {
            let errorMessage = 'An error occurred. Please try again later.'
            if (err.error) {
              if (err.error.errors && Object.keys(err.error.errors).length > 0) {
                for (let field in err.error.errors) {
                  if (err.error.errors.hasOwnProperty(field)) {
                    this.toastr.error(err.error.errors[field]);
                  }
                }
                errorMessage = err.error.errors;
              } else if (err.error.message) {
                errorMessage = err.error.message;
                this.toastr.error(errorMessage);
              }
            }
          }
        }
      );
      // Now, pass formData to your API via a service.
    } else {
      this.toastr.error('Please enter all required fields');
      // Mark all controls as touched to trigger validation messages.
      this.updateUserForm.markAllAsTouched();
    }
  }

  deleteStaff() {
    this.loader = true
    this.userService.deleteStaffById({ id: this.selectedStaffId }).subscribe(
      (res: any) => {
        if (res?.status === 200) {
          this.loader = false
          this.toastr.success(res.message, 'Success');
          this.modalService.dismissAll();
          this.getStaffList()
        } else {
          this.loader = false;
          this.toastr.error(res.message || 'An error occurred. Please try again.', 'Error');
        }
      },
      (err) => {
        this.loader = false;
        let errorMessage = 'An error occurred. Please try again later.'
        if (err.error) {
          if (err.error.errors && Object.keys(err.error.errors).length > 0) {
            errorMessage = err.error.errors;
          } else if (err.error.message) {
            errorMessage = err.error.message;
          }
        }
        this.toastr.error(errorMessage, 'Error');
      }
    );
  }

  toggleStatus(element: any, event: Event) {
    this.loader = true
    const isChecked = (event.target as HTMLInputElement).checked;

    let status_value = isChecked ? 'active' : 'deactivated';

    this.userService.updateStaffById({ status: status_value, staff_id: element?.id }).subscribe(
      (res: any) => {
        if (res?.status === 200) {
          this.loader = false
          this.toastr.success(res.message, 'Success');
          this.modalService.dismissAll();
          this.getStaffList();
        } else {
          this.loader = false
          this.toastr.error(res.message || 'An error occurred. Please try again.', 'Error');
        }
      },
      (err) => {
        this.loader = false
        let errorMessage = 'An error occurred. Please try again later.'
        if (err.error) {
          if (err.error.errors && Object.keys(err.error.errors).length > 0) {
            errorMessage = err.error.errors;
          } else if (err.error.message) {
            errorMessage = err.error.message;
          }
        }
        this.toastr.error(errorMessage, 'Error');
      }
    );

  }

  sendSetPasswordLink() {
    this.loader = true;
    this.userService.sendSetPasswordLink({ email: this.selectedEmail }).subscribe(
      (res: any) => {
        if (res?.status === 200) {
          this.loader = false;
          this.toastr.success(res.message, 'Success');
          this.modalService.dismissAll();
          this.getStaffList()
        } else {
          this.loader = false;
          this.toastr.error(res.message || 'An error occurred. Please try again.', 'Error');
        }
      },
      (err) => {
        this.loader = false;
        let errorMessage = 'An error occurred. Please try again later.'
        if (err.error) {
          if (err.error.errors && Object.keys(err.error.errors).length > 0) {
            errorMessage = err.error.errors;
          } else if (err.error.message) {
            errorMessage = err.error.message;
          }
        }
        this.toastr.error(errorMessage, 'Error');
      }
    );
  }

  onSearchChange(searchTexts: any) {
    const trimmedText = searchTexts?.trim();
    if (trimmedText) {
      this.searchText = searchTexts;
      this.getStaffList();
    } else if (searchTexts === "") {
      this.getStaffList();
    }
  }

  onStatusChange(event: any) {
    if (event?.value) {
      this.statusValue = event?.value;
      this.getStaffList()
    }
  }

  onRoleSelectionChange(event: any) {
    if (event?.value) {
      this.selectedRole = event?.value;
      this.getStaffList()
    }
  }

  clearAll() {
    if (this.searchText || this.statusValue || this.selectedRole) {
      this.searchText = '';
      this.statusValue = '';
      this.selectedRole = '';
      this.getStaffList();
    }
  }

  onFileChange(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length) {
      const file = input.files[0];
      this.userForm.patchValue({
        image: file
      });

      // Convert the file to base64 for preview
      const reader = new FileReader();

      reader.onload = () => {
        // This will store the Base64 string
        const base64String = reader.result as string;

        // Optionally store base64 string in a variable for preview binding
        this.editimage = base64String;
      };

      // Read the file as a data URL (Base64)
      reader.readAsDataURL(file);

    }
  }
  onFileChangeupdate(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length) {
      const file = input.files[0];
      this.updateUserForm.patchValue({
        image: file
      });

      // Convert the file to base64 for preview
      const reader = new FileReader();

      reader.onload = () => {
        // This will store the Base64 string
        const base64String = reader.result as string;

        // Optionally store base64 string in a variable for preview binding
        this.editimage = base64String;
      };

      // Read the file as a data URL (Base64)
      reader.readAsDataURL(file);
    }
  }


  openModalAdd(addStaff: any) {
    this.modalService.open(addStaff, {
      centered: true,
      size: "md",
      windowClass: "master_modal add_content",
    });
  }

  openModaledit(edit: any, staffId: any) {
    if (staffId) {
      this.selectedStaffId = staffId;
      this.getStaffById();
    }
    this.modalService.open(edit, {
      centered: true,
      size: "md",
      windowClass: "master_modal add_content",
    });
  }

  deleteStaffMember() {
    if (this.selectedStaffId) {
      this.deleteStaff()
    }
  }

  openModaldelete(deleteModal: any, staffId: any) {
    if (staffId) {
      this.selectedStaffId = staffId;
    }
    this.modalService.open(deleteModal, {
      centered: true,
      size: "md",
      windowClass: "master_modal add_content",
    });
  }

  openModalNewPasswordSet(passwordSet: any, element: any) {
    if (element?.email) {
      this.selectedEmail = element?.email;
    }
    this.modalService.open(passwordSet, {
      centered: true,
      size: "md",
      windowClass: "master_modal add_content",
    });
  }

  handlePageEvent(event: any) {
    this.limit = event?.pageSize;
    this.pageNumber = event?.pageIndex + 1
    this.getStaffList()
  }

  toTitleCase(str: string): string {
    return str
      ?.toLowerCase()
      ?.split(' ')
      ?.map(word => word.charAt(0).toUpperCase() + word.slice(1))
      ?.join(' ');
  }

}
