import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AiResumeTemplateComponent } from './ai-resume-template.component';

describe('AiResumeTemplateComponent', () => {
  let component: AiResumeTemplateComponent;
  let fixture: ComponentFixture<AiResumeTemplateComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AiResumeTemplateComponent]
    });
    fixture = TestBed.createComponent(AiResumeTemplateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
