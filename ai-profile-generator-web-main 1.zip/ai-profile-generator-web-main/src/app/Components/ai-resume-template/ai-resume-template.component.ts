import { Component, ElementRef, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { environment } from 'src/environments/environment';
import * as CryptoJS from 'crypto-js';
import { ResumeParseService } from 'src/app/services/resume-parse.service';
import { ToastrService } from 'ngx-toastr';
import html2pdf from 'html2pdf.js';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';
import { UserService } from 'src/app/services/user.service';
import { Location } from '@angular/common';

@Component({
  selector: 'app-ai-resume-template',
  templateUrl: './ai-resume-template.component.html',
  styleUrls: ['./ai-resume-template.component.scss']
})
export class AiResumeTemplateComponent {

  @ViewChild('previewdiv') previewdiv!: ElementRef;

  candidateId: any = '';
  encryptionKey: any = environment.encryptionKey;
  loader: boolean = false;
  resumeDetails: any;
  key_skills: any = [];
  workExperience: any = [];
  candidateImage: any = '';
  recruiterDetail: any;
  currentYear: any = new Date().getFullYear()
  recruiterImage: any = '';

  workingStyleDescription: any;
  technicalProficiencyDescription: any;
  cognitiveAbilityDescription: any;
  totalScore: any = 0;
  technicalProficiencyScore: any = [];
  scoreDescriptions: any = [];

  workingStyleMaxScore: any = 0;
  technicalProficiencyMaxScore: any = 0;
  cognitiveAbilityMaxScore: any = 0;

  brandingDetails: any;
  themeColor: any = '#6200ea';
  headerMainImage: any = '';;
  headerImage: any = '';
  headerLogo: any = '';

  is_resume_exported: boolean = false;

  geniusPairingDetail: any;

  genius_detail: any;
  assementScoreDetail: any;

  assessmentDescriptionText: any = "The above percentile scores for Cognitive and Technical assessments indicate how a candidate's performance is comparative to all candidates globally. For example, if a candidate is in the 90th percentile, it means they performed better than 90% of the candidates who took the test. This allows us to evaluate the candidate's raw abilities and their relative ranking among peers."

  scoreMapping: any = {
    'working style': 'workingStyleMaxScore',
    'technical proficiency': 'technicalProficiencyMaxScore',
    'cognitive ability': 'cognitiveAbilityMaxScore',
  };
  isHovering: boolean = false;
  isEditing: boolean = false;
  editableDescription: string = '';
  isDescriptionEdited: boolean = false; // New flag to track description changes
  wordLimit: number = 50;  // Set the word limit
  wordCount: number = 0;    // Variable to store current word count
  isSaveConfirmationVisible: boolean = false;


  scoreGrades: any = [
    { min: 0, max: 49, grade: 'D', description: 'Indicates significant gaps in qualifications or performance. This grade suggests that the candidate does not meet the minimum expectations for the role and would require significant development.' },
    { min: 50, max: 59, grade: 'C', description: 'Reflects a basic level of competency. The candidate meets some of the essential requirements but may lack proficiency or experience in key areas. Solid training and support are recommended to foster growth and development.' },
    { min: 60, max: 69, grade: 'B', description: 'Demonstrates good performance with definite potential. The candidate has a solid understanding of the role and possesses the necessary skills, though there is still room for further growth and development.' },
    { min: 70, max: 79, grade: 'A-', description: 'Represents a capable candidate with strong competence. The candidate meets most role expectations and is expected to perform consistently with minimal supervision.' },
    { min: 80, max: 89, grade: 'A', description: 'Indicates an excellent candidate with a well-rounded skill set and strong qualifications. The individual consistently demonstrates high performance and is highly capable of thriving in the role with little to no supervision.' },
    { min: 90, max: 100, grade: 'A+', description: 'Represents a top-tier candidate with exceptional skills and performance. This grade indicates a highly qualified individual who excels in all aspects of the role and is considered a strong asset to any team.' }
  ];

  showScore: boolean = true;

  constructor(private router: Router, private route: ActivatedRoute, private resumeParseService: ResumeParseService, private toastr: ToastrService,
    private userService: UserService, private location: Location) { }

  ngOnInit() {

    const encryptedIdParam = this.route.snapshot.paramMap.get('id');
    if (encryptedIdParam) {
      const decodedId = decodeURIComponent(encryptedIdParam);
      const bytes = CryptoJS.AES.decrypt(decodedId, this.encryptionKey);
      this.candidateId = bytes.toString(CryptoJS.enc.Utf8);
      this.getBrandSettingDetails();
    }
  }

  enableEditing() {
    this.isEditing = true;
    this.editableDescription = this.assementScoreDetail.description || ''; // Initialize with original description
    this.updateWordCount();  // Update the word count when editing starts
  }

  saveDescription() {
    this.assementScoreDetail.description = this.editableDescription; // Update original description
    this.isEditing = false;
  }

  checkDescriptionEdited() {
    this.isDescriptionEdited = this.editableDescription !== (this.assementScoreDetail?.description || '');
  }

  // Limit words while typing
  onInputChange(event: Event) {
    const textarea = event.target as HTMLTextAreaElement;
    let words = textarea.value.trim().split(/\s+/);

    // Prevent typing if the word limit is reached
    if (words.length > this.wordLimit) {
      words = words.slice(0, this.wordLimit);  // Limit the array of words to the word limit
      textarea.value = words.join(' ');  // Update the textarea with limited words
    }

    // Update the editable description and word count
    this.editableDescription = textarea.value;
    this.updateWordCount();
  }

  onKeyDown(event: KeyboardEvent) {
    const allowedKeys = [
      'Backspace', 'Delete', 'ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown',
      'Tab', 'Home', 'End', 'Control', 'Alt', 'Meta', 'Shift', 'Escape'
    ];

    // Check if the key is allowed regardless of word count
    if (allowedKeys.includes(event.key)) {
      return;
    }

    // Count the number of words that would result after this keypress
    const currentWords = this.editableDescription.trim().split(/\s+/).filter(Boolean);
    const selection = window.getSelection();
    const isTextSelected = selection && selection.toString().length > 0;

    if (currentWords.length >= this.wordLimit && !isTextSelected) {
      event.preventDefault(); // Prevent typing more words
    }
  }

  cancelEditing() {
    this.isEditing = false;
    this.editableDescription = this.assementScoreDetail.description || ''; // Reset to original description
    this.isDescriptionEdited = false; // Reset edited flag
  }

  confirmSaveDescription(event?: Event) {
    if (event instanceof KeyboardEvent) {
      event.preventDefault();
    }

    this.isSaveConfirmationVisible = true;
    document.body.style.overflow = 'hidden'; // Disable scroll
  }
  handleConfirmSave() {
    this.saveDescription();
    this.isSaveConfirmationVisible = false;
    document.body.style.overflow = 'auto'; // Re-enable scroll
  }

  handleCancelSave() {
    this.cancelEditing();
    this.isSaveConfirmationVisible = false;
    document.body.style.overflow = 'auto'; // Re-enable scroll
  }


  updateWordCount() {
    this.wordCount = this.editableDescription ? this.editableDescription.trim().split(/\s+/).length : 0;
  }



  getCandidateTemplateDetails() {

    this.loader = true;
    this.resumeParseService.getTemplateDetailsOfCandidate({ id: this.candidateId }).subscribe(
      async (res: any) => {
        if (res?.status === 200) {
          // console.log(res?.data, "resumeDetailss____",);
          this.resumeDetails = res?.data;
          this.recruiterDetail = res?.data?.added_by;
          this.is_resume_exported = this.resumeDetails?.candidate?.is_resume_exported;
          // this.recruiterImage = this.recruiterDetail?.image;
          if (this.recruiterDetail?.image)
            this.recruiterImage = await this.getBase64Image(this.recruiterDetail?.image)

          // this.candidateImage = this.resumeDetails?.candidate?.image;
          if (this.resumeDetails?.candidate?.image)
            this.candidateImage = await this.getBase64Image(this.resumeDetails?.candidate?.image);

          this.genius_detail = this.resumeDetails?.genius_detail[0];
          this.key_skills = this.resumeDetails?.key_skills;
          this.workExperience = this.resumeDetails?.work_experience;
          this.technicalProficiencyScore = this.resumeDetails?.candidate_technical_proficiency_score;
          this.scoreDescriptions = this.resumeDetails?.score_description_list;
          this.assessmentDescriptionText = this.resumeDetails?.assessment_description_list[0]?.description;
          this.scoreGrades = this.resumeDetails?.assessment_grade_list;

          // Understanding our Assessments Details
          this.workingStyleDescription = this.resumeDetails?.understanding_assessment['working style'];
          this.technicalProficiencyDescription = this.resumeDetails?.understanding_assessment['technical proficiency'];
          this.cognitiveAbilityDescription = this.resumeDetails?.understanding_assessment['cognitive ability'];
          this.totalScore = this.resumeDetails?.candidate?.work_style_score + this.resumeDetails?.candidate?.cognitive_capability_total_score + this.resumeDetails?.candidate?.technical_proficiency_score;

          if (this.totalScore) {
            this.assementScoreDetail = this.getGrade(this.totalScore);
          }

          if (this.resumeDetails?.genius_pairing_detail?.length > 0) {
            this.geniusPairingDetail = this.resumeDetails?.genius_pairing_detail[0];
          }

          this.scoreDescriptions.forEach((item: any) => {
            const key = this.scoreMapping[item?.talent_matrix];
            if (key) {
              (this as any)[key] = item?.max_value;
            }
          });

          if (!this.resumeDetails?.candidate?.pdf_file) {
            this.downloadResumeAsPDF();
          } else {
            this.loader = false;
          }

        } else {
          this.loader = false;
          this.toastr.error(res?.message || 'An error occurred. Please try again.', 'Error');
        }
      },
      (err) => {
        this.loader = false;
        if (err?.status !== 401) {
          let errorMessage = 'An error occurred. Please try again later.';
          if (err.error) {
            if (err.error.errors && Object.keys(err.error.errors).length > 0) {
              errorMessage = err.error.errors;
            } else if (err.error.message) {
              errorMessage = err.error.message;
            }
          }
          this.toastr.error(errorMessage, 'Error');
        }
      }
    );
  }

  getBrandSettingDetails() {
    this.loader = true;
    this.userService.getBrandingDetails({}).subscribe(
      async (res: any) => {
        if (res?.status === 200) {
          // this.loader = false;
          this.brandingDetails = res?.data;
          this.themeColor = this.brandingDetails?.theme_color;

          if (this.brandingDetails?.logo)
            this.headerLogo = await this.getBase64Image(this.brandingDetails?.logo)

          if (this.brandingDetails?.templateHeaderImgMain)
            this.headerMainImage = await this.getBase64Image(this.brandingDetails?.templateHeaderImgMain)

          if (this.brandingDetails?.templateHeaderImg)
            this.headerImage = await this.getBase64Image(this.brandingDetails?.templateHeaderImg)
          this.getCandidateTemplateDetails();

          // console.log(this.brandingDetails, "brandingDetails____");
        } else {
          this.loader = false;
          this.toastr.error(res.message || 'An error occurred. Please try again.', 'Error');
        }
      },
      (err) => {
        this.loader = false;
        if (err?.status !== 401) {
          let errorMessage = 'An error occurred. Please try again later.'
          if (err.error) {
            if (err.error.errors && Object.keys(err.error.errors).length > 0) {
              errorMessage = err.error.errors;
            } else if (err.error.message) {
              errorMessage = err.error.message;
            }
          }
          this.toastr.error(errorMessage, 'Error');
        }
      }
    );
  }

  async candidateResumeExportStatusUpdate() {
    // this.loader = true;
    this.resumeParseService.updateResumeExportStatus({ id: this.candidateId }).subscribe(
      (res: any) => {
        if (res?.status === 200) {
          // console.log(res?.data, "updateResumeExportStatus____",);
          this.loader = false;
        } else {
          this.loader = false;
          this.toastr.error(res?.message || 'An error occurred. Please try again.', 'Error');
        }
      },
      (err) => {
        this.loader = false;
        if (err?.status !== 401) {
          let errorMessage = 'An error occurred. Please try again later.';
          if (err.error) {
            if (err.error.errors && Object.keys(err.error.errors).length > 0) {
              errorMessage = err.error.errors;
            } else if (err.error.message) {
              errorMessage = err.error.message;
            }
          }
          this.toastr.error(errorMessage, 'Error');
        }
      }
    );
  }

  // Old one where logo is not coming

  // async downloadResumeAsPDF() {
  //   if (!this.previewdiv) {
  //     console.error("Error: previewdiv is not available.");
  //     return;
  //   }

  //   const content = this.previewdiv.nativeElement;
  //   let userName = this.resumeDetails?.candidate?.full_name || "resume";

  //   const options = {
  //     margin: 10,
  //     filename: `${userName}.pdf`,
  //     image: { type: "jpeg", quality: 0.98 },
  //     html2canvas: { scale: 2, useCORS: true },
  //     jsPDF: { format: "a4", orientation: "portrait" },
  //     pagebreak: { mode: "avoid-all" } // Ensures text is not cut
  //   };

  //   html2pdf().from(content).set(options).save();
  //   this.toastr.success("PDF downloaded successfully.");
  //   await this.candidateResumeExportStatusUpdate();
  // }


  // async downloadResumeAsPDF() {
  //   this.loader = true
  //   if (!this.previewdiv) {
  //     console.error("Error: previewdiv is not available.");
  //     return;
  //   }

  //   const content = this.previewdiv.nativeElement;
  //   let userName = this.resumeDetails?.candidate?.full_name || "resume";

  //   const pdf = new jsPDF("p", "mm", "a4");
  //   const pageWidth = pdf.internal.pageSize.getWidth();
  //   const pageHeight = pdf.internal.pageSize.getHeight();
  //   const margin = 10;
  //   const headerHeight = 20; // Adjust based on your header height
  //   let headerMainImgData = "";
  //   let headerImgData = "";
  //   let currentYPosition = margin + headerHeight; // Start position below the header

  //   // Capture the first page header (headerMainImage)
  //   const headerMainElement = document.querySelector(".create-resume img") as HTMLImageElement;
  //   if (headerMainElement) {
  //     const headerMainCanvas = await html2canvas(headerMainElement, { scale: 1.5, backgroundColor: "#FFFFFF" });
  //     headerMainImgData = headerMainCanvas.toDataURL("image/png"); // Use PNG for better quality
  //   }

  //   // Capture the subsequent pages' header (headerImage)
  //   const headerElement = document.querySelector(".create-resume1 img") as HTMLImageElement;
  //   if (headerElement) {
  //     const headerCanvas = await html2canvas(headerElement, { scale: 1.5, backgroundColor: "#FFFFFF" });
  //     headerImgData = headerCanvas.toDataURL("image/png"); // Use PNG for better quality
  //   }

  //   // Temporarily hide header while capturing content
  //   const headerDiv = document.querySelector(".create-resume") as HTMLElement;
  //   if (headerDiv) headerDiv.style.display = "none";

  //   // Define the block classes to target
  //   const blockClasses = [
  //     "first-block",
  //     "second-block",
  //     "third-block",
  //     "fourth-block",
  //     "fifth-block",
  //   ];

  //   // Create a selector to target all blocks
  //   const blockSelector = blockClasses.map(cls => `.${cls}`).join(", ");
  //   const blocks = content.querySelectorAll(blockSelector);
  //   let firstPage = true;

  //   // Debug: Log the number of blocks detected
  //   console.log("Detected blocks:", blocks.length);

  //   for (let i = 0; i < blocks.length; i++) {
  //     const block = blocks[i] as HTMLElement;

  //     // Skip empty blocks
  //     if (!block.innerText.trim()) continue;

  //     // Debug: Log the block being processed
  //     console.log(`Processing block ${i + 1}:`, block.className);

  //     // Capture the entire block as a single unit
  //     const canvas = await html2canvas(block, { scale: 1.5, backgroundColor: "#FFFFFF" });
  //     const imgWidth = pageWidth - 2 * margin;
  //     const imgHeight = (canvas.height * imgWidth) / canvas.width;

  //     // Debug: Log the block's height
  //     console.log(`Block ${i + 1} height:`, imgHeight);

  //     // Check if the block fits on the current page
  //     if (currentYPosition + imgHeight > pageHeight - margin) {
  //       // If it doesn't fit, add a new page and reset the Y position
  //       pdf.addPage();
  //       currentYPosition = margin + headerHeight; // Start below the header on the new page
  //       firstPage = false;
  //     }

  //     // Add the appropriate header for the page
  //     if (firstPage && headerMainImgData && currentYPosition === margin + headerHeight) {
  //       pdf.addImage(headerMainImgData, "PNG", margin, 5, pageWidth - 2 * margin, headerHeight);
  //     } else if (!firstPage && headerImgData && currentYPosition === margin + headerHeight) {

  //       // To Show New Header As Required For New Pages
  //       // pdf.addImage(headerImgData, "PNG", margin, 5, pageWidth - 2 * margin, headerHeight);

  //        // To Show Same Header For New Pages As Well
  //       pdf.addImage(headerMainImgData, "PNG", margin, 5, pageWidth - 2 * margin, headerHeight);
  //     }

  //     // Add the block to the PDF
  //     const imgData = canvas.toDataURL("image/png"); // Use PNG for better quality
  //     pdf.addImage(imgData, "PNG", margin, currentYPosition, imgWidth, imgHeight);

  //     // Update the Y position for the next block
  //     currentYPosition += imgHeight + 2; // Small gap between blocks
  //   }

  //   // Restore header visibility
  //   if (headerDiv) headerDiv.style.display = "flex";

  //   pdf.save(`${userName}.pdf`);
  //   this.toastr.success("PDF downloaded successfully.");

  //   if (this.is_resume_exported === false) {
  //     await this.candidateResumeExportStatusUpdate();
  //   }

  //   await this.uploadPDF(pdf, userName, this.candidateId);
  // }


  // New one where logo is coming


  // async downloadResumeAsPDF() {
  //   this.loader = true;
  //   if (!this.previewdiv) {
  //     console.error("Error: previewdiv is not available.");
  //     return;
  //   }

  //   const content = this.previewdiv.nativeElement;
  //   let userName = this.resumeDetails?.candidate?.full_name || "resume";

  //   const pdf = new jsPDF("p", "mm", "a4");
  //   const pageWidth = pdf.internal.pageSize.getWidth(); // 210mm for A4
  //   const pageHeight = pdf.internal.pageSize.getHeight(); // 297mm for A4
  //   const margin = 25; // 25mm margin for content
  //   const headerContentGap = 8; // 8mm gap between header and content
  //   let headerMainImgData = "";
  //   let headerImgData = "";
  //   let headerHeight = 0; // Will be calculated dynamically
  //   let currentYPosition = 0; // Will be set after calculating headerHeight

  //   // Preload images to ensure they are loaded before rendering
  //   const preloadImage = (src: string): Promise<void> => {
  //     return new Promise((resolve, reject) => {
  //       const img = new Image();
  //       // Only set crossOrigin if the image is from a different domain
  //       if (src && !src.startsWith("data:")) {
  //         img.crossOrigin = "Anonymous";
  //       }
  //       img.src = src;
  //       img.onload = () => {
  //         // console.log(`Image loaded successfully: ${src}`);
  //         resolve();
  //       };
  //       img.onerror = (err) => {
  //         console.error(`Failed to load image: ${src}`, err);
  //         reject(new Error(`Failed to load image: ${src}`));
  //       };
  //     });
  //   };

  //   // Preload header images
  //   try {
  //     if (this.headerMainImage) {
  //       // console.log("Preloading headerMainImage:", this.headerMainImage);
  //       await preloadImage(this.headerMainImage);
  //     } else {
  //       console.warn("headerMainImage is not defined.");
  //     }
  //     if (this.headerLogo) {
  //       // console.log("Preloading headerLogo:", this.headerLogo);
  //       await preloadImage(this.headerLogo);
  //     } else {
  //       console.warn("headerLogo is not defined.");
  //     }
  //   } catch (error) {
  //     console.error("Error preloading images:", error);
  //   }

  //   // Add a delay to ensure images are fully loaded
  //   await new Promise(resolve => setTimeout(resolve, 2000)); // Increased to 2 seconds

  //   // Capture the first page header (entire .create-resume div)
  //   const headerMainElement = document.querySelector(".create-resume") as HTMLElement;
  //   if (headerMainElement) {
  //     // Ensure the header is visible during capture
  //     headerMainElement.style.display = "flex";

  //     const headerMainCanvas = await html2canvas(headerMainElement, {
  //       scale: 1.5, // Match your working code
  //       backgroundColor: "#FFFFFF",
  //       useCORS: true,
  //       logging: true,
  //       // Remove windowWidth and width to match your working code
  //     });
  //     headerMainImgData = headerMainCanvas.toDataURL("image/png", 1.0);
  //     // console.log("Header canvas data URL:", headerMainImgData); // Debug: Check the captured header

  //     // Calculate headerHeight dynamically based on the canvas height
  //     const headerPixelHeight = headerMainCanvas.height; // Height in pixels
  //     const headerWidthInPixels = headerMainCanvas.width; // Width in pixels
  //     const headerWidthInMM = pageWidth; // Header width in mm (210mm for A4)
  //     const headerHeightInMM = (headerPixelHeight * headerWidthInMM) / headerWidthInPixels; // Convert to mm
  //     headerHeight = headerHeightInMM;
  //     // console.log(`Calculated header height: ${headerHeight}mm`);

  //     // Ensure headerHeight is sufficient (minimum 30mm to match your working code)
  //     headerHeight = Math.max(headerHeight, 30);
  //   } else {
  //     console.error("Header element (.create-resume) not found.");
  //     headerHeight = 30; // Fallback to 30mm if header is not found
  //   }

  //   // Set the initial Y position for content
  //   currentYPosition = headerHeight + headerContentGap;

  //   // Capture the subsequent pages' header (entire .create-resume1 div)
  //   const headerElement = document.querySelector(".create-resume1") as HTMLElement;
  //   if (headerElement) {
  //     const headerCanvas = await html2canvas(headerElement, {
  //       scale: 2,
  //       backgroundColor: "#FFFFFF",
  //       useCORS: true,
  //       logging: true,
  //       width: 794,
  //     });
  //     headerImgData = headerCanvas.toDataURL("image/png", 1.0);
  //   } else {
  //     console.error("Header element (.create-resume1) not found.");
  //   }

  //   // Temporarily hide header while capturing content
  //   const headerDiv = document.querySelector(".create-resume") as HTMLElement;
  //   if (headerDiv) headerDiv.style.display = "none";

  //   // Define the block classes to target
  //   const blockClasses = [
  //     "first-block",
  //     "second-block",
  //     "third-block",
  //     "fourth-block",
  //     "fifth-block",
  //   ];

  //   // Create a selector to target all blocks
  //   const blockSelector = blockClasses.map(cls => `.${cls}`).join(", ");
  //   const blocks = content.querySelectorAll(blockSelector);
  //   let firstPage = true;

  //   // Debug: Log the number of blocks detected
  //   // console.log("Detected blocks:", blocks.length);

  //   for (let i = 0; i < blocks.length; i++) {
  //     const block = blocks[i] as HTMLElement;

  //     // Skip empty blocks
  //     if (!block.innerText.trim()) continue;

  //     // Debug: Log the block being processed
  //     // console.log(`Processing block ${i + 1}:`, block.className);

  //     // Capture the entire block as a single unit
  //     const canvas = await html2canvas(block, {
  //       scale: 2,
  //       backgroundColor: "#FFFFFF",
  //       useCORS: true,
  //       logging: true,
  //     });
  //     const imgWidth = pageWidth - 2 * margin; // 210mm - 50mm = 160mm
  //     const imgHeight = (canvas.height * imgWidth) / canvas.width;

  //     // Debug: Log the block's height
  //     // console.log(`Block ${i + 1} height:`, imgHeight);

  //     // Check if the block fits on the current page
  //     if (currentYPosition + imgHeight > pageHeight - margin) {
  //       // If it doesn't fit, add a new page and reset the Y position
  //       pdf.addPage();
  //       currentYPosition = headerHeight + headerContentGap;
  //       firstPage = false;
  //     }

  //     // Add the appropriate header for the page
  //     if (firstPage && headerMainImgData && currentYPosition === headerHeight + headerContentGap) {
  //       pdf.addImage(headerMainImgData, "PNG", 0, 0, pageWidth, headerHeight);
  //     } else if (!firstPage && headerImgData && currentYPosition === headerHeight + headerContentGap) {
  //       // Add the same header for new pages
  //       pdf.addImage(headerMainImgData, "PNG", 0, 0, pageWidth, headerHeight);
  //     }

  //     // Add the block to the PDF
  //     const imgData = canvas.toDataURL("image/png", 1.0);
  //     pdf.addImage(imgData, "PNG", margin, currentYPosition, imgWidth, imgHeight);

  //     // Update the Y position for the next block
  //     currentYPosition += imgHeight + 2; // Small gap between blocks
  //   }

  //   // Restore header visibility
  //   if (headerDiv) headerDiv.style.display = "flex";

  //   pdf.save(`${userName}.pdf`);
  //   this.toastr.success("PDF downloaded successfully.");

  //   if (!this.is_resume_exported) {
  //     await this.candidateResumeExportStatusUpdate();
  //   }

  //   await this.uploadPDF(pdf, userName, this.candidateId);
  //   this.loader = false;
  // }

  //  HAAVING BIG FONT SIZE

  // async downloadResumeAsPDF() {
  //   this.loader = true;
  //   if (!this.previewdiv) {
  //     console.error("Error: previewdiv is not available.");
  //     return;
  //   }

  //   const content = this.previewdiv.nativeElement;
  //   content.classList.add('pdf-export');

  //   // Debug: Log component data
  //   console.log('technicalProficiencyScore:', this.technicalProficiencyScore);
  //   console.log('cognitiveAbilityDescription:', this.cognitiveAbilityDescription);
  //   console.log('technicalProficiencyDescription:', this.technicalProficiencyDescription);

  //   let userName = this.resumeDetails?.candidate?.full_name || "resume";

  //   const pdf = new jsPDF("p", "mm", "a4");
  //   const pageWidth = pdf.internal.pageSize.getWidth(); // 210mm for A4
  //   const pageHeight = pdf.internal.pageSize.getHeight(); // 297mm for A4
  //   const margin = 25; // 25mm margin for content
  //   const headerContentGap = 8; // 8mm gap between header and content
  //   let headerMainImgData = "";
  //   let headerImgData = "";
  //   let headerHeight = 0;
  //   let currentYPosition = margin; // Start at top margin
  //   let firstPage = true;

  //   const preloadImage = (src: string): Promise<void> => {
  //     return new Promise((resolve, reject) => {
  //       const img = new Image();
  //       if (src && !src.startsWith("data:")) {
  //         img.crossOrigin = "Anonymous";
  //       }
  //       img.src = src;
  //       img.onload = () => resolve();
  //       img.onerror = (err) => {
  //         console.error(`Failed to load image: ${src}`, err);
  //         reject(new Error(`Failed to load image: ${src}`));
  //       };
  //     });
  //   };

  //   try {
  //     if (this.headerMainImage) {
  //       await preloadImage(this.headerMainImage);
  //     } else {
  //       console.warn("headerMainImage is not defined.");
  //     }
  //     if (this.headerLogo) {
  //       await preloadImage(this.headerLogo);
  //     } else {
  //       console.warn("headerLogo is not defined.");
  //     }
  //   } catch (error) {
  //     console.error("Error preloading images:", error);
  //   }

  //   await new Promise(resolve => setTimeout(resolve, 2000));

  //   const headerMainElement = document.querySelector(".create-resume") as HTMLElement;
  //   if (headerMainElement) {
  //     const originalWidth = headerMainElement.style.width;
  //     headerMainElement.style.width = '794px';
  //     headerMainElement.style.display = "flex";

  //     const headerMainCanvas = await html2canvas(headerMainElement, {
  //       scale: 2.5,
  //       backgroundColor: "#FFFFFF",
  //       useCORS: true,
  //       logging: true,
  //       width: 794,
  //     });
  //     headerMainImgData = headerMainCanvas.toDataURL("image/png", 1.0);

  //     const headerPixelHeight = headerMainCanvas.height;
  //     const headerWidthInPixels = headerMainCanvas.width;
  //     const headerWidthInMM = pageWidth;
  //     const headerHeightInMM = (headerPixelHeight * headerWidthInMM) / headerWidthInPixels;
  //     headerHeight = headerHeightInMM;
  //     headerHeight = Math.max(headerHeight, 30);

  //     headerMainElement.style.width = originalWidth;
  //   } else {
  //     console.error("Header element (.create-resume) not found.");
  //     headerHeight = 30;
  //   }

  //   const headerElement = document.querySelector(".create-resume1") as HTMLElement;
  //   if (headerElement) {
  //     const originalWidth = headerElement.style.width;
  //     headerElement.style.width = '794px';

  //     const headerCanvas = await html2canvas(headerElement, {
  //       scale: 3,
  //       backgroundColor: "#FFFFFF",
  //       useCORS: true,
  //       logging: true,
  //       width: 794,
  //     });
  //     headerImgData = headerCanvas.toDataURL("image/png", 1.0);

  //     headerElement.style.width = originalWidth;
  //   } else {
  //     console.error("Header element (.create-resume1) not found.");
  //   }

  //   const headerDiv = document.querySelector(".create-resume") as HTMLElement;
  //   if (headerDiv) headerDiv.style.display = "none";

  //   const blockClasses = [
  //     "first-block",
  //     "second-block",
  //     "third-block",
  //     "fourth-block",
  //     "fifth-block",
  //   ];
  //   const blockSelector = blockClasses.map(cls => `.${cls}`).join(", ");
  //   const blocks = content.querySelectorAll(blockSelector);

  //   for (let i = 0; i < blocks.length; i++) {
  //     const block = blocks[i] as HTMLElement;

  //     if (!block.innerText.trim()) continue;

  //     const originalWidth = block.style.width;
  //     block.style.width = '794px';

  //     const recruitContentBoxes = block.querySelectorAll('.recruit-content-box');
  //     let additionalHeight = 0;

  //     // Debug: Log DOM state before capture
  //     const debugAnchors = block.querySelectorAll('a');
  //     debugAnchors.forEach(a => console.log('Anchor text before capture:', a.innerText, 'href:', a.getAttribute('href')));

  //     // Capture canvas for the block with anchors hidden
  //     const anchors = block.querySelectorAll('a');
  //     anchors.forEach(anchor => anchor.style.display = 'none'); // Hide anchors temporarily

  //     const canvas = await html2canvas(block, {
  //       scale: 3,
  //       backgroundColor: "#FFFFFF",
  //       useCORS: true,
  //       logging: true,
  //       width: 794,
  //     });

  //     anchors.forEach(anchor => anchor.style.display = ''); // Restore anchor visibility

  //     const imgWidth = pageWidth - 2 * margin;
  //     const imgHeight = (canvas.height * imgWidth) / canvas.width;

  //     // Estimate height of content before the anchor-containing box
  //     let baseHeight = 0;
  //     const skillsExp = block.querySelector('.skills-exp');
  //     if (skillsExp) baseHeight += 10; // Approximate height for 24px title
  //     const otherBoxes = block.querySelectorAll('.recruit-content-box:not(:last-child)');
  //     otherBoxes.forEach(box => {
  //       if (!box.querySelector('.learn-more a')) baseHeight += 20 + 10 + 18; // Margin + title + 1 line of text
  //     });

  //     // Calculate total height including links
  //     let totalBlockHeight = imgHeight;
  //     if (recruitContentBoxes.length > 0 && block.querySelector('a')) {
  //       additionalHeight = 5; // 5mm for each link
  //       totalBlockHeight += additionalHeight;
  //     }
  //     totalBlockHeight += 2; // Add default spacing to next block

  //     console.log(`Block ${i}: imgHeight=${imgHeight}, baseHeight=${baseHeight}, additionalHeight=${additionalHeight}, totalBlockHeight=${totalBlockHeight}, currentYPosition=${currentYPosition}`);

  //     // Check if the block fits on the current page
  //     if (currentYPosition + totalBlockHeight > pageHeight - margin) {
  //       pdf.addPage();
  //       currentYPosition = margin; // Reset to top margin
  //       firstPage = false;
  //       console.log(`New page added, resetting currentYPosition to ${currentYPosition}`);
  //     }

  //     // Add header only at the start of a new page
  //     if (currentYPosition === margin) {
  //       if (firstPage && headerMainImgData) {
  //         pdf.addImage(headerMainImgData, "PNG", 0, 0, pageWidth, headerHeight);
  //         currentYPosition = headerHeight + headerContentGap;
  //         console.log(`Added header on first page, new currentYPosition=${currentYPosition}`);
  //       } else if (!firstPage && headerImgData) {
  //         pdf.addImage(headerImgData, "PNG", 0, 0, pageWidth, headerHeight);
  //         currentYPosition = headerHeight + headerContentGap;
  //         console.log(`Added header on subsequent page, new currentYPosition=${currentYPosition}`);
  //       }
  //     }

  //     // Add the block image (without the anchor)
  //     pdf.addImage(canvas.toDataURL("image/png", 1.0), "PNG", margin, currentYPosition, imgWidth, imgHeight);
  //     console.log(`Added block ${i} image at Y=${currentYPosition}, height=${imgHeight}`);

  //     // Handle original anchor tags as clickable links with inline approximation
  //     if (recruitContentBoxes.length > 0) {
  //       let baseYPosition = currentYPosition + baseHeight;
  //       for (const box of Array.from(recruitContentBoxes)) {
  //         const learnMoreDiv = box.querySelector('.learn-more');
  //         const anchor = box.querySelector('a');
  //         if (learnMoreDiv && anchor) {
  //           const anchorRect = anchor.getBoundingClientRect();
  //           const blockRect = block.getBoundingClientRect();
  //           const scale = 794 / blockRect.width;
  //           const linkY = currentYPosition + baseHeight + ((anchorRect.top - blockRect.top) * scale * 0.264583);
  //           const linkX = margin + (anchorRect.left - blockRect.left) * scale * 0.264583;

  //           // Robust text extraction
  //           const linkText = anchor.innerText?.trim() || anchor.textContent?.trim() || 'Link'; // Fallback to 'Link' if empty
  //           const linkUrl = anchor.getAttribute('href') || '';
  //           console.log(`Processing anchor: text="${linkText}", URL="${linkUrl}", calculated Y=${linkY}, X=${linkX}`);

  //           if (linkUrl) {
  //             pdf.setFontSize(12);
  //             pdf.setTextColor(138, 36, 232); // Match themeColor (#8A24E8)
  //             pdf.textWithLink(linkText, linkX, linkY, { url: linkUrl });
  //             console.log(`Added clickable link "${linkText}" at X=${linkX}, Y=${linkY} with URL=${linkUrl}`);
  //           } else {
  //             console.warn(`No URL found for anchor text "${linkText}" in block ${i}`);
  //           }
  //         } else {
  //           baseYPosition += 20; // Approximate height for boxes without links
  //           console.warn(`No anchor found in box: ${box.className}`);
  //         }
  //       }
  //       additionalHeight = 5;
  //     }

  //     // Update Y position for the next block
  //     if (i < blocks.length - 1) {
  //       const nextBlock = blocks[i + 1] as HTMLElement;
  //       const spaceElement = block.nextSibling as HTMLElement;
  //       let spaceHeight = 0;

  //       if (spaceElement && spaceElement.tagName.toLowerCase() === 'span' && spaceElement.style.height) {
  //         spaceHeight = parseFloat(spaceElement.style.height) || 0;
  //         spaceHeight = (spaceHeight * 0.264583) || 2;
  //         console.log(`Space height between block ${i + 1} and ${i + 2}: ${spaceHeight}mm`);
  //       } else {
  //         spaceHeight = 2;
  //       }

  //       currentYPosition += imgHeight + spaceHeight + additionalHeight;
  //       console.log(`Updated currentYPosition to ${currentYPosition} after block ${i}`);
  //     } else {
  //       currentYPosition += imgHeight + 2 + additionalHeight;
  //       console.log(`Updated currentYPosition to ${currentYPosition} for last block`);
  //     }

  //     block.style.width = originalWidth;
  //   }

  //   if (headerDiv) headerDiv.style.display = "flex";

  //   content.classList.remove('pdf-export');

  //   pdf.save(`${userName}.pdf`);
  //   this.toastr.success("PDF downloaded successfully.");

  //   // if (!this.is_resume_exported) {
  //   //   await this.candidateResumeExportStatusUpdate();
  //   // }

  //   // await this.uploadPDF(pdf, userName, this.candidateId);
  //   this.loader = false;
  // }

  // Anchor Redirection 

  async downloadResumeAsPDF() {
    // Save the description if it was edited
    if (this.isDescriptionEdited && this.showScore) {
      this.assementScoreDetail.description = this.editableDescription;
      this.isEditing = false;
      this.isDescriptionEdited = false;
    }
    this.loader = true;
    if (!this.previewdiv) {
      console.error("Error: previewdiv is not available.");
      this.loader = false;
      return;
    }

    const content = this.previewdiv.nativeElement;
    content.classList.add('pdf-export');

    // Add temporary CSS to handle overflow and page breaks
    const style = document.createElement('style');
    style.innerHTML = `
      .pdf-export .third-block,
      .pdf-export .fourth-block,
      .pdf-export .fifth-block {
        overflow: visible !important;
        page-break-inside: avoid;
      }
      .pdf-export li {
        page-break-inside: avoid;
      }
      .pdf-export {
        visibility: visible !important;
      }
    `;
    document.head.appendChild(style);

    let userName = this.resumeDetails?.candidate?.full_name || "resume";
    const pdf = new jsPDF("p", "mm", "a4");
    const pageWidth = pdf.internal.pageSize.getWidth();
    const pageHeight = pdf.internal.pageSize.getHeight();
    const margin = 25;
    const bottomMargin = 10;
    const headerContentGap = 6;
    let headerMainImgData = "";
    let headerImgData = "";
    let headerHeight = 0;
    let currentYPosition = 0;

    // Helper function to preload images
    const preloadImage = (src: string): Promise<void> => {
      return new Promise((resolve, reject) => {
        if (!src) {
          resolve();
          return;
        }
        const img = new Image();
        if (src && !src.startsWith("data:")) {
          img.crossOrigin = "Anonymous";
        }
        img.src = src;
        img.onload = () => resolve();
        img.onerror = (err) => {
          console.error(`Failed to load image: ${src}`, err);
          reject(new Error(`Failed to load image: ${src}`));
        };
      });
    };

    // Preload all images
    try {
      const imageLoadPromises = [];
      if (this.headerMainImage) {
        imageLoadPromises.push(preloadImage(this.headerMainImage));
      }
      if (this.headerLogo) {
        imageLoadPromises.push(preloadImage(this.headerLogo));
      }
      if (this.recruiterImage) {
        imageLoadPromises.push(preloadImage(this.recruiterImage));
      }
      await Promise.all(imageLoadPromises);
    } catch (error) {
      console.error("Error preloading images:", error);
    }

    // Process main header
    const headerMainElement = document.querySelector(".create-resume") as HTMLElement;
    if (headerMainElement) {
      const originalDisplay = headerMainElement.style.display;
      const originalWidth = headerMainElement.style.width;
      headerMainElement.style.width = '794px';
      headerMainElement.style.display = "flex";

      const headerMainCanvas = await html2canvas(headerMainElement, {
        scale: 3, // Reduced scale for better performance
        backgroundColor: "#FFFFFF",
        useCORS: true,
        logging: true,
        width: 794,
        windowHeight: headerMainElement.scrollHeight
      });
      headerMainImgData = headerMainCanvas.toDataURL("image/jpeg", 0.8);
      headerHeight = Math.max((headerMainCanvas.height * pageWidth) / headerMainCanvas.width, 30);

      // Restore original styles
      headerMainElement.style.width = originalWidth;
      headerMainElement.style.display = originalDisplay;
    } else {
      headerHeight = 30;
    }

    if (headerMainImgData) {
      pdf.addImage(headerMainImgData, "JPEG", 0, 0, pageWidth, headerHeight);
    }
    currentYPosition = headerHeight + headerContentGap;

    // Process secondary header if needed
    const headerElement = document.querySelector(".create-resume1") as HTMLElement;
    if (headerElement) {
      const originalWidth = headerElement.style.width;
      headerElement.style.width = '794px';
      const headerCanvas = await html2canvas(headerElement, {
        scale: 2.5,
        backgroundColor: "#FFFFFF",
        useCORS: true,
        logging: true,
        width: 794
      });
      headerImgData = headerCanvas.toDataURL("image/jpeg", 0.8);
      headerElement.style.width = originalWidth;
    }

    // Hide main header during content processing
    const headerDiv = document.querySelector(".create-resume") as HTMLElement;
    if (headerDiv) headerDiv.style.display = "none";

    // Define the blocks to process in order
    const blockClasses = [
      "first-block",
      "second-block",
      "third-block",
      "fourth-block",
      "fifth-block",
      "sixth-block"
    ];

    // Process each block sequentially
    for (const blockClass of blockClasses) {
      const block = content.querySelector(`.${blockClass}`) as HTMLElement;
      if (!block || !block.textContent?.trim()) continue;

      console.log(`Processing block: ${blockClass}`);

      // Create a clone of the block for processing
      const blockClone = block.cloneNode(true) as HTMLElement;
      blockClone.style.position = 'absolute';
      blockClone.style.left = '-9999px';
      blockClone.style.width = '794px';
      blockClone.style.visibility = 'visible';
      blockClone.style.height = 'auto';
      document.body.appendChild(blockClone);

      try {
        // Measure the block's height
        const blockHeight = blockClone.offsetHeight;
        console.log(`${blockClass} height: ${blockHeight}px`);

        // Render the block to canvas
        const canvas = await html2canvas(blockClone, {
          scale: 2.5,
          backgroundColor: "#FFFFFF",
          useCORS: true,
          logging: true,
          width: 794,
          windowHeight: blockClone.scrollHeight
        });

        const imgWidth = pageWidth - 2 * margin;
        const imgHeight = (canvas.height * imgWidth) / canvas.width;

        console.log(`${blockClass} PDF dimensions: ${imgWidth}x${imgHeight}mm`);

        // Check if we need a new page
        if (currentYPosition + imgHeight > pageHeight - bottomMargin) {
          pdf.addPage();
          currentYPosition = margin;
          // Add header to new page
          if (headerMainImgData) {
            pdf.addImage(headerMainImgData, "JPEG", 0, 0, pageWidth, headerHeight);
            currentYPosition = headerHeight + headerContentGap;
          }
        }

        // Add content to PDF
        pdf.addImage(
          canvas.toDataURL("image/jpeg", 0.8),
          "JPEG",
          margin,
          currentYPosition,
          imgWidth,
          imgHeight
        );

        // Process links if any
        const links = blockClone.querySelectorAll<HTMLAnchorElement>('a[href]');
        links.forEach(link => {
          const rect = link.getBoundingClientRect();
          const blockRect = blockClone.getBoundingClientRect();
          const scaleX = imgWidth / blockClone.offsetWidth;
          const scaleY = imgHeight / blockClone.offsetHeight;
          const pdfX = margin + ((rect.left - blockRect.left) * scaleX);
          const pdfY = currentYPosition + ((rect.top - blockRect.top) * scaleY);
          const pdfWidth = rect.width * scaleX;
          const pdfHeight = rect.height * scaleY;

          pdf.link(pdfX, pdfY, pdfWidth, pdfHeight, { url: link.href });
        });

        currentYPosition += imgHeight + 2; // Add small gap between sections
        console.log(`Current Y position after ${blockClass}: ${currentYPosition}`);
      } catch (error) {
        console.error(`Error processing ${blockClass}:`, error);
      } finally {
        // Clean up the clone
        document.body.removeChild(blockClone);
      }
    }

    // Final cleanup
    if (headerDiv) headerDiv.style.display = "flex";
    content.classList.remove('pdf-export');
    document.head.removeChild(style);

    // Save the PDF
    pdf.save(`Candidate Profile_${userName}.pdf`);
    this.toastr.success("PDF downloaded successfully.");

    // Update export status if needed
    if (!this.is_resume_exported) {
      await this.candidateResumeExportStatusUpdate();
    }

    // Upload the PDF
    await this.uploadPDF(pdf, userName, this.candidateId);
    this.loader = false;
  }


  async uploadPDF(pdf: jsPDF, userName: string, candidateId: string) {
    this.loader = true
    const pdfBlob = pdf.output("blob");
    const formData = new FormData();

    formData.append("candidate_id", candidateId);
    formData.append("pdf_file", pdfBlob, `${userName}.pdf`);

    this.resumeParseService.saveCandidateResume(formData).subscribe(
      async (res: any) => {
        if (res?.status === 200) {
          this.getCandidateTemplateDetails()
        } else {
          this.loader = false;
          this.toastr.error(res.message || 'An error occurred. Please try again.', 'Error');
        }
      },
      (err) => {
        this.loader = false;
        if (err?.status !== 401) {
          let errorMessage = 'An error occurred. Please try again later.'
          if (err.error) {
            if (err.error.errors && Object.keys(err.error.errors).length > 0) {
              errorMessage = err.error.errors;
            } else if (err.error.message) {
              errorMessage = err.error.message;
            }
          }
          this.toastr.error(errorMessage, 'Error');
        }
      }
    );
  }


  cognitiveScoreKeys(): string[] {
    return this.resumeDetails?.candidate?.cognitive_capability_score
      ? Object.keys(this.resumeDetails.candidate.cognitive_capability_score)
      : [];
  }

  formatKey(key: string): string {
    return key
      .replace(/([a-z])([A-Z])/g, '$1 $2') // Add space before uppercase letters
      .replace(/Percentile$/, ' Percentile') // Ensure "Percentile" is spaced properly
      .replace(/\b\w/g, (char) => char.toUpperCase()); // Capitalize first letters
  }

  getGrade(totalScore: number): { grade: string; description: string } {
    return this.scoreGrades.find((range: { min: number; max: number; grade: string; description: string }) =>
      totalScore >= range.min && totalScore <= range.max
    ) || { grade: 'Invalid Score', description: 'Score is out of the valid range.' };
  }


  async getBase64Image(url: string): Promise<string> {
    const response = await fetch(`${environment.apiUrl}resume-parsing/proxy-image/?url=${encodeURIComponent(url)}`);
    const blob = await response.blob();

    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.onloadend = () => resolve(reader.result as string);
      reader.readAsDataURL(blob);
    });
  }

  goBack(): void {
    this.location.back();
  }

  downloadResumeFromDB() {
    const pdfFileUrl = this.resumeDetails?.candidate?.pdf_file;

    if (!pdfFileUrl) {
      console.error("PDF file URL is missing.");
      return;
    }

    const link = document.createElement("a");
    link.href = pdfFileUrl;
    link.target = "_blank"; // Open in a new tab (optional)
    link.download = pdfFileUrl.split('/').pop(); // Extract filename from URL
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }

  getOrdinalBase(value: number): number {
    return value;
  }

  getOrdinalSuffix(value: number): string {
    const j = value % 10,
      k = value % 100;

    if (j === 1 && k !== 11) {
      return 'st';
    }
    if (j === 2 && k !== 12) {
      return 'nd';
    }
    if (j === 3 && k !== 13) {
      return 'rd';
    }
    return 'th';
  }

  toggleScore() {
    if (this.showScore) {
      this.isDescriptionEdited = true
    }
    this.showScore = !this.showScore;
  }

}
