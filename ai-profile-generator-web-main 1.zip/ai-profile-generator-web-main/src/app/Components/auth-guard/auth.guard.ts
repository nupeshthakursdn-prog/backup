import { inject } from '@angular/core';
import { CanActivateFn, Router, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { UserService } from 'src/app/services/user.service';
import { Observable, of } from 'rxjs';
import { tap, catchError, switchMap } from 'rxjs/operators';

export const authGuard: CanActivateFn = (route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> => {
  const router = inject(Router);
  const userService = inject(UserService);
  const token = localStorage.getItem('token');

  const loggedInUser = localStorage.getItem('loginUser');
  const loggedInUserData = loggedInUser ? JSON.parse(loggedInUser) : null;

  if (!token || !loggedInUserData) {
    router.navigate(['login']);
    return of(false);
  }

  const requestedPath = route.routeConfig?.path;
  const cachedPermissions = userService.getCachedPermissions();

  // ✅ Step 1: If path is not protected, allow access immediately
  if (!isProtectedRoute(requestedPath)) {
    return of(true);
  }

  // ✅ Step 2: Use Cached Permissions for Instant Navigation
  if (checkPermissions(cachedPermissions, requestedPath)) {
    // Fetch fresh permissions in the background
    userService.getPermissions({ staff_id: loggedInUserData.user_id }).pipe(
      tap((res: any) => {
        if (res?.status === 200) {
          userService.updateCachedPermissions(res.data.permission);
          // If new permissions don't allow access, redirect AFTER load
          if (!checkPermissions(res.data.permission, requestedPath)) {
            router.navigate(['/no-permission']);
          }
        }
      }),
      catchError(() => of(null)) // Ignore errors silently
    ).subscribe();

    return of(true);
  }

  // ✅ Step 3: If No Cached Permissions, Fetch Fresh & Block Navigation Until Done
  return userService.getPermissions({ staff_id: loggedInUserData.user_id }).pipe(
    switchMap((res: any) => {
      if (res?.status !== 200 || !checkPermissions(res.data.permission, requestedPath)) {
        router.navigate(['/no-permission']);
        return of(false);
      }
      userService.updateCachedPermissions(res.data.permission);
      return of(true);
    }),
    catchError(() => {
      router.navigate(['/no-permission']);
      return of(false);
    })
  );
};

/**
 * ✅ Check if a user has permission for the requested path
 */
const checkPermissions = (permissions: string[], requestedPath: string | undefined): boolean => {
  const routePermissions: Record<string, string> = {
    'score-management': 'score_management',
    'technical-proficiency-management': 'technical_proficiency_management',
    'role-category': 'role_category_management',
    'work-style-management': 'work_style_management',
    'score-description': 'score_description',
    'candidate-profile-creation': 'candidate_profile_creation',
    'cognitive-capability-management': 'cognitive_capability_management',
    'role-management': 'role_management',
    'staff-management': 'staff_management',
    'permission-management': 'permission_management',
    'genius-pairings':'genius_pairings',
    'branding-setting':'branding_setting',
    'assessment-description':'assessment_description',
    'assessment-grade':'assessment_grade'
  };

  return requestedPath ? permissions.includes(routePermissions[requestedPath] || '') : true;
};

/**
 * ✅ Check if the route is protected (only some routes require authentication)
 */
const isProtectedRoute = (requestedPath: string | undefined): boolean => {
  const protectedRoutes = [
    'score-management',
    'technical-proficiency-management',
    'role-category',
    'work-style-management',
    'score-description',
    'candidate-profile-creation',
    'cognitive-capability-management',
    'role-management',
    'staff-management',
    'permission-management',
    'branding-setting',
    'genius-pairings',
    'assessment-description',
    'assessment-grade'
  ];

  return requestedPath ? protectedRoutes.includes(requestedPath) : false;
};






// OLD CODE SLOW RESPONSE




// import { inject } from '@angular/core';
// import { CanActivateFn, Router, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
// import { UserService } from 'src/app/services/user.service';
// import { Observable, of } from 'rxjs';
// import { map, catchError, switchMap } from 'rxjs/operators';

// export const authGuard: CanActivateFn = (route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> => {
//   const router = inject(Router);
//   const userService = inject(UserService);
//   const token = localStorage.getItem('token');

//   if (!token) {
//     router.navigate(['/login']);
//     return of(false);
//   }

//   const loggedInUser = localStorage.getItem('loginUser');
//   const loggedInUserData = loggedInUser ? JSON.parse(loggedInUser) : null;

//   if (!loggedInUserData?.user_id) {
//     router.navigate(['/login']);
//     return of(false);
//   }

//   const requestedPath = route.routeConfig?.path;

//   return userService.getPermissions({ staff_id: loggedInUserData.user_id }).pipe(
//     switchMap((res: any) => {
//       if (res?.status !== 200) {
//         router.navigate(['/no-permission']);
//         return of(false);
//       }

//       const permissions: string[] = res?.data?.permission || [];
//       console.log(permissions, "permissions_data_fromAUthGuard_______");

//       const routePermissions: Record<string, string> = {
//         'score-management': 'score_management',
//         'technical-proficiency-management': 'technical_proficiency_management',
//         'role-category': 'role_category_management',
//         'work-style-management': 'work_style_management',
//         'score-description': 'score_description',
//         'candidate-profile-create': 'candidate_profile_creation',
//         'cognitive-capability-management': 'cognitive_capability_management',
//         'role-management': 'role_management',
//         'staff-management': 'staff_management',
//         'permission-management': 'permission_management'
//       };

//       if (requestedPath && routePermissions[requestedPath] && !permissions.includes(routePermissions[requestedPath])) {
//         router.navigate(['/no-permission']);
//         return of(false);
//       }

//       return of(true); // ✅ Allow navigation if permissions match
//     }),
//     catchError(() => {
//       router.navigate(['/no-permission']);
//       return of(false);
//     })
//   );
// };
