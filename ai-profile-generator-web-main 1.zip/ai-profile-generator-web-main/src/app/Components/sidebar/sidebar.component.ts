import { Component } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss']
})
export class SidebarComponent {
  loggedInUser: any = ''
  loggedInUserData: any = ''
  activerole: string = ''
  activeItem: string = '/dashboard'
  permissionsData: any[] = [];
  loggedInUserPermissions: any;

  constructor(private router: Router, private userService: UserService) {
    this.loggedInUser = localStorage.getItem('loginUser');

    if (this.loggedInUser) {
      this.loggedInUserData = JSON.parse(this.loggedInUser)
    }
    this.getPermissionsdata()
  }
  loader: boolean = false;

  ngOnInit() {
    this.router?.events.subscribe(event => {
      if (event instanceof NavigationEnd) {
        this.activeItem = event?.url;
      }
    });
  }

  // getPermissionsdata(){
  //   this.userService.permissions$.subscribe((permissions) => {
  //     this.permissionsData = permissions;
  //     console.log(this.permissionsData,"permissionsData__sidebar______");
  //   });
  // }

  getPermissionsdata() {
    this.userService.permissions$.subscribe((permissions) => {
      if (permissions.length) {
        this.permissionsData = permissions;
      } else {
        const storedPermissions = localStorage.getItem("permissions");
        this.permissionsData = storedPermissions ? JSON.parse(storedPermissions) : [];
      }

      // console.log(this.permissionsData, "permissionsData__");

      const isCandidateProfilePage = this.router.url.startsWith('/candidates/profile/');
      const addCandidatePage = this.router.url.startsWith('/candidates/professional-details');
      const resumeTemplate = this.router.url.startsWith('/candidate-profile-builder');

      if (!this.permissionsData.includes('candidate_profile_creation') && (resumeTemplate || isCandidateProfilePage || addCandidatePage)) {
        this.router.navigate(['no-permission']);
      }

    });
  }

  navigateTo(route: string, queryParams: any = {}) {
    this.activeItem = route;
    this.router.navigate([route], queryParams);
}



}
