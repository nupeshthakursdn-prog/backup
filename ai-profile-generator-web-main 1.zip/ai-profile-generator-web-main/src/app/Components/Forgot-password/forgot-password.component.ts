import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from 'src/app/services/user.service';
import { ToastrService } from 'ngx-toastr';
@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.scss']
})
export class ForgotPasswordComponent {

  forgotPasswordForm!: FormGroup;
  submitted = false;
  loader: boolean = false;

  constructor(private formBuilder: FormBuilder, private userService: UserService, private router: Router,
    private toastr: ToastrService) {
    this.forgotPasswordForm = this.formBuilder.group({
      email: ['', [Validators.required, Validators.email]]  // Email field with required and email validation
    });
  }

  ngOnInit() {

  }

  onSubmit() {
    this.submitted = true;
    if (this.forgotPasswordForm.invalid) {
      this.forgotPasswordForm.markAllAsTouched();
      this.toastr.error('Please enter all required fields');
      return;
    }
    this.loader = true
    const email = this.f['email'].value;
    this.userService.forgotPassword({ email }).subscribe(
      (res: any) => {

        if (res?.status === 200) {
          this.loader = false;
          this.toastr.success(res.message, 'Success');
          this.forgotPasswordForm.reset();
        } else {
          this.loader = false;
          this.toastr.error(res.message || 'An error occurred. Please try again.', 'Error');
        }
      },
      (err) => {
        this.loader = false;
        if (err?.status !== 401) {
          let errorMessage = 'An error occurred. Please try again later.'
          if (err.error) {
            if (err.error.errors && Object.keys(err.error.errors).length > 0) {
              errorMessage = err.error.errors;
            } else if (err.error.message) {
              errorMessage = err.error.message;
            }
          }
          this.toastr.error(errorMessage, 'Error');
        }
      }
    );
  }


  get f() { return this.forgotPasswordForm.controls; }

}
