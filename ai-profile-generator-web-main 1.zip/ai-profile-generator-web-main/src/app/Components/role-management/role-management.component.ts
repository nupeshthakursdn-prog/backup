import { Component } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { MatDialog } from '@angular/material/dialog';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UserService } from 'src/app/services/user.service';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';

@Component({
  selector: 'app-role-management',
  templateUrl: './role-management.component.html',
  styleUrls: ['./role-management.component.scss']
})

export class RoleManagementComponent {
  loader: boolean = false;
  limit: any = 10
  pageNumber: any = 1
  totalLength: any = 0
  searchText: any = ''

  displayedColumns: string[] = ['name', 'actions'];
  dataSource: any = [];
  rolesList: any = [];
  roleForm: FormGroup;
  editRoleForm: FormGroup;
  selectedRoleId: any = ''

  constructor(private fb: FormBuilder, private modalService: NgbModal, public dialog: MatDialog,
    private userService: UserService, private router: Router, private toastr: ToastrService) {

    this.roleForm = this.fb.group({
      roleName: ['', [Validators.required, Validators.minLength(3)]]
    });

    this.editRoleForm = this.fb.group({
      roleName: ['', Validators.required]
    });

  }

  ngOnInit(): void {
    this.getRoles();
  }

  getRoles() {
    this.loader = true;
    let queryData = {
      limit: this.limit,
      page: this.pageNumber,
      searchText: this.searchText
    }

    this.userService.getRoles(queryData).subscribe(
      (res: any) => {
        if (res?.status === 200) {
          this.loader = false;
          this.rolesList = res?.data?.roles;
          this.totalLength = res?.data?.total;
        } else {
          this.loader = false;
          this.rolesList = []
          this.toastr.error(res.message || 'An error occurred. Please try again.', 'Error');
        }
      },
      (err) => {
        this.loader = false;
        if (err?.status !== 401) {
          let errorMessage = 'An error occurred. Please try again later.'
          if (err.error) {
            if (err.error.errors && Object.keys(err.error.errors).length > 0) {
              errorMessage = err.error.errors;
            } else if (err.error.message) {
              errorMessage = err.error.message;
            }
          }
          this.toastr.error(errorMessage, 'Error');
        }
      }
    );
  }

  getRoleById() {
    this.loader = true;
    this.userService.getRoleById({ id: this.selectedRoleId }).subscribe(
      (res: any) => {
        if (res?.status === 200) {
          this.editRoleForm.patchValue({
            roleName: this.toTitleCase(res?.data?.role_name)
          });
          this.loader = false;
        } else {
          this.loader = false;
          this.toastr.error(res.message || 'An error occurred. Please try again.', 'Error');
        }
      },
      (err) => {
        this.loader = false;
        if (err?.status !== 401) {
          let errorMessage = 'An error occurred. Please try again later.'
          if (err.error) {
            if (err.error.errors && Object.keys(err.error.errors).length > 0) {
              errorMessage = err.error.errors;
            } else if (err.error.message) {
              errorMessage = err.error.message;
            }
          }
          this.toastr.error(errorMessage, 'Error');
        }
      }
    );
  }

  deleteRole() {
    this.loader = true;
    this.userService.deleteRoleById({ id: this.selectedRoleId }).subscribe(
      (res: any) => {
        if (res?.status === 200) {
          this.loader = false;
          this.toastr.success(res.message, 'Success');
          this.modalService.dismissAll();
          this.getRoles()
        } else {
          this.loader = false;
          this.toastr.error(res.message || 'An error occurred. Please try again.', 'Error');
        }
      },
      (err) => {
        this.loader = false;
        if (err?.status !== 401) {
          let errorMessage = 'An error occurred. Please try again later.'
          if (err.error) {
            if (err.error.errors && Object.keys(err.error.errors).length > 0) {
              errorMessage = err.error.errors;
            } else if (err.error.message) {
              errorMessage = err.error.message;
            }
          }
          this.toastr.error(errorMessage, 'Error');
        }
      }
    );
  }

  onSubmitAdd() {
    if (this.roleForm.valid) {
      this.loader = true;
      // Extract form data to pass to your API
      const { roleName } = this.roleForm.value;

      // Call your API method (replace createRole with your actual method)
      this.userService.addRole({ role_name: roleName }).subscribe(
        (res: any) => {

          if (res?.status === 200) {
            this.loader = false;
            this.toastr.success(res.message, 'Success');
            this.getRoles();
            this.modalService.dismissAll();
            this.roleForm.reset()
          } else {
            this.loader = false;
            this.toastr.error(res.message || 'An error occurred. Please try again.', 'Error');
          }
        },
        (err) => {
          this.loader = false;
          if (err?.status !== 401) {
            let errorMessage = 'An error occurred. Please try again later.'
            if (err.error) {
              if (err.error.errors && Object.keys(err.error.errors).length > 0) {
                for (let field in err.error.errors) {
                  if (err.error.errors.hasOwnProperty(field)) {
                    this.toastr.error(err.error.errors[field]);
                  }
                }
                errorMessage = err.error.errors;
              } else if (err.error.message) {
                errorMessage = err.error.message;
                this.toastr.error(errorMessage);
              }
            }
          }
        }
      );
    } else {
      this.roleForm.markAllAsTouched();
      this.toastr.error('Please enter all required fields');
    }
  }

  onSubmitEdit() {
    this.loader = true;
    if (this.editRoleForm.valid) {
      const { roleName } = this.editRoleForm.value;
      let data = {
        role_name: roleName,
        role_id: this.selectedRoleId
      }
      this.userService.updateRoleById(data).subscribe(
        (res: any) => {
          if (res?.status === 200) {
            this.loader = false;
            this.toastr.success(res.message, 'Success');
            this.modalService.dismissAll();
            this.getRoles();
          } else {
            this.loader = false;
            this.toastr.error(res.message || 'An error occurred. Please try again.', 'Error');
          }
        },
        (err) => {
          this.loader = false;
          if (err?.status !== 401) {
            let errorMessage = 'An error occurred. Please try again later.'
            if (err.error) {
              if (err.error.errors && Object.keys(err.error.errors).length > 0) {
                for (let field in err.error.errors) {
                  if (err.error.errors.hasOwnProperty(field)) {
                    this.toastr.error(err.error.errors[field]);
                  }
                }
                errorMessage = err.error.errors;
              } else if (err.error.message) {
                errorMessage = err.error.message;
                this.toastr.error(errorMessage);
              }
            }
          }
        }
      );
    }
  }

  get roleName() {
    return this.roleForm.get('roleName');
  }


  onSearchChange(searchTexts: any) {
    const trimmedText = searchTexts?.trim();
    if (trimmedText) {
      this.searchText = searchTexts;
      this.getRoles();
    } else if (searchTexts === "") {
      this.getRoles();
    }
  }


  clearAll() {
    this.searchText = '';
    this.getRoles();
  }


  openModal(addcontent: any) {
    this.modalService.open(addcontent, {
      centered: true,
      size: "md",
      windowClass: "master_modal add_content",
    });
  }

  openModaledit(edit: any, roleId: any) {
    if (roleId) {
      this.selectedRoleId = roleId;
      this.getRoleById()
    }
    this.modalService.open(edit, {
      centered: true,
      size: "md",
      windowClass: "master_modal add_content",
    });
  }

  openModaldelete(deleteModal: any, roleId: any) {
    if (roleId) {
      this.selectedRoleId = roleId;
    }
    this.modalService.open(deleteModal, {
      centered: true,
      size: "md",
      windowClass: "master_modal add_content",
    });
  }

  handlePageEvent(event: any) {
    this.limit = event?.pageSize;
    this.pageNumber = event?.pageIndex + 1
    this.getRoles()
  }

  toTitleCase(str: string): string {
    return str
      ?.toLowerCase()
      ?.split(' ')
      ?.map(word => word.charAt(0).toUpperCase() + word.slice(1))
      ?.join(' ');
  }

}
