import { Component } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Route, Router } from '@angular/router';
import { UserService } from 'src/app/services/user.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-set-password',
  templateUrl: './set-password.component.html',
  styleUrls: ['./set-password.component.scss']
})
export class SetPasswordComponent {
  resetPasswordForm: FormGroup;
  uidb64!: string;
  token!: string;
  passwordVisible: boolean = false;
  loader:boolean = false;
  constructor(private route: ActivatedRoute, private fb: FormBuilder, private userService: UserService,
    private toastr: ToastrService, private router: Router) {

    this.resetPasswordForm = this.fb.group({
      password: ['', [
        Validators.required,
        Validators.minLength(8),
        Validators.pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{8,}$/) // At least one uppercase, lowercase, number, special character
      ]],
      confirmPassword: ['', Validators.required]
    }, { validator: this.passwordsMatchValidator });
  }

  ngOnInit(): void {

    let isTokenExist = localStorage.getItem('token');
    if(isTokenExist){
      this.toastr.error('You are already logged in using different account please logout from that account or set password in different browser or on private window');
    }
    // Retrieve uuid and token from the route parameters
    this.uidb64 = this.route.snapshot.paramMap.get('uuid')!;
    this.token = this.route.snapshot.paramMap.get('token')!;
  }

  passwordsMatchValidator(formGroup: AbstractControl) {
    const password = formGroup.get('password');
    const confirmPassword = formGroup.get('confirmPassword');

    if (!password || !confirmPassword) {
      return null;
    }

    if (confirmPassword.errors && !confirmPassword.errors['mismatch']) {
      return null; // Return if another validator has already found an error
    }

    if (password.value !== confirmPassword.value) {
      confirmPassword.setErrors({ mismatch: true });
    } else {
      confirmPassword.setErrors(null);
    }

    return null;
  }

  get password() {
    return this.resetPasswordForm.get('password')!;
  }

  get confirmPassword() {
    return this.resetPasswordForm.get('confirmPassword')!;
  }

  onSubmit() {
    if (this.resetPasswordForm.valid) {
      this.loader = true
      const { confirmPassword,password } = this.resetPasswordForm.value;
      let data = {
        uidb64: this.uidb64,
        token: this.token,
        new_password: password,
        confirm_new_password:confirmPassword
      }
      this.userService.resetPasswordStaff(data).subscribe(
        (res: any) => {

          if (res?.status === 200) {
            this.loader = false
            this.toastr.success(res.message, 'Success');
            this.router.navigate(['login']);
          } else {
            this.loader = false
            this.toastr.error(res.message || 'An error occurred. Please try again.', 'Error');
          }
        },
        (err) => {
          this.loader = false
          let errorMessage = 'An error occurred. Please try again later.'
          if (err.error) {
            if (err.error.errors) {
              errorMessage = err.error.errors;
            } else if (err.error.message) {
              errorMessage = err.error.message;
            }
          }
          this.toastr.error(errorMessage, 'Error');
        }
      );

    }else{
      this.resetPasswordForm.markAllAsTouched();
      this.toastr.error('Please enter all required fields');
    }
  }

  togglePasswordVisibility() {
    this.passwordVisible = !this.passwordVisible;
  }

}
