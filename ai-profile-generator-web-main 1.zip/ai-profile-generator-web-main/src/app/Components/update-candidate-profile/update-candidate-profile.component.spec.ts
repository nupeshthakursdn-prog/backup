import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateCandidateProfileComponent } from './update-candidate-profile.component';

describe('UpdateCandidateProfileComponent', () => {
  let component: UpdateCandidateProfileComponent;
  let fixture: ComponentFixture<UpdateCandidateProfileComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [UpdateCandidateProfileComponent]
    });
    fixture = TestBed.createComponent(UpdateCandidateProfileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
