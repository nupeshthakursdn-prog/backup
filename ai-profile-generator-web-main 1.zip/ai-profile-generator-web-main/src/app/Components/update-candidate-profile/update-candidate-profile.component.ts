import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { environment } from 'src/environments/environment';
import * as CryptoJS from 'crypto-js';
import { Editor } from 'ngx-editor';
import { AbstractControl, FormArray, FormBuilder, FormGroup, ValidationErrors, ValidatorFn, Validators } from '@angular/forms';
import { MasterService } from 'src/app/services/master.service';
import { ResumeParseService } from 'src/app/services/resume-parse.service';
import { ToastrService } from 'ngx-toastr';
import { Location } from '@angular/common';
import { ImageCroppedEvent } from 'ngx-image-cropper';

@Component({
  selector: 'app-update-candidate-profile',
  templateUrl: './update-candidate-profile.component.html',
  styleUrls: ['./update-candidate-profile.component.scss'],
})
export class UpdateCandidateProfileComponent {

  selectedFileName: string = 'No file chosen';
  editor: Editor = new Editor;
  html = '';
  searchText: any = '';
  formType: any = 'parsing';

  limit: any = 10
  pageNumber: any = 1
  fileError: any = '';
  userParseData: any;
  loader: boolean = false;
  roleCategoryList: any = [];
  selectedCategory: any = ''
  updateCandidateForm!: FormGroup;
  // years: number[] = Array.from({ length: new Date().getFullYear() - 1990 + 1 }, (_, i) => 1990 + i);
  currentYear: any = new Date().getFullYear();
  //Include current year as well in select
  years: number[] = Array.from({ length: this.currentYear - 1990 + 1 }, (_, i) => 1990 + i);
  candidateCategoryRecord: any;
  technicalProficiencyByRole: any = [];
  cognitiveList: any = [];
  availableAssessments: any[] = [];
  candidateImage: any = '';

  candidateId: any = '';
  encryptionKey = environment.encryptionKey;
  candidateProfileDetail: any;
  selectedCategoryId: any = '';

  pairingsFields: any = [];
  filteredPairing1: any = []
  filteredPairing2: any = []

  imageChangedEvent: any = '';
  croppedImage: any = '';

  constructor(private route: ActivatedRoute, private router: Router, private resumeParseService: ResumeParseService, private toastr: ToastrService,
    private masterService: MasterService, private fb: FormBuilder, private location: Location) {
  }

  initializeForm() {
    this.updateCandidateForm = this.fb.group({
      fullName: ['', [Validators.required, Validators.minLength(3)]],
      roleCategory: ['', [Validators.required]],
      age: ['', [Validators.required, Validators.min(12), Validators.max(100)]],
      noticePeriod: ['', [Validators.required, Validators.min(0), Validators.max(180)]],
      englishEducation: ['', [Validators.required, Validators.min(0), Validators.max(5),this.integerValidator]],
      image: [null],
      keySkills: this.fb.array([this.createKeySkill()]),
      profileSummary: ['', Validators.required],
      workExperience: this.fb.array([], [this.fromYearLessThanToYearValidator()]),
      workStyleScore: [''],
      pairing1: ['', [Validators.required]],
      pairing2: ['', [Validators.required]],
      candidate_id: ['', [Validators.required]],
      cognitiveCapability: this.fb.group(this.getCognitiveCapabilityControls()),
      technicalProficiency: this.fb.array([this.createAssessment()]),
      jobRole: ['', [Validators.required, Validators.minLength(3)]],
      proximityToOffice: ['', [Validators.required, Validators.maxLength(1000)]] // Add new field
    });
    this.addWorkExperience();
  }

  integerValidator(control: AbstractControl): ValidationErrors | null {
    const value = control.value;
    if (value !== null && value !== undefined && value !== '') {
      if (!Number.isInteger(+value)) {
        return { notInteger: true };
      }
    }
    return null;
  }

  ngOnInit() {
    const encryptedIdParam = this.route.snapshot.paramMap.get('id');
    if (encryptedIdParam) {
      const decodedId = decodeURIComponent(encryptedIdParam);
      const bytes = CryptoJS.AES.decrypt(decodedId, this.encryptionKey);
      this.candidateId = bytes.toString(CryptoJS.enc.Utf8);
    }
    this.editor = new Editor();
    this.getCognitiveCapability();
    this.getGeniusPairingFields();
  }


  updatePairings() {
    const selectedPairing1 = this.updateCandidateForm.get('pairing1')?.value;
    const selectedPairing2 = this.updateCandidateForm.get('pairing2')?.value;

    this.filteredPairing1 = this.pairingsFields.filter((field: any) => field !== selectedPairing2);
    this.filteredPairing2 = this.pairingsFields.filter((field: any) => field !== selectedPairing1);
  }

  getGeniusPairingFields() {
    this.loader = true;
    this.masterService.getGeniusPairingsField().subscribe(
      (res: any) => {
        this.pairingsFields = res?.data?.workstyle_data;
        this.filteredPairing1 = [...this.pairingsFields];
        this.filteredPairing2 = [...this.pairingsFields];
        this.loader = false;
      },
      (err) => {
        this.loader = false;
        if (err?.status !== 401) {
          let errorMessage = 'An error occurred. Please try again later.'
          if (err.error) {
            if (err.error.errors && Object.keys(err.error.errors).length > 0) {
              errorMessage = err.error.errors;
            } else if (err.error.message) {
              errorMessage = err.error.message;
            }
          }
          this.toastr.error(errorMessage, 'Error');
        }
      }
    );
  }


  getCandidateProfileDetailsById() {
    this.loader = true;
    this.resumeParseService.getCandidateProfileById({ id: this.candidateId }).subscribe(
      (res: any) => {
        if (res?.status === 200) {
          this.candidateProfileDetail = res?.data;

          this.candidateCategoryRecord = this.roleCategoryList?.find(
            (item: any) => item?.name?.trim()?.toLowerCase() === this.candidateProfileDetail?.role_category?.name?.trim()?.toLowerCase()
          );

          if (this.candidateCategoryRecord?.id) {
            this.getTechnicalProficiencyByRole();
          }
          if (this.candidateProfileDetail?.image) {
            this.candidateImage = this.candidateProfileDetail?.image
          }

          this.updateCandidateForm.patchValue({
            image: this.candidateProfileDetail?.image,
            candidate_id: this.candidateId,
            fullName: this.candidateProfileDetail?.full_name,
            roleCategory: this.candidateProfileDetail?.role_category?.id,
            proximityToOffice: this.candidateProfileDetail?.proximity_to_office || '', // Add new field
            jobRole: this.toTitleCase(this.candidateProfileDetail?.job_role),
            pairing1: this.candidateProfileDetail?.pairing1 ? this.candidateProfileDetail?.pairing1 : '',
            pairing2: this.candidateProfileDetail?.pairing2 ? this.candidateProfileDetail?.pairing2 : '',
            age: this.candidateProfileDetail?.age ? this.candidateProfileDetail?.age : '',
            noticePeriod: this.candidateProfileDetail?.notice_period ? this.candidateProfileDetail?.notice_period : '',
            englishEducation: this.candidateProfileDetail?.rating ? this.candidateProfileDetail?.rating : '',
            profileSummary: this.candidateProfileDetail?.profile_summary ? this.candidateProfileDetail?.profile_summary : '',
          });

          // keySkills Patch
          if (this.candidateProfileDetail?.key_skills?.length > 0) {
            this.keySkills.clear();
            this.candidateProfileDetail.key_skills.forEach((skill: any, index: any) => {
              if (index <= 7) {
                this.keySkills.push(
                  this.fb.group({
                    key_skill: [skill.key_skill || '', Validators.required],
                  })
                );
              }
            });
          }

          // Work_Experience Patch
          if (this.candidateProfileDetail?.work_experiences?.length > 0) {
            // Clear the default empty field before adding new data
            this.workExperience.clear();
            this.candidateProfileDetail.work_experiences.forEach((experience: any) => {
              this.workExperience.push(
                this.fb.group({
                  designation: [experience.designation || '', Validators.required],
                  company_name: [experience.company_name || '', Validators.required],
                  from_year: [experience.from_year || '', Validators.required],
                  to_year: [experience.to_year === 'Present' ? this.currentYear : experience.to_year || '', Validators.required]
                },
                  { validators: this.fromYearLessThanToYearValidator() })
              );
            });
          }

          // Technical Proficiency Score Patch
          // if (this.candidateProfileDetail?.technical_proficiency_score?.length > 0) {
          //   this.availableAssessments = this.candidateProfileDetail?.technical_proficiency_score || [];

          //   this.technicalProficiency.clear();
          //   this.candidateProfileDetail?.technical_proficiency_score.forEach((item: any) => {
          //     this.technicalProficiency.push(
          //       this.fb.group({
          //         selectAssessment: [item?.name_of_proficiency || '', Validators.required],
          //         assessmentUrl: [item?.assessmentURL || '', [Validators.required, Validators.pattern('https?://.+')]],
          //         score: [item?.score || '', [Validators.required, Validators.min(0), Validators.max(100)]]
          //       })
          //     );
          //   });
          // }

          // Cognitive Capability Score Patch
          if (this.candidateProfileDetail?.cognitive_capability_score && Object.keys(this.candidateProfileDetail.cognitive_capability_score).length > 0) {
            const cognitiveCapabilityGroup = this.updateCandidateForm.get('cognitiveCapability') as FormGroup;
            this.cognitiveList.forEach((item: any) => {
              const fieldKey = this.convertLabelToKey(item.name); // Convert label to DB key
              if (this.candidateProfileDetail?.cognitive_capability_score.hasOwnProperty(fieldKey)) {
                const controlName = this.getFieldName(item.name); // Form control name
                if (cognitiveCapabilityGroup.controls[controlName]) {
                  cognitiveCapabilityGroup.controls[controlName].patchValue(this.candidateProfileDetail?.cognitive_capability_score[fieldKey]);
                }
              }
            })
          }
          this.updatePairings();
          this.loader = false;
        } else {
          this.loader = false;
          this.toastr.error(res?.message || 'An error occurred. Please try again.', 'Error');
        }
      },
      (err) => {
        this.loader = false;
        if (err.status !== 401) {
          let errorMessage = 'An error occurred. Please try again later.';
          if (err.error) {
            if (err.error.errors && Object.keys(err.error.errors).length > 0) {
              errorMessage = err.error.errors;
            } else if (err.error.message) {
              errorMessage = err.error.message;
            }
          }
          this.toastr.error(errorMessage, 'Error');
        }
      }
    );
  }


  getTechnicalProficiencyByRole() {
    this.loader = true
    let queryData = {
      role_category_id: this.candidateCategoryRecord?.id,
    }
    this.resumeParseService.getTechnicalProficiencyByRoleCategory(queryData).subscribe(
      (res: any) => {
        if (res?.status === 200) {
          this.loader = false
          this.technicalProficiencyByRole = res?.data?.technical_proficiencies;

          this.availableAssessments = this.technicalProficiencyByRole || [];

          if (this.candidateProfileDetail?.technical_proficiency_score?.length > 0) {
            // this.availableAssessments = this.candidateProfileDetail?.technical_proficiency_score || [];

            this.technicalProficiency.clear();
            this.candidateProfileDetail?.technical_proficiency_score.forEach((item: any) => {
              this.technicalProficiency.push(
                this.fb.group({
                  selectAssessment: [item?.name_of_proficiency || '', Validators.required],
                  assessmentUrl: [item?.assessmentURL || '', [Validators.required, Validators.pattern('https?://.+')]],
                  score: [item?.actual_score || '', [Validators.required, Validators.min(0), Validators.max(100)]]
                })
              );
            });
          }
        } else {
          this.loader = false
          this.technicalProficiencyByRole = []
        }
      },
      (err) => {
        if (err?.status == 404 && this.candidateProfileDetail?.technical_proficiency_score?.length > 0) {
          this.availableAssessments = this.candidateProfileDetail?.technical_proficiency_score || [];

          this.technicalProficiency.clear();
          this.candidateProfileDetail?.technical_proficiency_score.forEach((item: any) => {
            this.technicalProficiency.push(
              this.fb.group({
                selectAssessment: [item?.name_of_proficiency || '', Validators.required],
                assessmentUrl: [item?.assessmentURL || '', [Validators.required, Validators.pattern('https?://.+')]],
                score: [item?.score || '', [Validators.required, Validators.min(0), Validators.max(100)]]
              })
            );
          });
        } else {
          this.loader = false
          if (err?.status !== 401) {
            let errorMessage = 'An error occurred. Please try again later.'
            if (err.error) {
              if (err.error.errors && Object.keys(err.error.errors).length > 0) {
                errorMessage = err.error.errors;
              } else if (err.error.message) {
                errorMessage = err.error.message;
              }
            }
            this.toastr.error(errorMessage);
          }
        }
      }
    );
  }

  convertLabelToKey(label: string): string {
    return label
      .toLowerCase()
      .replace(/\s+/g, ' ')   // Ensure single spaces
      .trim()
      .split(' ')             // Split into words
      .map((word, index) => index === 0
        ? word.toLowerCase()
        : word.charAt(0).toUpperCase() + word.slice(1).toLowerCase()
      )                        // Convert to camelCase
      .join('');
  }


  getRolecategoryList() {
    this.loader = true;
    let queryData = {
      limit: '',
      page: this.pageNumber,
      searchText: ''
    }

    this.masterService.getRoleCategory(queryData).subscribe(
      (res: any) => {
        if (res?.status === 200) {
          this.loader = false;
          this.roleCategoryList = res?.data?.role_categories;
        } else {
          this.loader = false;
          this.roleCategoryList = []
          this.toastr.error(res.message || 'An error occurred. Please try again.', 'Error');
        }
      },
      (err) => {
        this.loader = false;
        if (err?.status !== 401) {
          let errorMessage = 'An error occurred. Please try again later.'
          if (err.error) {
            if (err.error.errors && Object.keys(err.error.errors).length > 0) {
              errorMessage = err.error.errors;
            } else if (err.error.message) {
              errorMessage = err.error.message;
            }
          }
          this.toastr.error(errorMessage, 'Error');
        }
      }
    );
  }

  getCognitiveCapability() {
    this.loader = true
    let queryData = {
      limit: this.limit,
      page: this.pageNumber,
      searchText: this.searchText
    }
    this.masterService.getcognitiveCapability(queryData).subscribe(
      (res: any) => {
        if (res?.status === 200) {
          this.cognitiveList = res?.data?.cognitive_capabilities;
          if (this.cognitiveList.length > 0) {
            this.initializeForm();
            this.getRolecategoryList();
            this.getCandidateProfileDetailsById();
          } else {
            this.toastr.error('No cognitive capability score record exist please add them first.');
          }
        } else {
          this.loader = false;
          this.cognitiveList = [];
        }
      },
      (err) => {
        this.loader = false;
        if (err?.status !== 401) {
          let errorMessage = 'An error occurred. Please try again later.';
          if (err?.error) {
            if (err?.error?.errors && Object.keys(err?.error?.errors).length > 0) {
              errorMessage = err?.error?.errors;
              this.toastr.error(errorMessage, 'Error');
            } else if (err?.error?.message) {
              errorMessage = err?.error?.message;
              this.toastr.error(errorMessage, 'Error');
            }
          }
          this.toastr.error(errorMessage, 'Error');
        }
      }
    );
  }

  getCognitiveCapabilityControls() {
    let controls: any = {};

    this.cognitiveList.forEach((item: any) => {
      const fieldName = this.getFieldName(item.name);
      controls[fieldName] = ['', [Validators.required, Validators.min(0), Validators.max(100)]];
    })

    return controls;
  }

  // Helper function to generate valid form control names
  getFieldName(name: string): string {
    return name
      .toLowerCase() // Convert to lowercase
      .replace(/[^a-z\s]/g, '') // Remove non-alphabetic characters
      .split(' ') // Split words
      .map((word, index) => index === 0 ? word : word.charAt(0).toUpperCase() + word.slice(1)) // Convert to camelCase
      .join('');
  }

  createKeySkill(): FormGroup {
    return this.fb.group({
      key_skill: ['', Validators.required]
    });
  }

  // Getter to easily access the keySkills FormArray from the updateCandidateForm
  get keySkills(): FormArray {
    return this.updateCandidateForm.get('keySkills') as FormArray;
  }

  // Method to add a new key skill entry
  addKeySkill() {
    if (this.keySkills.length < 8) {
      this.keySkills.push(this.createKeySkill());
    }
  }

  // Method to remove a key skill entry; keeping at least one entry in the array
  removeKeySkill(index: number) {
    if (this.keySkills.length > 1) {
      this.keySkills.removeAt(index);
    }
  }


  // workExperience form array functionality

  get workExperience(): FormArray {
    return this.updateCandidateForm.get('workExperience') as FormArray;
  }

  // Add New Work Experience Row
  addWorkExperience() {
    this.workExperience.push(
      this.fb.group({
        designation: ['', Validators.required],
        company_name: ['', Validators.required],
        from_year: ['', Validators.required],
        to_year: ['', Validators.required]
      },
        { validators: this.fromYearLessThanToYearValidator() })
    );
  }

  // Remove Work Experience Row
  removeWorkExperience(index: number) {
    this.workExperience.removeAt(index);
  }

  // Technical Proficiency Score form array functionality

  get technicalProficiency(): FormArray {
    return this.updateCandidateForm.get('technicalProficiency') as FormArray;
  }

  createAssessment(): FormGroup {
    const group = this.fb.group({
      selectAssessment: ['', Validators.required],
      assessmentUrl: ['', [Validators.required, Validators.pattern('https?://.+')]],
      score: ['', [Validators.required, Validators.min(0), Validators.max(100)]]
    });

    // Subscribe to changes in selectAssessment control
    group.get('selectAssessment')?.valueChanges.subscribe(selectedName => {
      const selectedAssessment = this.availableAssessments.find(
        (item: any) => item.name_of_proficiency === selectedName
      );

      if (selectedAssessment) {
        // Reset assessmentUrl before setting a new value
        group.get('assessmentUrl')?.reset();

        // Set the new assessment URL
        group.get('assessmentUrl')?.setValue(selectedAssessment.assessment_url, { emitEvent: true });
      } else {
        // Clear the assessmentUrl if no matching assessment is found
        group.get('assessmentUrl')?.reset();
      }

      // Force Angular to detect changes
      group.get('assessmentUrl')?.updateValueAndValidity();
    });

    return group;
  }


  addAssessment(): void {
    this.technicalProficiency.push(this.createAssessment());
  }

  removeAssessment(index: number): void {
    this.technicalProficiency.removeAt(index);
  }

  redirectToResumeTemplate(candidateId: any) {
    const encryptedId = CryptoJS.AES.encrypt(candidateId.toString(), this.encryptionKey).toString();
    const safeEncryptedId = encodeURIComponent(encryptedId);
    if (safeEncryptedId) {
      this.router.navigate([`candidate-profile-builder/${safeEncryptedId}`])
    }
  }


  // Form Submission

  onSubmit() {
    // this.router.navigate(['resume-template'])

    if (this.updateCandidateForm.valid) {
      this.loader = true
      const formData = new FormData();
      formData.append('full_name', this.updateCandidateForm.value.fullName);
      formData.append('candidate_id', this.updateCandidateForm.value.candidate_id);
      formData.append('role_category_id', this.updateCandidateForm.value.roleCategory);
      formData.append('phone_number', this.updateCandidateForm.value.phone_number);
      formData.append('role', "");
      formData.append('pairing1', this.updateCandidateForm.value.pairing1);
      formData.append('pairing2', this.updateCandidateForm.value.pairing2);
      formData.append('profile_summary', this.updateCandidateForm.value.profileSummary);
      formData.append('age', this.updateCandidateForm.value.age);
      formData.append('rating', this.updateCandidateForm.value.englishEducation);
      formData.append('notice_period', this.updateCandidateForm.value.noticePeriod);
      formData.append('work_experience', JSON.stringify(this.updateCandidateForm.value.workExperience));
      formData.append('job_role', this.updateCandidateForm.value.jobRole);
      formData.append('key_skills', JSON.stringify(this.updateCandidateForm.value.keySkills));
      formData.append('cognitive_capability_score', JSON.stringify(this.updateCandidateForm.value.cognitiveCapability));
      formData.append('technical_proficiency_scores', JSON.stringify(this.updateCandidateForm.value.technicalProficiency));
      formData.append('proximity_to_office', this.updateCandidateForm.value.proximityToOffice); // Add new field

      if (this.updateCandidateForm.value.image instanceof File) {
        formData.append('image', this.updateCandidateForm.value.image);
      } else if (this.updateCandidateForm.value.image === null) {
        formData.append('image', '');
      }

      this.resumeParseService.updateCandidateProfile(formData).subscribe(
        (res: any) => {

          if (res?.status === 200) {
            this.loader = false
            this.toastr.success(res.message, 'Success');
            this.getCandidateProfileDetailsById();
            this.imageChangedEvent = ''
            this.redirectToResumeTemplate(res?.data?.id)
          } else {
            this.loader = false;
            this.toastr.error(res.message || 'An error occurred. Please try again.', 'Error');
          }
        },
        (err) => {
          this.loader = false;
          if (err?.status !== 401) {
            let errorMessage = 'An error occurred. Please try again later.'
            if (err.error) {
              if (err.error.errors && Object.keys(err.error.errors).length > 0) {
                // for (let field in err.error.errors) {
                //   if (err.error.errors.hasOwnProperty(field)) {
                //     this.toastr.error(err.error.errors[field]);
                //   }
                // }
                errorMessage = err.error.errors;
                this.toastr.error(errorMessage);
              } else if (err.error.message) {
                errorMessage = err.error.message;
                this.toastr.error(errorMessage);
              }
            }
          }
        }
      );

    } else {
      this.updateCandidateForm.markAllAsTouched(); // Force validation messages to appear
      this.toastr.error("Please fill all the required fields.");
      return;
    }
  }

  onFileChange(event: Event): void {
    this.imageChangedEvent = event; // Pass the event to the cropper
  }

  imageCropped(event: ImageCroppedEvent): void {
    this.candidateImage = event.base64; // Store the base64 image for preview
  
    // Convert Base64 to File and update the form directly
    const timestamp = new Date().getTime(); // Get current timestamp
    this.convertBase64ToFile(event.base64, `${this.candidateId}-${timestamp}.png`);
  }


  imageLoaded() {
    console.log("Image loaded successfully!");
  }

  loadImageFailed() {
    console.error("Image loading failed!");
  }

  onImageUpload(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length) {
      const file = input.files[0];

      // Patch the file into the form control
      this.updateCandidateForm.patchValue({
        image: file
      });
      // this.updateCandidateForm.get('image')?.updateValueAndValidity();

      // Create a FileReader to generate a preview URL
      const reader = new FileReader();
      reader.onload = () => {
        const base64String = reader.result as string;
        this.candidateImage = base64String;
      };
      reader.readAsDataURL(file);
    }
  }



  triggerFileInput(): void {
    const fileInput = document.getElementById('fileInput') as HTMLInputElement;
    fileInput.click();
  }

  // make sure to destory the editor
  ngOnDestroy(): void {
    this.editor.destroy();
  }
  navigateTo(routePath: any) {
    this.router.navigate([routePath])
  }

  onCategoryChange(event: any): void {
    this.selectedCategoryId = event?.value;
    if (!this.selectedCategoryId) return;
    this.candidateCategoryRecord = this.roleCategoryList.find(
      (category: any) => category?.id === this.selectedCategoryId
    ) || null;

    if (this.candidateCategoryRecord?.id) {
      this.getTechnicalProficiencyByRole1()
    }
  }


  fromYearLessThanToYearValidator(): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      const fromYear = control.get('from_year')?.value;
      const toYear = control.get('to_year')?.value;

      // If both values are present and from_year is greater than to_year, return an error.
      if (fromYear && toYear && fromYear > toYear) {
        return { fromYearGreaterThanToYear: true };
      }
      return null;
    };
  }

  removeImage(fileInput: any) {
    // Properly update the form control
    this.updateCandidateForm.patchValue({ image: null });
    // Remove the image preview
    this.candidateImage = null;
    this.imageChangedEvent = ''
    fileInput.value = "";
  }



  getTechnicalProficiencyByRole1() {
    this.loader = true
    let queryData = {
      role_category_id: this.selectedCategoryId,
    }
    this.resumeParseService.getTechnicalProficiencyByRoleCategory(queryData).subscribe(
      (res: any) => {
        if (res?.status === 200) {
          this.technicalProficiency.clear();
          this.technicalProficiency.push(this.createAssessment());
          this.loader = false
          this.candidateCategoryRecord = this.roleCategoryList?.find(
            (item: any) => item?.name?.trim()?.toLowerCase() === this.candidateProfileDetail?.role_category?.name?.trim()?.toLowerCase()
          );
          this.technicalProficiencyByRole = res?.data?.technical_proficiencies;
          this.availableAssessments = this.technicalProficiencyByRole || [];
        } else {
          this.loader = false
          this.technicalProficiencyByRole = []
        }
      },
      (err) => {
        this.loader = false
        if (err?.status !== 401) {
          let errorMessage = 'An error occurred. Please try again later.'
          if (err.error) {
            if (err.error.errors && Object.keys(err.error.errors).length > 0) {
              errorMessage = err.error.errors;
            } else if (err.error.message) {
              errorMessage = err.error.message;
            }
          }
          this.toastr.error(errorMessage);
        }
      }
    );
  }

  goBack(): void {
    this.location.back();
  }

  toTitleCase(str: string): string {
    return str
      ?.toLowerCase()
      ?.split(' ')
      ?.map(word => word.charAt(0).toUpperCase() + word.slice(1))
      ?.join(' ');
  }


  convertBase64ToFile(base64: any, filename: string): void {
    const arr = base64.split(',');
    const mime = arr[0].match(/:(.*?);/)?.[1];
    const bstr = atob(arr[1]);
    let n = bstr.length;
    const u8arr = new Uint8Array(n);
  
    while (n--) {
      u8arr[n] = bstr.charCodeAt(n);
    }
  
    const file = new File([u8arr], filename, { type: mime });
  
    // Immediately update the form with the cropped image file
    this.updateCandidateForm.patchValue({
      image: file
    });
    this.updateCandidateForm.get('image')?.updateValueAndValidity();
  }
  

}
