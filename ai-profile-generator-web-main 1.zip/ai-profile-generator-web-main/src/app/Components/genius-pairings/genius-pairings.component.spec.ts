import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GeniusPairingsComponent } from './genius-pairings.component';

describe('GeniusPairingsComponent', () => {
  let component: GeniusPairingsComponent;
  let fixture: ComponentFixture<GeniusPairingsComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [GeniusPairingsComponent]
    });
    fixture = TestBed.createComponent(GeniusPairingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
