import { Component } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { MatDialog } from '@angular/material/dialog';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { MasterService } from 'src/app/services/master.service';

export interface PeriodicElement {
  typeOfScore: string;
  value: string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  {
    typeOfScore: 'Work Style',
    value: '0-5'
  },
  {
    typeOfScore: 'Cognitive Ability',
    value: '5-10'
  },
  {
    typeOfScore: 'Technical Proficiency',
    value: '10-15'
  },
];

@Component({
  selector: 'app-genius-pairings',
  templateUrl: './genius-pairings.component.html',
  styleUrls: ['./genius-pairings.component.scss']
})
export class GeniusPairingsComponent {
  loader: boolean = false
  limit: any = 10
  pageNumber: any = 1
  totalLength: any = 0
  searchText: any = ''

  displayedColumns: string[] = ['pairing', 'title', 'description', 'actions'];
  dataSource = ELEMENT_DATA;
  ELEMENT_DATA: PeriodicElement[] = [];

  geniusPairingForm: FormGroup;
  geniusPairingFormUpdate: FormGroup;
  selectedGeniusPairing: any = ''

  geniusPairingList: any = []
  pairingsFields: any = [];
  availablePairing1: string[] = [];
  availablePairing2: string[] = [];

  constructor(private fb: FormBuilder, private modalService: NgbModal, public dialog: MatDialog,
    private masterService: MasterService, private toastr: ToastrService) {

    this.geniusPairingForm = this.fb.group({
      pairing1: ['', Validators.required],
      pairing2: ['', [Validators.required]],
      title: ['', Validators.required],
      description: ['', Validators.required],
    });

    this.geniusPairingFormUpdate = this.fb.group({
      pairing1: ['', Validators.required],
      pairing2: ['', [Validators.required]],
      title: ['', Validators.required],
      description: ['', Validators.required],
    });

  }

  ngOnInit(): void {
    this.getGeniusPairingList();
    this.getGeniusPairingFields();
  }

  updateAvailableOptions(selectedValue: string, changedField: 'pairing1' | 'pairing2', isUpdateForm: boolean = false) {
    const form = isUpdateForm ? this.geniusPairingFormUpdate : this.geniusPairingForm; // Use correct form

    const pairing1Value = form.get('pairing1')?.value;
    const pairing2Value = form.get('pairing2')?.value;

    if (isUpdateForm) {
      // Handle update form
      this.availablePairing1 = this.pairingsFields.filter((field: any) => field !== pairing2Value);
      this.availablePairing2 = this.pairingsFields.filter((field: any) => field !== pairing1Value);
    } else {
      // Handle add form
      this.availablePairing1 = this.pairingsFields.filter((field: any) => field !== pairing2Value);
      this.availablePairing2 = this.pairingsFields.filter((field: any) => field !== pairing1Value);
    }
  }

  // Pairing Fields

  getGeniusPairingFields() {
    this.loader = true;
    this.masterService.getGeniusPairingsField().subscribe(
      (res: any) => {
        this.pairingsFields = res?.data?.workstyle_data;

        this.availablePairing1 = [...this.pairingsFields];
        this.availablePairing2 = [...this.pairingsFields];

        this.geniusPairingForm.get('pairing1')?.valueChanges.subscribe(selectedValue => {
          this.updateAvailableOptions(selectedValue, 'pairing1', false); // false for add form
        });

        this.geniusPairingForm.get('pairing2')?.valueChanges.subscribe(selectedValue => {
          this.updateAvailableOptions(selectedValue, 'pairing2', false); // false for add form
        });
        this.loader = false;
      },
      (err) => {
        this.loader = false;
        if (err?.status !== 401) {
          let errorMessage = 'An error occurred. Please try again later.'
          if (err.error) {
            if (err.error.errors && Object.keys(err.error.errors).length > 0) {
              errorMessage = err.error.errors;
            } else if (err.error.message) {
              errorMessage = err.error.message;
            }
          }
          this.toastr.error(errorMessage, 'Error');
        }
      }
    );
  }

  // GET PAIRING LIST

  getGeniusPairingList() {
    this.loader = true
    let queryData = {
      limit: this.limit,
      page: this.pageNumber,
      searchText: this.searchText
    }
    this.masterService.getGeniusPairings(queryData).subscribe(
      (res: any) => {
        this.loader = false;
        if (res?.status === 200 && res?.data?.results?.length > 0) {
          this.geniusPairingList = res?.data?.results;
          this.totalLength = res?.data?.total;
        }
      },
      (err) => {
        this.loader = false;
        if (err?.status !== 401) {
          let errorMessage = 'An error occurred. Please try again later.'
          if (err.error) {
            if (err.error.errors && Object.keys(err.error.errors).length > 0) {
              errorMessage = err.error.errors;
            } else if (err.error.message) {
              errorMessage = err.error.message;
            }
          }
        }
      }
    );
  }

  // GET PAIRING BY ID

  getGeniusPairingsByIdById() {
    this.loader = true;

    this.masterService.getGeniusPairingById(this.selectedGeniusPairing).subscribe(
      (res: any) => {
        this.loader = false;

        if (res?.status === 200 && res?.data) {

          const { pairing1, pairing2, title, description } = res.data;

          this.geniusPairingFormUpdate.patchValue({
            pairing1: this.toTitleCase(pairing1),
            pairing2: this.toTitleCase(pairing2),
            title: title,
            description: description
          });
          this.updateAvailableOptions('', 'pairing1', true);
          this.updateAvailableOptions('', 'pairing2', true);
        } else {
          this.toastr.error(res?.message || "An error occurred. Please try again.", "Error");
        }
      },
      (err) => {
        this.loader = false;
        if (err?.status !== 401) {
          let errorMessage = 'An error occurred. Please try again later.'
          if (err.error) {
            if (err.error.errors && Object.keys(err.error.errors).length > 0) {
              errorMessage = err.error.errors;
            } else if (err.error.message) {
              errorMessage = err.error.message;
            }
          }
          this.toastr.error(errorMessage, 'Error');
        }
      }
    );
  }

  // ADD PAIRING

  onSubmit(): void {
    if (this.geniusPairingForm.valid) {
      this.loader = true;
      const { pairing1, pairing2, title, description } = this.geniusPairingForm.value;
      const data = {
        pairing1: pairing1.toLowerCase(),
        pairing2: pairing2.toLowerCase(),
        title: title.toLowerCase(),
        description: description
      };

      this.masterService.addGeniusPairing(data).subscribe(
        (res: any) => {
          this.loader = false;
          if (res?.status === 200) {
            this.toastr.success(res.message, "Success");
            this.modalService.dismissAll();
            this.geniusPairingForm.reset();
            this.getGeniusPairingList();
          } else {
            this.toastr.error(res.message || "An error occurred. Please try again.", "Error");
          }
        },
        (err) => {
          this.loader = false;
          if (err?.status !== 401) {
            let errorMessage = 'An error occurred. Please try again later.';
            if (err?.error) {
              if (err?.error?.errors && Object.keys(err?.error?.errors).length > 0) {
                for (let field in err.error.errors) {
                  if (err.error.errors.hasOwnProperty(field)) {
                    this.toastr.error(err.error.errors[field]);
                  }
                }
              } else if (err?.error?.message) {
                errorMessage = err?.error?.message;
                this.toastr.error(errorMessage, 'Error');
              }
            }
          }
        }
      );
    } else {
      this.toastr.error("Please select all required fields");
      this.geniusPairingForm.markAllAsTouched();
    }
  }

  // UPDATE PAIRING

  onSubmitUpdate(): void {

    if (this.geniusPairingFormUpdate.valid) {
      this.loader = true;
      const { pairing1, pairing2, title, description } = this.geniusPairingFormUpdate.value;
      const data = {
        pairing1: pairing1.toLowerCase(),
        pairing2: pairing2.toLowerCase(),
        title: title.toLowerCase(),
        description: description,
        genius_pairing_id: this.selectedGeniusPairing
      };
      this.masterService.updateGeniusPairinById(data).subscribe(
        (res: any) => {
          this.loader = false;
          if (res?.status === 200) {
            this.toastr.success(res.message, "Success");
            this.modalService.dismissAll();
            this.getGeniusPairingList();
          } else {
            this.toastr.error(res.message || "An error occurred. Please try again.", "Error");
          }
        },
        (err) => {
          this.loader = false;
          if (err?.status !== 401) {
            let errorMessage = 'An error occurred. Please try again later.';
            if (err?.error) {
              if (err?.error?.errors && typeof err.error.errors === 'object' && Object.keys(err.error.errors).length > 0) {
                for (let field in err.error.errors) {
                  if (err.error.errors.hasOwnProperty(field)) {
                    this.toastr.error(err.error.errors[field], 'Error');
                  }
                }
              } else if (err?.error?.message) {
                errorMessage = err.error.message; // Now it correctly captures "Score description already exist."
                this.toastr.error(errorMessage);
              }
            }
          }
        }
      );
    } else {
      this.toastr.error("Please select all required fields");
      this.geniusPairingFormUpdate.markAllAsTouched();
    }
  }

  // DELETE PAIRING

  deletePairingRecord() {
    this.loader = true
    this.masterService.deleteGeniusPairinById(this.selectedGeniusPairing).subscribe(
      (res: any) => {
        if (res?.status === 200) {
          this.loader = false
          this.toastr.success(res.message, 'Success');
          this.modalService.dismissAll();
          this.getGeniusPairingList()
        } else {
          this.loader = false;
          this.toastr.error(res.message || 'An error occurred. Please try again.', 'Error');
        }
      },
      (err) => {
        this.loader = false;
        if (err?.status !== 401) {
          let errorMessage = 'An error occurred. Please try again later.'
          if (err.error) {
            if (err.error.errors && Object.keys(err.error.errors).length > 0) {
              errorMessage = err.error.errors;
            } else if (err.error.message) {
              errorMessage = err.error.message;
            }
          }
          this.toastr.error(errorMessage, 'Error');
        }
      }
    );
  }

  onSearchChange(searchTexts: any) {
    const trimmedText = searchTexts?.trim();
    if (trimmedText) {
      this.searchText = searchTexts;
      this.getGeniusPairingList();
    } else if (searchTexts === "") {
      this.getGeniusPairingList();
    }
  }

  clearAll() {
    this.searchText = '';
    this.getGeniusPairingList();
  }

  openModalAddGeniusPairing(addPairing: any) {
    this.modalService.open(addPairing, {
      centered: true,
      size: "md",
      windowClass: "master_modal add_content",
    });
  }

  openModalEditPairing(edit: any, pairingId: any) {
    if (pairingId) {
      this.selectedGeniusPairing = pairingId;
      this.getGeniusPairingsByIdById();
    }
    this.modalService.open(edit, {
      centered: true,
      size: "md",
      windowClass: "master_modeladd_content",
    })
  }

  openModaldeletePairing(deleteModal: any, pairingId: any) {
    if (pairingId) {
      this.selectedGeniusPairing = pairingId;
    }
    this.modalService.open(deleteModal, {
      centered: true,
      size: "md",
      windowClass: "master_modeladd_content",
    })
  }

  handlePageEvent(event: any) {
    this.limit = event?.pageSize;
    this.pageNumber = event?.pageIndex + 1
    this.getGeniusPairingList()
  }

  toTitleCase(str: string): string {
    return str
      ?.toLowerCase()
      ?.split(' ')
      ?.map(word => word.charAt(0).toUpperCase() + word.slice(1))
      ?.join(' ');
  }
}
