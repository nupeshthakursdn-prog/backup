import { Component } from '@angular/core';
import Chart from 'chart.js/auto';
import { CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend } from 'chart.js';
import { ActivatedRoute, Router } from '@angular/router';
import { ResumeParseService } from 'src/app/services/resume-parse.service';
import { ToastrService } from 'ngx-toastr';

Chart.register(CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend);
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent {
  dashboardData: any;
  loader: boolean = false;
  monthly_data: any;
  totalProfileCreated: any = 0;
  totalPDFsExported: any = 0;
  years: number[] = [];
  selected_year: any = new Date().getFullYear()
  chartInstance: Chart | null = null; // Store chart instance

  ngAfterViewInit() {
  }

  constructor(private resumeParseService: ResumeParseService, private toastr: ToastrService, private router: Router) { }

  ngOnInit() {
    this.getDashboardDetails();
  }

  populateYears(): void {
    const currentYear = new Date().getFullYear();
    this.years = Array.from({ length: 5 }, (_, i) => currentYear - i);
  }

  getDashboardDetails() {
    this.loader = true;
    this.resumeParseService.dashboardDetails(this.selected_year).subscribe(
      (res: any) => {
        if (res?.status === 200) {
          this.dashboardData = res?.data;
          this.monthly_data = this.dashboardData?.monthly_counts;
          this.totalProfileCreated = res?.data?.total_profile_created;
          this.totalPDFsExported = res?.data?.total_pdf_exported;
          if (this.monthly_data) {
            this.renderChart(this.monthly_data);
          }
          this.populateYears();
          this.loader = false;
        } else {
          this.loader = false;
          this.toastr.error(res?.message || 'An error occurred. Please try again.', 'Error');
        }
      },
      (err) => {
        this.loader = false;
        if (err?.status !== 401) {
          let errorMessage = 'An error occurred. Please try again later.';
          if (err.error) {
            if (err.error.errors && Object.keys(err.error.errors).length > 0) {
              errorMessage = err.error.errors;
            } else if (err.error.message) {
              errorMessage = err.error.message;
            }
          }
          this.toastr.error(errorMessage, 'Error');
        }
      }
    );
  }


  renderChart(monthly_data: any) {
    const ctx = document.getElementById('profileChart') as HTMLCanvasElement;

    if (!ctx) {
      console.error("Canvas element not found!");
      return;
    }

    // Destroy existing chart instance if it exists
    if (this.chartInstance) {
      this.chartInstance.destroy();
    }

    const allMonths = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

    // Convert `monthly_data` keys to match allMonths format
    const formattedData: number[] = allMonths.map(month => monthly_data[month] || 0);

    // Create a new chart instance and store it
    this.chartInstance = new Chart(ctx, {
      type: 'line',
      data: {
        labels: allMonths,
        datasets: [
          {
            label: 'Total Profile',
            data: formattedData,
            borderColor: '#6a1b9a',
            backgroundColor: 'rgba(106, 27, 154, 0.2)',
            pointBackgroundColor: '#6a1b9a',
            pointRadius: 5,
            fill: true,
            tension: 0.4,
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            display: true,
            labels: { color: '#333' }
          },
          tooltip: {
            callbacks: {
              label: function (tooltipItem: any) {
                return `Total Profile: ${tooltipItem.raw}`;
              }
            }
          }
        },
        scales: {
          x: { type: 'category', ticks: { color: '#333' } },
          y: { beginAtZero: true, ticks: { color: '#333' } }
        }
      }
    });
  }

  filterByYear(year: number): void {
    this.selected_year = year;
    this.getDashboardDetails();
  }

  redirectToCandidates() {
    this.router.navigate(['candidate-profile-creation'])
  }

}
