import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UserService } from 'src/app/services/user.service';
import { ToastrService } from 'ngx-toastr';
import { NavigationEnd, Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent {
  passwordVisible: boolean = false;
  loginForm!: FormGroup;
  submitted = false;
  loader: boolean = false;
  loginUserId: any = '';
  permissionsData: any = [];

  constructor(private fb: FormBuilder, private userService: UserService, private toastr: ToastrService,
    private router: Router) {

    const token = localStorage.getItem('token');

    if (token) {
      this.router.navigate(['/dashboard']);
    }

    this.loginForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]],
      // rememberMe: [false]
    });
  }

  ngOnInit() {
  }

  onSubmit() {
    this.submitted = true;

    if (this.loginForm.invalid) {
      return;
    }

    this.loader = true
    const data = this.loginForm.value;
    this.userService.login(data).subscribe(
      (res: any) => {

        if (res?.status === 200) {
          const loginUserInfo = {
            first_name: res?.data?.first_name,
            last_name: res?.data?.last_name,
            user_id: res?.data?.user_id,
            role: res?.data?.user_type,
            is_staff: res?.data?.is_staff,
            image: res?.data?.image
          };

          this.loader = false;
          localStorage.setItem('token', res?.data?.token?.access);
          localStorage.setItem('loginUser', JSON.stringify(loginUserInfo));
          this.router.navigate(['dashboard']);
          this.toastr.success(res.message, 'Success');

          if (res?.data?.user_id) {
            this.loginUserId = res?.data?.user_id
            this.getPermissionsById();
          }

        } else {
          this.loader = false;
          this.toastr.error(res.message || 'An error occurred. Please try again.', 'Error');
        }
      },
      (err: any) => {
        this.loader = false;
        let errorMessage = 'An error occurred. Please try again later.'
        if (err.error) {
          if (err.error.errors && Object.keys(err.error.errors).length > 0) {
            errorMessage = err.error.errors;
          } else if (err.error.message) {
            errorMessage = err.error.message;
          }
        }
        this.toastr.error(errorMessage, '');
      }
    );
  }

  getPermissionsById() {
    this.loader = true
    let queryData = {
      staff_id: this.loginUserId,
      role_id:''
    }
    this.userService.getPermissions(queryData).subscribe(
      (res: any) => {
        if (res?.status === 200) {
          this.loader = false;
          this.permissionsData = res?.data?.permission;
          localStorage.setItem("permissions", JSON.stringify(this.permissionsData))
        } else {
          this.loader = false;
          this.permissionsData = []
        }
      },
      (err) => {
        this.permissionsData = []
        // localStorage.setItem("permissions",this.permissionsData)
        this.loader = false;
        let errorMessage = 'An error occurred. Please try again later.'
        if (err.error) {
          if (err.error.errors && Object.keys(err.error.errors).length > 0) {
            errorMessage = err.error.errors;
            this.toastr.error(errorMessage);
          } else if (err.error.message) {
            errorMessage = err.error.message;
            // this.toastr.error(errorMessage);
          }
        }
      }
    );
  }

  get f() {
    return this.loginForm.controls;
  }
  togglePasswordVisibility() {
    this.passwordVisible = !this.passwordVisible;
  }
}
