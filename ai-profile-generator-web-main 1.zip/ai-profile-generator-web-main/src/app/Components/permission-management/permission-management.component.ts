import { Component } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ToastrService } from 'ngx-toastr';
import { MasterService } from 'src/app/services/master.service';
import { UserService } from 'src/app/services/user.service';

interface Food {
  value: string;
  viewValue: string;
}
interface Permission {
  value: string;
}

@Component({
  selector: 'app-permission-management',
  templateUrl: './permission-management.component.html',
  styleUrls: ['./permission-management.component.scss']
})
export class PermissionManagementComponent {

  foods: Food[] = [
    { value: 'steak-0', viewValue: 'Steak' },
    { value: 'pizza-1', viewValue: 'Pizza' },
    { value: 'tacos-2', viewValue: 'Tacos' },
  ];
  loader: boolean = false
  limit: any = ''
  pageNumber: any = 1
  totalLength: any = 0
  searchText: any = ''

  staffList: any = [];
  rolesList: any = [];
  selectedStaffId: any = '';
  selectedRole: any = '';
  permissionsData: any = [];
  selectedPermissions: any = [];

  constructor(private fb: FormBuilder, private modalService: NgbModal, public dialog: MatDialog,
    private masterService: MasterService, private router: Router, private toastr: ToastrService, private userService: UserService) { }

  ngOnInit() {
    this.getStaffList();
    this.getRoles();
  }

  getPermissionsById() {
    this.loader = true
    let queryData = {
      staff_id: this.selectedStaffId,
      role_id: this.selectedRole
    }
    this.userService.getPermissionsForAdmin(queryData).subscribe(
      (res: any) => {
        if (res?.status === 200) {
          this.loader = false;


          this.permissionsData = res?.data?.permission;
          this.selectedPermissions = this.permissionsData;
          // console.log(this.selectedPermissions, "permissionsData____");
        } else {
          this.loader = false;
          this.permissionsData = []
          this.selectedPermissions = []
        }
      },
      (err) => {
        this.permissionsData = []
        this.selectedPermissions = []
        this.loader = false;
        if (err?.status !== 401) {
          let errorMessage = 'An error occurred. Please try again later.'
          if (err.error) {
            if (err?.error?.errors && Object.keys(err?.error?.errors).length > 0) {
              errorMessage = err.error.errors;
              this.toastr.error(errorMessage);
            } else if (err?.error?.message) {
              errorMessage = err.error.message;
              this.toastr.error(errorMessage);
            }
          }
        }
      }
    );
  }

  getStaffList() {
    this.loader = true;
    let queryData = {
      limit: '',
      page: this.pageNumber,
      searchText: this.searchText,
      status: 'active',
      role: this.selectedRole
    }
    this.userService.getStaffs(queryData).subscribe(
      (res: any) => {
        if (res?.status === 200) {
          this.loader = false;
          this.staffList = res?.data?.staffs;
        } else {
          this.loader = false
          this.staffList = [];
          this.totalLength = 0
        }
      },
      (err) => {
        this.loader = false
        if (err?.status !== 401) {
          let errorMessage = 'An error occurred. Please try again later.'
          if (err.error) {
            if (err.error.errors && Object.keys(err.error.errors).length > 0) {
              errorMessage = err.error.errors;
            } else if (err.error.message) {
              errorMessage = err.error.message;
            }
          }
        }
      }
    );
  }

  getRoles() {
    let queryData = {
      limit: '',
      page: '',
      searchText: ''
    }
    this.userService.getRoles(queryData).subscribe(
      (res: any) => {
        if (res?.status === 200) {
          this.rolesList = res?.data?.roles;
        } else {
          this.rolesList = []
        }
      },
      (err) => {
        if (err?.status !== 401) {
          let errorMessage = 'An error occurred. Please try again later.'
          if (err.error) {
            if (err.error.errors && Object.keys(err.error.errors).length > 0) {
              errorMessage = err.error.errors;
            } else if (err.error.message) {
              errorMessage = err.error.message;
            }
          }
        }
      }
    );
  }

  addPermission() {

    if (this.permissionsData.length > 0 && this.selectedStaffId) {
      this.loader = true
      let data = {
        permission: this.selectedPermissions,
        staff_id: this.selectedStaffId
      }
      this.userService.updatePermissions(data).subscribe(
        (res: any) => {
          if (res?.status === 200) {
            this.loader = false;
            this.getPermissionsById();
            this.toastr.success(res.message, 'Success');
          } else {
            this.loader = false;
            this.toastr.error(res.message || 'An error occurred. Please try again.', 'Error');
          }
        },
        (err) => {
          this.loader = false;
          if (err?.status !== 401) {
            let errorMessage = 'An error occurred. Please try again later.'
            if (err.error) {
              if (err.error.errors && Object.keys(err.error.errors).length > 0) {
                this.toastr.error(err.error.errors);
                // for (let field in err.error.errors) {
                //   if (err.error.errors.hasOwnProperty(field)) {
                //     this.toastr.error(err.error.errors[field]);
                //   }
                // }
                errorMessage = err.error.errors;
              } else if (err.error.message) {
                errorMessage = err.error.message;
                this.toastr.error(errorMessage);
              }
            }
          }
        }
      );

    } else if (this.permissionsData.length > 0 && this.selectedRole) {
      this.loader = true
      let data = {
        permission: this.selectedPermissions,
        role_id: this.selectedRole
      }
      this.userService.updatePermissions(data).subscribe(
        (res: any) => {
          if (res?.status === 200) {
            this.loader = false;
            this.getPermissionsById();
            this.toastr.success(res.message, 'Success');
          } else {
            this.loader = false;
            this.toastr.error(res.message || 'An error occurred. Please try again.', 'Error');
          }
        },
        (err) => {
          this.loader = false;
          if (err?.status !== 401) {
            let errorMessage = 'An error occurred. Please try again later.'
            if (err.error) {
              if (err.error.errors && Object.keys(err.error.errors).length > 0) {
                this.toastr.error(err.error.errors);
                // for (let field in err.error.errors) {
                //   if (err.error.errors.hasOwnProperty(field)) {
                //     this.toastr.error(err.error.errors[field]);
                //   }
                // }
                errorMessage = err.error.errors;
              } else if (err.error.message) {
                errorMessage = err.error.message;
                this.toastr.error(errorMessage);
              }
            }
          }
        }
      );
    } else if (this.selectedPermissions.length && this.selectedStaffId) {

      this.loader = true;

      let data = {
        permission: this.selectedPermissions,
        staff_id: this.selectedStaffId
      }
      this.userService.addPermissions(data).subscribe(
        (res: any) => {
          if (res?.status === 200) {
            this.loader = false;
            this.getPermissionsById();
            this.toastr.success(res.message, 'Success');
          } else {
            this.loader = false;
            this.toastr.error(res.message || 'An error occurred. Please try again.', 'Error');
          }
        },
        (err) => {
          this.loader = false;
          let errorMessage = 'An error occurred. Please try again later.'
          if (err.error) {
            if (err.error.errors && Object.keys(err.error.errors).length > 0) {
              this.toastr.error(err.error.errors);
              // for (let field in err.error.errors) {
              //   if (err.error.errors.hasOwnProperty(field)) {
              //     this.toastr.error(err.error.errors[field]);
              //   }
              // }
              errorMessage = err.error.errors;
            } else if (err.error.message) {
              errorMessage = err.error.message;
              this.toastr.error(errorMessage);
            }
          }
        }
      );
    } else if (this.selectedPermissions.length && this.selectedRole && !this.selectedStaffId) {

      this.loader = true;

      let data = {
        permission: this.selectedPermissions,
        role_id: this.selectedRole
      }
      this.userService.addPermissions(data).subscribe(
        (res: any) => {
          if (res?.status === 200) {
            this.loader = false;
            this.getPermissionsById();
            this.toastr.success(res.message, 'Success');
          } else {
            this.loader = false;
            this.toastr.error(res.message || 'An error occurred. Please try again.', 'Error');
          }
        },
        (err) => {
          this.loader = false;
          if (err?.status !== 401) {
            let errorMessage = 'An error occurred. Please try again later.'
            if (err.error) {
              if (err.error.errors && Object.keys(err.error.errors).length > 0) {
                this.toastr.error(err.error.errors);
                // for (let field in err.error.errors) {
                //   if (err.error.errors.hasOwnProperty(field)) {
                //     this.toastr.error(err.error.errors[field]);
                //   }
                // }
                errorMessage = err.error.errors;
              } else if (err.error.message) {
                errorMessage = err.error.message;
                this.toastr.error(errorMessage);
              }
            }
          }
        }
      );
    } else {
      this.toastr.error('Please select a staff or role and set their permissions before proceeding.');
    }
  }

  togglePermission(event: Event, value: string) {
    if (this.selectedStaffId || this.selectedRole) {
      const isChecked = (event.target as HTMLInputElement).checked;
      if (isChecked) {

        // Add the permission if checked
        this.selectedPermissions.push(value);
      } else {
        this.selectedPermissions = this.selectedPermissions.filter((p: string) => p !== value);
      }
      // console.log(this.selectedPermissions, "selectedPermissions_____");
    } else {
      this.selectedPermissions = [];
      this.toastr.error('please select the staff or role first');
    }
  }

  onStaffSelectionChange(event: any) {
    if (event?.value) {
      this.selectedPermissions = []
      this.selectedStaffId = event?.value;
      this.getPermissionsById();
    }
  }

  onRoleSelectionChange(event: any) {
    if (event?.value) {
      this.selectedRole = event?.value;
      this.selectedStaffId = ''
      this.selectedPermissions = []
      this.getPermissionsById();
      this.getStaffList();
    }
  }

  clearAll() {
    if (this.selectedRole || this.selectedStaffId) {
      this.permissionsData = [];
      this.selectedPermissions = [];
      this.selectedRole = '';
      this.selectedStaffId = '';
      this.getStaffList();
      this.getRoles();
    }
  }
}
