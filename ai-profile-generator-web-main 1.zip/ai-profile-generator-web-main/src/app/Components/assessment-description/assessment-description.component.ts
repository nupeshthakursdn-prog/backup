import { Component } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { MatDialog } from '@angular/material/dialog';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { MasterService } from 'src/app/services/master.service';


export interface PeriodicElement {
  typeOfScore: string;
  value: string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  {
    typeOfScore: 'Work Style',
    value: '0-5'
  },
  {
    typeOfScore: 'Cognitive Ability',
    value: '5-10'
  },
  {
    typeOfScore: 'Technical Proficiency',
    value: '10-15'
  },
];

@Component({
  selector: 'app-assessment-description',
  templateUrl: './assessment-description.component.html',
  styleUrls: ['./assessment-description.component.scss']
})
export class AssessmentDescriptionComponent {

  loader: boolean = false
  limit: any = 10
  pageNumber: any = 1
  totalLength: any = 0
  searchText: any = ''

  displayedColumns: string[] = ['typeOfScore', 'description', 'actions'];
  dataSource = ELEMENT_DATA;
  ELEMENT_DATA: PeriodicElement[] = [];
  rolesList: any = []
  scoresList: any = []
  assessmentDescriptionList: any = []
  assessmentDescriptionForm: FormGroup;
  updateAssessmentDescriptionForm: FormGroup;
  selectedScoreDesId: any = '';;
  selectedScoreDescription: any = ''

  descriptionTypes: { key: string; label: string }[] = [];

  constructor(private fb: FormBuilder, private modalService: NgbModal, public dialog: MatDialog,
    private masterService: MasterService, private toastr: ToastrService) {

    this.assessmentDescriptionForm = this.fb.group({
      assessment_description_type: ['', Validators.required],
      description: ['', Validators.required],
    });

    this.updateAssessmentDescriptionForm = this.fb.group({
      assessment_description_type: ['', Validators.required],
      description: ['', Validators.required],
    });

  }

  ngOnInit(): void {
    this.getAssessmentsDescription();
  }

  getAssessmentsDescription() {
    this.loader = true
    let queryData = {
      limit: this.limit,
      page: this.pageNumber,
      searchText: this.searchText
    }
    this.masterService.getAssessmentDescription(queryData).subscribe(
      (res: any) => {
        this.loader = false;
        if (res?.status === 200 && res?.data?.results) {
          this.assessmentDescriptionList = res?.data?.results;
          this.descriptionTypes = res?.data?.description_types;
          this.totalLength = res?.data?.total;
        }
      },
      (err) => {
        this.loader = false;
        if (err?.status !== 401) {
          let errorMessage = 'An error occurred. Please try again later.'
          if (err.error) {
            if (err.error.errors && Object.keys(err.error.errors).length > 0) {
              errorMessage = err.error.errors;
            } else if (err.error.message) {
              errorMessage = err.error.message;
            }
          }
        }
      }
    );
  }

  getAssessmentDescriptionById() {

    this.loader = true;

    this.masterService.getAssessmentDesById(this.selectedScoreDescription).subscribe(
      (res: any) => {
        this.loader = false;

        if (res?.status === 200 && res?.data) {
          const { assessment_description_type, description } = res.data;

          this.updateAssessmentDescriptionForm.patchValue({
            assessment_description_type: assessment_description_type || '',
            description: description || ''
          });

        } else {
          this.toastr.error(res?.message || "An error occurred. Please try again.", "Error");
        }
      },
      (err) => {
        this.loader = false;
        if (err?.status !== 401) {
          let errorMessage = 'An error occurred. Please try again later.'
          if (err.error) {
            if (err.error.errors && Object.keys(err.error.errors).length > 0) {
              errorMessage = err.error.errors;
            } else if (err.error.message) {
              errorMessage = err.error.message;
            }
          }
          this.toastr.error(errorMessage, 'Error');
        }
      }
    );
  }


  onSubmit(): void {

    if (this.assessmentDescriptionForm.valid) {
      this.loader = true;
      const { assessment_description_type, description } = this.assessmentDescriptionForm.value;

      const data = {
        assessment_description_type: assessment_description_type.toLowerCase(),
        description: description
      };
      
      this.masterService.addAssessmentDescription(data).subscribe(
        (res: any) => {
          this.loader = false;
          if (res?.status === 200) {
            this.toastr.success(res.message, "Success");
            this.modalService.dismissAll();
            this.assessmentDescriptionForm.reset();
            this.getAssessmentsDescription();
          } else {
            this.toastr.error(res.message || "An error occurred. Please try again.", "Error");
          }
        },
        (err) => {
          this.loader = false;
          if (err?.status !== 401) {
            let errorMessage = 'An error occurred. Please try again later.';
            if (err?.error) {
              if (err?.error?.errors && Object.keys(err?.error?.errors).length > 0) {
                for (let field in err.error.errors) {
                  if (err.error.errors.hasOwnProperty(field)) {
                    this.toastr.error(err.error.errors[field]);
                  }
                }
              } else if (err?.error?.message) {
                errorMessage = err?.error?.message;
                this.toastr.error(errorMessage, 'Error');
              }
            }
          }
        }
      );
    } else {
      this.toastr.error("Please select all required fields");
      this.assessmentDescriptionForm.markAllAsTouched();
    }
  }


  onSubmitUpdate(): void {

    if (this.updateAssessmentDescriptionForm.valid) {
      this.loader = true;
      const { assessment_description_type, description } = this.updateAssessmentDescriptionForm.value;

      const data = {
        assessment_description_id: this.selectedScoreDescription, 
        assessment_description_type: assessment_description_type, 
        description: description
      };
      this.masterService.updateAssessmentDescriptionId(data).subscribe(
        (res: any) => {
          this.loader = false;
          if (res?.status === 200) {
            this.toastr.success(res.message, "Success");
            this.modalService.dismissAll();
            this.getAssessmentsDescription();
          } else {
            this.toastr.error(res.message || "An error occurred. Please try again.", "Error");
          }
        },
        (err) => {
          this.loader = false;
          if (err?.status !== 401) {
            let errorMessage = 'An error occurred. Please try again later.';
            if (err?.error) {
              if (err?.error?.errors && typeof err.error.errors === 'object' && Object.keys(err.error.errors).length > 0) {
                for (let field in err.error.errors) {
                  if (err.error.errors.hasOwnProperty(field)) {
                    this.toastr.error(err.error.errors[field], 'Error');
                  }
                }
              } else if (err?.error?.message) {
                errorMessage = err.error.message; // Now it correctly captures "Score description already exist."
                this.toastr.error(errorMessage);
              }
            }
          }
        }
      );
    } else {
      this.toastr.error("Please select all required fields");
      this.updateAssessmentDescriptionForm.markAllAsTouched();
    }
  }


  deleteAssessmentDescription() {
    this.loader = true
    this.masterService.deleteAssessmentDescriptionById(this.selectedScoreDescription).subscribe(
      (res: any) => {
        if (res?.status === 200) {
          this.loader = false
          this.toastr.success(res.message, 'Success');
          this.modalService.dismissAll();
          this.getAssessmentsDescription()
        } else {
          this.loader = false;
          this.toastr.error(res.message || 'An error occurred. Please try again.', 'Error');
        }
      },
      (err) => {
        this.loader = false;
        if (err?.status !== 401) {
          let errorMessage = 'An error occurred. Please try again later.'
          if (err.error) {
            if (err.error.errors && Object.keys(err.error.errors).length > 0) {
              errorMessage = err.error.errors;
            } else if (err.error.message) {
              errorMessage = err.error.message;
            }
          }
          this.toastr.error(errorMessage, 'Error');
        }
      }
    );
  }

  onSearchChange(searchTexts: any) {
    const trimmedText = searchTexts?.trim();
    if (trimmedText) {
      this.searchText = searchTexts;
      this.getAssessmentsDescription();
    } else if (searchTexts === "") {
      this.getAssessmentsDescription();
    }
  }

  clearAll() {
    this.searchText = '';
    this.selectedScoreDesId = '';
    this.getAssessmentsDescription();
  }

  openModalAddscore(addScore: any) {
    this.assessmentDescriptionForm.setValue({
      assessment_description_type: '',
      description: ''
    });
    this.modalService.open(addScore, {
      centered: true,
      size: "md",
      windowClass: "master_modal add_content",
    });
  }

  openModaleditscore(edit: any, scoreId: any) {

    if (scoreId) {
      this.selectedScoreDescription = scoreId;
      this.getAssessmentDescriptionById();
    }
    this.modalService.open(edit, {
      centered: true,
      size: "md",
      windowClass: "master_modeladd_content",
    })
  }

  openModaldeletescore(deleteModal: any, scoreId: any) {
    if (scoreId) {
      this.selectedScoreDesId = scoreId;
    }
    this.modalService.open(deleteModal, {
      centered: true,
      size: "md",
      windowClass: "master_modeladd_content",
    })
  }

  handlePageEvent(event: any) {
    this.limit = event?.pageSize;
    this.pageNumber = event?.pageIndex + 1
    this.getAssessmentsDescription()
  }

  toTitleCase(str: string): string {
    return str
      ?.toLowerCase()
      ?.split(' ')
      ?.map(word => word.charAt(0).toUpperCase() + word.slice(1))
      ?.join(' ');
  }
}
