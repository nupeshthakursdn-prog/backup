import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AssessmentDescriptionComponent } from './assessment-description.component';

describe('AssessmentDescriptionComponent', () => {
  let component: AssessmentDescriptionComponent;
  let fixture: ComponentFixture<AssessmentDescriptionComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AssessmentDescriptionComponent]
    });
    fixture = TestBed.createComponent(AssessmentDescriptionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
