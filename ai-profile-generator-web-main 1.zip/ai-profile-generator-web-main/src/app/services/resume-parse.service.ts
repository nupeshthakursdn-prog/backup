import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ResumeParseService {

  getBasePath() {
    return environment.apiUrl;
  }

  getToken() {
    return localStorage.getItem('token');
  }
  getHeader(token: any) {
    const httpHeaders = new HttpHeaders({
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`
    });
    return httpHeaders;
  }

  constructor(private http: HttpClient) { }

  // Dashboard Counts
  dashboardDetails(selected_year: any) {
    return this.http.get(
      this.getBasePath() + `resume-parsing/countfordashboard/?selected_year=${selected_year}`,
      {
        headers: this.getHeader(this.getToken())
      }
    );
  }

  //Get Resume Parse Data

  getResumeParseData(formData: any) {
    return this.http.post(
      this.getBasePath() + `resume-parsing/resume-parse/`,
      formData,
      {
        headers: new HttpHeaders({
          'Authorization': `Bearer ${this.getToken()}`
        })
      }
    );
  }

  //Get Technical proficiency by role
  getTechnicalProficiencyByRoleCategory(data: any) {
    return this.http.get(
      this.getBasePath() + `master/technical-proficiency-by-role/?role_category=${data?.role_category_id}`,
      {
        headers: this.getHeader(this.getToken())
      }
    );
  }

  // Candidate Management

  addCandidate(formdata: any) {
    return this.http.post(
      this.getBasePath() + `resume-parsing/candidate/`,
      formdata,
      {
        headers: new HttpHeaders({
          'Authorization': `Bearer ${this.getToken()}`
        })
      }
    );
  }

  getCandidates(data: any) {
    return this.http.get(
      this.getBasePath() + `resume-parsing/candidate/?page=${data?.page}&limit=${data?.limit}&search_text=${data?.searchText}&role_category=${data?.role_category_id}&type=${data?.type}`,
      {
        headers: this.getHeader(this.getToken())
      }
    );
  }


  getCandidatesDrafts(data: any) {
    return this.http.get(
      this.getBasePath() + `resume-parsing/draft-candidate-profiles/?page=${data?.page}&limit=${data?.limit}&search_text=${data?.searchText}&role_category=${data?.role_category_id}&type=${data?.type}`,
      {
        headers: this.getHeader(this.getToken())
      }
    );
  }

  deleteCandidate(data: any) {
    return this.http.delete(
      this.getBasePath() + `resume-parsing/candidate/${data.id}`,
      {
        headers: this.getHeader(this.getToken())
      }
    );
  }

  getCandidateProfileById(data: any) {
    return this.http.get(
      this.getBasePath() + `resume-parsing/candidate/${data.id}`,
      {
        headers: this.getHeader(this.getToken())
      }
    );
  }

  updateCandidateProfile(formdata: any) {
    return this.http.put(
      this.getBasePath() + `resume-parsing/candidate/`,
      formdata,
      {
        headers: new HttpHeaders({
          'Authorization': `Bearer ${this.getToken()}`
        })
      }
    );
  }

  deleteSelectedCandidates(data: any) {
    return this.http.post(
      this.getBasePath() + `resume-parsing/bulk-delete-candidate/`,
      data,
      {
        headers: new HttpHeaders({
          'Authorization': `Bearer ${this.getToken()}`
        })
      }
    );
  }

  // Resume Template details of Candidate
  getTemplateDetailsOfCandidate(data: any) {
    return this.http.get(
      this.getBasePath() + `resume-parsing/template-details/${data.id}`,
      {
        headers: this.getHeader(this.getToken())
      }
    );
  }

  // Update Candidate Resume Export Status
  updateResumeExportStatus(data: any) {
    return this.http.get(
      this.getBasePath() + `resume-parsing/pdf-exported-status/${data.id}/`,
      {
        headers: this.getHeader(this.getToken())
      }
    );
  }

  saveCandidateResume(formdata: any) {
    return this.http.post(
      this.getBasePath() + `resume-parsing/save-candidate-resume/`,
      formdata,
      {
        headers: new HttpHeaders({
          'Authorization': `Bearer ${this.getToken()}`
        })
      }
    );
  }

}
