import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders } from "@angular/common/http";
import { environment } from 'src/environments/environment';
import { Token } from '@angular/compiler';
import { BehaviorSubject, Observable } from 'rxjs';
import { tap, catchError } from 'rxjs/operators';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  logoutUser(){
    localStorage.removeItem('token');
    localStorage.removeItem('loginUser')
    localStorage.removeItem('permissions')
  }

  getBasePath() {
    return environment.apiUrl;
  }

  getToken() {
    return localStorage.getItem('token');
  }

  getHeader(token: any) {
    const httpHeaders = new HttpHeaders({
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`
    });
    return httpHeaders;
  }

  private areArraysEqual(arr1: string[], arr2: string[]): boolean {
    if (arr1.length !== arr2.length) return false; // Quick length check
  
    // Convert to Set and compare (Handles order differences efficiently)
    return new Set(arr1).size === new Set(arr2).size && arr1.every(item => arr2.includes(item));
  }
  

  constructor(private http: HttpClient,private toastr: ToastrService, private router :Router) { 
    // this.loadPermissions() 
  }

  // private permissionsSubject = new BehaviorSubject<string[]>([]);
  // public permissions$ = this.permissionsSubject.asObservable();

  // private loadPermissions() {
  //   const permissionsData = localStorage.getItem('permissions');
  //   const permissions = permissionsData ? JSON.parse(permissionsData) : [];
  //   this.permissionsSubject.next(permissions);
  // }

  // updatePermissionsData() {
  //   this.loadPermissions();
  // }

  // API call one 
  private permissionsSubject = new BehaviorSubject<string[]>([]);
  permissions$ = this.permissionsSubject.asObservable();
  private lastUpdated: number = 0;
  private PERMISSION_EXPIRY_TIME = 5 * 60 * 1000;

  updatePermissionsFromServer(staffId: string): void {
    if (!staffId) {
      console.warn('Staff ID is missing, cannot fetch permissions.');
      return;
    }

    this.http.get<string[]>(`${this.getBasePath()}auth/permission/?staff_id=${staffId}`,{ headers: this.getHeader(this.getToken())}).subscribe(
      (updatedPermissions: any) => {
        // console.log('Updated permissions:', updatedPermissions);
        const newPermissions = updatedPermissions?.data?.permission || [];
        const oldPermissions = JSON.parse(localStorage.getItem('permissions') || '[]');
        // var currenturl=this.router.url
        // this.router.navigate([currenturl])
        // console.log(currenturl,"pdating permissions From Intercepter...");
        if (!this.areArraysEqual(oldPermissions, newPermissions)) {
          // console.log("not_match_______");
          
          // console.log("Permissions changed, reloading page...");
          localStorage.setItem('permissions', JSON.stringify(newPermissions));
          this.permissionsSubject.next(newPermissions);
         
          this.toastr.success('Your permissions got updated!');
          localStorage.setItem('permissions', JSON.stringify(updatedPermissions?.data?.permission));
          // setTimeout(()=>{
          //   window.location.reload();
          // },1000)
        } else {
          // console.log("Permissions are the same, no reload needed.");
          this.permissionsSubject.next(oldPermissions);

        }

        // this.permissionsSubject.next(updatedPermissions); // Emit new permissions to update components
      },
      (error) => {
        console.error('Failed to fetch permissions', error);
      }
    );
  }

  getPermissionsFromLocal(): Observable<string[]> {
    return this.permissions$; // Observable for sidebar to listen
  }

  resetPermissions() {
    this.permissionsSubject.next([]); // Clears the permissions
  }

  private getStoredPermissions(): string[] {
    const storedPermissions = localStorage.getItem('permissions');
    return storedPermissions ? JSON.parse(storedPermissions) : [];
  }

  getCachedPermissions(): string[] {
    return this.permissionsSubject.value;
  }

  isPermissionsOutdated(): boolean {
    return (Date.now() - this.lastUpdated) > this.PERMISSION_EXPIRY_TIME;
  }

  updateCachedPermissions(permissions: string[]) {
    this.permissionsSubject.next(permissions);
    this.lastUpdated = Date.now();
  }

  // Authentications Services

  // Get User Details Real Time
  private userDetails = new BehaviorSubject<any>(null);
  userDetails$ = this.userDetails.asObservable();

  updateUserDetails(user: any) {
    this.userDetails.next(user);
  }

  login(data: any) {
    return this.http.post(
      this.getBasePath() + `auth/login/`,
      data,
      {
        headers: new HttpHeaders({
          "Content-Type": "application/json"
        })
      }
    );
  }

  forgotPassword(data: any) {
    return this.http.post(
      this.getBasePath() + `auth/forgotpassword/`,
      data,
      {
        headers: new HttpHeaders({
          "Content-Type": "application/json"
        })
      }
    );
  }

  resetPassword(data: any) {
    return this.http.post(
      this.getBasePath() + `auth/resetpassword/`,
      data,
      {
        headers: new HttpHeaders({
          "Content-Type": "application/json"
        })
      }
    );
  }

  resetPasswordStaff(data: any) {
    return this.http.post(
      this.getBasePath() + `auth/set-password/`,
      data,
      {
        headers: new HttpHeaders({
          "Content-Type": "application/json"
        })
      }
    );
  }

  //Update Profile
  updateUserProfile(formData: any) {
    return this.http.put(
      this.getBasePath() + `auth/updateprofile/`,
      formData,
      {
        headers: new HttpHeaders({
          'Authorization': `Bearer ${this.getToken()}`
        })
      }
    );
  }

  //Change Password
  changePassword(data: any) {
    return this.http.put(
      this.getBasePath() + `auth/changepassword/${data.loggedInUserId}/`,
      data,
      {
        headers: new HttpHeaders({
          'Authorization': `Bearer ${this.getToken()}`
        })
      }
    );
  }

  // Role Management

  addRole(data: any) {
    return this.http.post(
      this.getBasePath() + `auth/getroles/`,
      data,
      {
        headers: this.getHeader(this.getToken())
      }
    );
  }

  getRoles(data: any) {
    return this.http.get(
      this.getBasePath() + `auth/getroles/?page=${data?.page}&limit=${data?.limit}&search_text=${data?.searchText}`,
      {
        headers: this.getHeader(this.getToken())
      }
    );
  }

  getRoleById(data: any) {
    return this.http.get(
      this.getBasePath() + `auth/getroles/${data?.id}`,
      {
        headers: this.getHeader(this.getToken())
      }
    );
  }

  updateRoleById(data: any) {
    return this.http.put(
      this.getBasePath() + `auth/getroles/`,
      data,
      {
        headers: this.getHeader(this.getToken())
      }
    );
  }

  deleteRoleById(data: any) {
    return this.http.delete(
      this.getBasePath() + `auth/getroles/${data.id}`,
      {
        headers: this.getHeader(this.getToken())
      }
    );
  }

  // Staff Management

  addStaff(formdata: any) {

    return this.http.post(
      this.getBasePath() + `auth/getstaff/`,
      formdata,
      {
        headers: new HttpHeaders({
          'Authorization': `Bearer ${this.getToken()}`
        })
      }
    );
  }

  getStaffs(data: any) {
    return this.http.get(
      this.getBasePath() + `auth/getstaff/?page=${data?.page}&limit=${data?.limit}&search_text=${data?.searchText}&status=${data.status}&role=${data?.role}`,
      {
        headers: this.getHeader(this.getToken())
      }
    );
  }

  getStaffById(data: any) {
    return this.http.get(
      this.getBasePath() + `auth/getstaff/${data?.id}`,
      {
        headers: this.getHeader(this.getToken())
      }
    );
  }

  updateStaffById(formData: any) {
    return this.http.put(
      this.getBasePath() + `auth/getstaff/`,
      formData,
      {
        headers: new HttpHeaders({
          'Authorization': `Bearer ${this.getToken()}`
        })
      }
    );
  }

  deleteStaffById(data: any) {
    return this.http.delete(
      this.getBasePath() + `auth/getstaff/${data.id}`,
      {
        headers: this.getHeader(this.getToken())
      }
    );
  }

  sendSetPasswordLink(email: any) {
    return this.http.post(
      this.getBasePath() + `auth/set-password-link/`,
      email,
      {
        headers: this.getHeader(this.getToken())
      }
    );
  }

  // Permission Management

  addPermissions(data: any) {
    return this.http.post(
      this.getBasePath() + `auth/permission/`,
      data,
      {
        headers: this.getHeader(this.getToken())
      }
    );
  }

  // getPermissions(data: any) {
  //   return this.http.get(
  //     this.getBasePath() + `auth/permission/?staff_id=${data?.staff_id}`,
  //     {
  //       headers: this.getHeader(this.getToken())
  //     }
  //   );
  // }

  getPermissions(data: any): Observable<any> {
    return this.http.get<any>(this.getBasePath() + `auth/permission/?staff_id=${data?.staff_id}&role_id=${data?.role_id}`, {
      headers: this.getHeader(this.getToken())
    }).pipe(
      tap((res: any) => {
        if (res?.status === 200) {
          this.permissionsSubject.next(res.data.permission || []);
          this.lastUpdated = Date.now();
        }
      })
    );
  }

  getPermissionsForAdmin(data: any) {
    return this.http.get(
      this.getBasePath() + `auth/permission/?staff_id=${data?.staff_id}&role_id=${data?.role_id}`,
      {
        headers: this.getHeader(this.getToken())
      }
    );
  }

  updatePermissions(data: any) {
    return this.http.put(
      this.getBasePath() + `auth/permission/`,
      data,
      {
        headers: this.getHeader(this.getToken())
      }
    );
  }

  // Branding Setting

  getBrandingDetails(data: any) {
    return this.http.get(
      this.getBasePath() + `auth/branding-setting/`,
      {
        headers: this.getHeader(this.getToken())
      }
    );
  }

  updateBrandingDetails(formData: any) {
    return this.http.put(
      this.getBasePath() + `auth/branding-setting/`,
      formData,
      {
        headers: new HttpHeaders({
          'Authorization': `Bearer ${this.getToken()}`
        })
      }
    );
  }

}
