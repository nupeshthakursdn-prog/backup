import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class MasterService {

  getBasePath() {
    return environment.apiUrl;
  }

  getToken() {
    return localStorage.getItem('token');
  }
  getHeader(token: any) {
    const httpHeaders = new HttpHeaders({
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`
    });
    return httpHeaders;
  }

  constructor(private http: HttpClient) { }

  //Role Category Management

  addRoleCategory(data: any) {
    return this.http.post(
      this.getBasePath() + `master/role-category/`,
      data,
      {
        headers: this.getHeader(this.getToken())
      }
    );
  }

  getRoleCategory(data: any) {
    return this.http.get(
      this.getBasePath() + `master/role-category/?page=${data?.page}&limit=${data?.limit}&search_text=${data?.searchText}`,
      {
        headers: this.getHeader(this.getToken())
      }
    );
  }

  getRoleCategoryById(data: any) {
    return this.http.get(
      this.getBasePath() + `master/role-category/${data?.id}`,
      {
        headers: this.getHeader(this.getToken())
      }
    );
  }

  updateRoleCategoryById(data: any) {
    return this.http.put(
      this.getBasePath() + `master/role-category/`,
      data,
      {
        headers: this.getHeader(this.getToken())
      }
    );
  }

  deleteRoleCategoryById(data: any) {
    return this.http.delete(
      this.getBasePath() + `master/role-category/${data.id}`,
      {
        headers: this.getHeader(this.getToken())
      }
    );
  }

  // Score Management

  addScore(data: any) {
    return this.http.post(
      this.getBasePath() + `master/score/`,
      data,
      {
        headers: this.getHeader(this.getToken())
      }
    );
  }

  getScores(data: any) {
    return this.http.get(
      this.getBasePath() + `master/score/?page=${data?.page}&limit=${data?.limit}&search_text=${data?.searchText}`,
      {
        headers: this.getHeader(this.getToken())
      }
    );
  }

  getScoreById(data: any) {
    return this.http.get(
      this.getBasePath() + `master/score/${data?.id}`,
      {
        headers: this.getHeader(this.getToken())
      }
    );
  }

  updateScoreId(data: any) {
    return this.http.put(
      this.getBasePath() + `master/score/`,
      data,
      {
        headers: this.getHeader(this.getToken())
      }
    );
  }

  deleteScoreById(data: any) {
    return this.http.delete(
      this.getBasePath() + `master/score/${data.id}`,
      {
        headers: this.getHeader(this.getToken())
      }
    );
  }

  // Technical Proficiency Management

  addTechnicalProficiency(data: any) {
    return this.http.post(
      this.getBasePath() + `master/technical-proficiency/`,
      data,
      {
        headers: this.getHeader(this.getToken())
      }
    );
  }

  getTechnicalProficiency(data: any) {
    return this.http.get(
      this.getBasePath() + `master/technical-proficiency/?page=${data?.page}&limit=${data?.limit}&search_text=${data?.searchText}`,
      {
        headers: this.getHeader(this.getToken())
      }
    );
  }

  getTechnicalProficiencyById(data: any) {
    return this.http.get(
      this.getBasePath() + `master/technical-proficiency/${data?.id}`,
      {
        headers: this.getHeader(this.getToken())
      }
    );
  }

  updateTechnicalProficiency(data: any) {
    return this.http.put(
      this.getBasePath() + `master/technical-proficiency/`,
      data,
      {
        headers: this.getHeader(this.getToken())
      }
    );
  }

  deleteTechnicalProficiencyById(data: any) {
    return this.http.delete(
      this.getBasePath() + `master/technical-proficiency/${data.techincal_proficiency_id}`,
      {
        headers: this.getHeader(this.getToken())
      }
    );
  }

  // Working Style Management

  addWorkingStyle(data: any) {
    return this.http.post(
      this.getBasePath() + `master/work-style/`,
      data,
      {
        headers: this.getHeader(this.getToken())
      }
    );
  }

  getWorkingStyles(data: any) {
    return this.http.get(
      this.getBasePath() + `master/work-style/?page=${data?.page}&limit=${data?.limit}&search_text=${data?.searchText}`,
      {
        headers: this.getHeader(this.getToken())
      }
    );
  }

  getWorkingStyleById(data: any) {
    return this.http.get(
      this.getBasePath() + `master/work-style/${data?.id}`,
      {
        headers: this.getHeader(this.getToken())
      }
    );
  }

  updateWorkingStyle(data: any) {
    return this.http.put(
      this.getBasePath() + `master/work-style/`,
      data,
      {
        headers: this.getHeader(this.getToken())
      }
    );
  }

  deleteWorkingStyleById(data: any) {
    return this.http.delete(
      this.getBasePath() + `master/work-style/${data?.id}`,
      {
        headers: this.getHeader(this.getToken())
      }
    );
  }

  // Cognitive Capability Management

  addcognitiveCapability(data: any) {
    return this.http.post(
      this.getBasePath() + `master/cognitive-capability/`,
      data,
      {
        headers: this.getHeader(this.getToken())
      }
    );
  }

  getcognitiveCapability(data: any) {
    return this.http.get(
      this.getBasePath() + `master/cognitive-capability/?page=${data?.page}&limit=${data?.limit}&search_text=${data?.searchText}`,
      {
        headers: this.getHeader(this.getToken())
      }
    );
  }

  updatecognitiveCapability(data: any) {
    return this.http.put(
      this.getBasePath() + `master/cognitive-capability/`,
      data,
      {
        headers: this.getHeader(this.getToken())
      }
    );
  }


  getcognitiveById(cognitiveId: any) {
    return this.http.get(
      this.getBasePath() + `master/cognitive-capability/${cognitiveId}`,
      {
        headers: this.getHeader(this.getToken())
      }
    );
  }

  deleteCognitiveById(cognitiveId: number) {
    return this.http.delete(
      this.getBasePath() + `master/cognitive-capability/${cognitiveId}/`,  // Send ID in the URL
      {
        headers: this.getHeader(this.getToken())
      }
    );
  }

  // Score Description Management

  addScoreDescription(data: any) {
    return this.http.post(
      this.getBasePath() + `master/score-description/`,
      data,
      {
        headers: this.getHeader(this.getToken())
      }
    );
  }

  getScoreDescription(data: any) {
    return this.http.get(
      this.getBasePath() + `master/score-description/?page=${data?.page}&limit=${data?.limit}&search_text=${data?.searchText}`,
      {
        headers: this.getHeader(this.getToken())
      }
    );
  }

  updateScoreDescriptionId(data: any) {
    return this.http.put(
      this.getBasePath() + `master/score-description/`,
      data,
      {
        headers: this.getHeader(this.getToken())
      }
    );
  }


  getScoreDesById(scoreId: any) {
    return this.http.get(
      this.getBasePath() + `master/score-description/${scoreId}`,
      {
        headers: this.getHeader(this.getToken())
      }
    );
  }

  deleteScoreDescriptionById(scoreId: number) {
    return this.http.delete(
      this.getBasePath() + `master/score-description/${scoreId}`,  // Send ID in the URL
      {
        headers: this.getHeader(this.getToken())
      }
    );
  }


  // Assessment Description Management

  addAssessmentDescription(data: any) {
    return this.http.post(
      this.getBasePath() + `master/assessment-description/`,
      data,
      {
        headers: this.getHeader(this.getToken())
      }
    );
  }

  getAssessmentDescription(data: any) {
    return this.http.get(
      this.getBasePath() + `master/assessment-description/?page=${data?.page}&limit=${data?.limit}&search_text=${data?.searchText}`,
      {
        headers: this.getHeader(this.getToken())
      }
    );
  }

  updateAssessmentDescriptionId(data: any) {
    return this.http.put(
      this.getBasePath() + `master/assessment-description/`,
      data,
      {
        headers: this.getHeader(this.getToken())
      }
    );
  }


  getAssessmentDesById(AssessmentId: any) {
    return this.http.get(
      this.getBasePath() + `master/assessment-description/${AssessmentId}`,
      {
        headers: this.getHeader(this.getToken())
      }
    );
  }

  deleteAssessmentDescriptionById(AssessmentId: number) {
    return this.http.delete(
      this.getBasePath() + `master/assessment-description/${AssessmentId}`,  // Send ID in the URL
      {
        headers: this.getHeader(this.getToken())
      }
    );
  }


  // Genius Pairing Fields
  getGeniusPairingsField() {
    return this.http.get(
      this.getBasePath() + `master/genius-pairing-field/`,
      {
        headers: this.getHeader(this.getToken())
      }
    );
  }

  // Genius Pairings Master

  addGeniusPairing(data: any) {
    return this.http.post(
      this.getBasePath() + `master/genius-pairing/`,
      data,
      {
        headers: this.getHeader(this.getToken())
      }
    );
  }

  getGeniusPairings(data: any) {
    return this.http.get(
      this.getBasePath() + `master/genius-pairing/?page=${data?.page}&limit=${data?.limit}&search_text=${data?.searchText}`,
      {
        headers: this.getHeader(this.getToken())
      }
    );
  }

  getGeniusPairingById(pairingId: any) {
    return this.http.get(
      this.getBasePath() + `master/genius-pairing/${pairingId}`,
      {
        headers: this.getHeader(this.getToken())
      }
    );
  }

  updateGeniusPairinById(data: any) {
    return this.http.put(
      this.getBasePath() + `master/genius-pairing/`,
      data,
      {
        headers: this.getHeader(this.getToken())
      }
    );
  }

  deleteGeniusPairinById(pairingId: number) {
    return this.http.delete(
      this.getBasePath() + `master/genius-pairing/${pairingId}`,
      {
        headers: this.getHeader(this.getToken())
      }
    );
  }

  // Assessment Grdae Master

  getAssessmentGrade(data: any) {
    return this.http.get(
      this.getBasePath() + `master/talent-assessment-score/?page=${data?.page}&limit=${data?.limit}&search_text=${data?.searchText}`,
      {
        headers: this.getHeader(this.getToken())
      }
    );
  }

  addAssessmentGrade(data: any) {
    return this.http.post(
      this.getBasePath() + `master/talent-assessment-score/`,
      data,
      {
        headers: this.getHeader(this.getToken())
      }
    );
  }

  getAssessmentGradeById(data: any) {
    return this.http.get(
      this.getBasePath() + `master/talent-assessment-score/${data?.id}`,
      {
        headers: this.getHeader(this.getToken())
      }
    );
  }

  updateAssessmentGrade(data: any) {
    return this.http.put(
      this.getBasePath() + `master/talent-assessment-score/`,
      data,
      {
        headers: this.getHeader(this.getToken())
      }
    );
  }

  deleteAssessmentGrade(data: any) {
    return this.http.delete(
      this.getBasePath() + `master/talent-assessment-score/${data.id}`,
      {
        headers: this.getHeader(this.getToken())
      }
    );
  }

}
