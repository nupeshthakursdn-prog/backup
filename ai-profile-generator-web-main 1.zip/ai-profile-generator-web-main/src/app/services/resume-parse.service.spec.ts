import { TestBed } from '@angular/core/testing';

import { ResumeParseService } from './resume-parse.service';

describe('ResumeParseService', () => {
  let service: ResumeParseService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ResumeParseService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
