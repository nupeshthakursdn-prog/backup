import { Injectable } from '@angular/core';
import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, tap } from 'rxjs/operators';
import { UserService } from '../services/user.service';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';

@Injectable()
export class AuthInterceptor implements HttpInterceptor {
  private lastPermissionsUpdate = 0; // Track last API call time
  private readonly updateThreshold = 30000; // 30 seconds threshold

  constructor(private userService: UserService, private toastrService: ToastrService, private router: Router) { }

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    let staffId = '';
    let isStaff = false;
    const loginUser = localStorage.getItem('loginUser');

    if (loginUser) {
      const parsedUser = JSON.parse(loginUser);
      staffId = parsedUser.user_id;
      isStaff = parsedUser.is_staff;
    }

    return next.handle(req).pipe(

      catchError((err: HttpErrorResponse) => {
        console.log(err, "error___________");

        if (err.status === 401) {
          // Check if the error message indicates an expired token

          this.userService.logoutUser();
          this.router.navigate(['/login']);
          this.toastrService.warning("please log in again.", "Session Expired");

          // if (err.error?.message?.toLowerCase().includes('token expired')) {
          //   this.toastrService.warning("please log in again.", "Session Expired");
          //   this.userService.logoutUser();
          //   this.router.navigate(['/login']);
          // } else {
          //   this.toastrService.warning("please log in again.", "Session Expired");
          //   this.userService.logoutUser();
          //   this.router.navigate(['/login']);
          // }
        } else if (err.status === 403) {
          this.userService.logoutUser();
          this.router.navigate(['/login']);
          // this.toastrService.warning("Your account has been deactivated please contact to admin.");
        }

        return throwError(() => err);
      }),

      tap(() => {

        // 1. Only update permissions if request is NOT the permission-fetching API itself
        // if (req.url.includes('/auth/permission')) {
        //   return;
        // }

        // 2. Prevent unnecessary frequent calls using time threshold
        const now = Date.now();
        if (now - this.lastPermissionsUpdate < this.updateThreshold) {
          return;
        }
        // console.log("inside__intercepter___");


        // 3. Call permission update method ONLY IF staffId exists and the user is a staff
        if (staffId && isStaff) {
          console.log('Updating permissions From Intercepter...');
          this.lastPermissionsUpdate = now;
          this.userService.updatePermissionsFromServer(staffId);
        }
      })
    );
  }
}
