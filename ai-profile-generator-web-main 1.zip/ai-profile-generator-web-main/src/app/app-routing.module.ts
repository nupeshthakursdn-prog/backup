import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './Components/Login/login.component';
import { ForgotPasswordComponent } from './Components/Forgot-password/forgot-password.component';
import { ResetPasswordComponent } from './Components/Reset-password/reset-password.component';
import { RoleManagementComponent } from './Components/role-management/role-management.component';
import { StaffManagementComponent } from './Components/Staff-management/staff-management.component';
import { authGuard } from './Components/auth-guard/auth.guard';
import { DashboardComponent } from './Components/dashboard/dashboard.component';
import { SetPasswordComponent } from './Components/set-password/set-password.component';
import { ScoreManagementComponent } from './Components/score-management/score-management.component';
import { RoleCategoryComponent } from './Components/role-category/role-category.component';
import { WorkStyleManagemntComponent } from './Components/work-style-managemnt/work-style-managemnt.component';
import { TechnicalProficiencyManagementComponent } from './Components/technical-proficiency-management/technical-proficiency-management.component';
import { CognitiveCapabilityComponent } from './Components/cognitive-capability/cognitive-capability.component';
import { CandidateProfileManagementComponent } from './Components/candidate-profile-management/candidate-profile-management.component';
import { ManualResumeComponent } from './Components/manual-resume/manual-resume.component';
import { AIParsedResumeComponent } from './Components/ai-parsed-resume/ai-parsed-resume.component';
import { UpdateProfileComponent } from './Components/update-profile/update-profile.component';
import { ChangePasswordComponent } from './Components/change-password/change-password.component';
import { PermissionManagementComponent } from './Components/permission-management/permission-management.component';
import { NoPermissionComponent } from './Components/no-permission/no-permission.component';
import { AiResumeTemplateComponent } from './Components/ai-resume-template/ai-resume-template.component';
import { ThemeSettingComponent } from './Components/theme-setting/theme-setting.component';
import { ScoreDescriptionComponent } from './Components/score-description/score-description.component';
import { NotFoundComponent } from './Components/not-found/not-found.component';
import { UpdateCandidateProfileComponent } from './Components/update-candidate-profile/update-candidate-profile.component';
import { GeniusPairingsComponent } from './Components/genius-pairings/genius-pairings.component';
import { AssessmentDescriptionComponent } from './Components/assessment-description/assessment-description.component';
import { AssessmentGradeComponent } from './Components/assessment-grade/assessment-grade.component';

const routes: Routes = [
  { path: "", redirectTo: "login", pathMatch: "full" },
  { path: 'login', component: LoginComponent },
  { path: 'dashboard', component: DashboardComponent,canActivate: [authGuard] },
  { path: 'forgot-password', component: ForgotPasswordComponent },
  { path: 'reset-password/:uuid/:token', component: ResetPasswordComponent },
  { path: 'set-password/:uuid/:token', component: SetPasswordComponent },
  { path: 'change-password', component: ChangePasswordComponent,canActivate: [authGuard] },
  { path: 'update-profile', component: UpdateProfileComponent, canActivate: [authGuard] },
  { path: 'role-management', component: RoleManagementComponent, canActivate: [authGuard] },
  { path: 'staff-management', component: StaffManagementComponent, canActivate: [authGuard] },
  { path: 'score-management', component: ScoreManagementComponent, canActivate: [authGuard] },
  { path: 'role-category', component: RoleCategoryComponent, canActivate: [authGuard] },
  { path: 'work-style-management', component: WorkStyleManagemntComponent, canActivate: [authGuard] },
  { path: 'cognitive-capability-management', component: CognitiveCapabilityComponent, canActivate: [authGuard] },
  { path: 'genius-pairings', component: GeniusPairingsComponent, canActivate: [authGuard] },
  { path: 'score-description', component: ScoreDescriptionComponent, canActivate: [authGuard] },
  { path: 'assessment-description', component: AssessmentDescriptionComponent, canActivate: [authGuard] },
  { path: 'assessment-grade', component: AssessmentGradeComponent, canActivate: [authGuard] },
  { path: 'permission-management', component: PermissionManagementComponent, canActivate: [authGuard] },
  { path: 'technical-proficiency-management', component: TechnicalProficiencyManagementComponent, canActivate: [authGuard] },
  { path: 'branding-setting', component: ThemeSettingComponent, canActivate: [authGuard] },
  { path: 'candidate-profile-creation', component: CandidateProfileManagementComponent, canActivate: [authGuard] },
  { path: 'candidate-profile-builder/:id', component: AiResumeTemplateComponent,canActivate: [authGuard] },
  { path: 'candidates/professional-details/:type', component: AIParsedResumeComponent,canActivate: [authGuard] },
  { path: 'candidates/profile/:id', component: UpdateCandidateProfileComponent,canActivate: [authGuard] },
  { path: 'ai-manual-resume', component: ManualResumeComponent,canActivate: [authGuard] },
  { path: 'no-permission', component: NoPermissionComponent },
  { path: '**', component: NotFoundComponent }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {

}
